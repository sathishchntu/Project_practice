package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.MilesDrivenOverSpeedingByMiles;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * MilesDrivenOverSpeedingByMilesRepository
 */
public interface MilesDrivenOverSpeedingByMilesRepository extends CassandraRepository<MilesDrivenOverSpeedingByMiles, Long> {
    @Query("select * from miles_driven_over_speeding_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    List<MilesDrivenOverSpeedingByMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId);

    @Query("select max(odometer) from miles_driven_over_speeding_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    Integer findMaxOdometerReadingByVinAndOrganizationId(String vinNumber, Integer organizationId);

    @Query("select * from miles_driven_over_speeding_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and odometer >= :fromOdometerReading and odometer <= :maxOdometerReading")
    List<MilesDrivenOverSpeedingByMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId, int fromOdometerReading, Integer maxOdometerReading);


}
