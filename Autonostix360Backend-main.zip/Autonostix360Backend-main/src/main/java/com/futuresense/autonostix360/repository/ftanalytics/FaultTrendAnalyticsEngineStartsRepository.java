package com.futuresense.autonostix360.repository.ftanalytics;

import com.futuresense.autonostix360.domain.ftanalytics.FaultTrendAnalyticsEngineStarts;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

/**
 * FaultTrendAnalyticsEngineStartsRepository
 */
public interface FaultTrendAnalyticsEngineStartsRepository extends CassandraRepository<FaultTrendAnalyticsEngineStarts, String> {

    @Query(value = "select * from fault_trend_analytics_engine_starts " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_in_engine_starts >= :fromRulEngineStarts and rul_in_engine_starts <= :toRulEngineStarts")
    Slice<FaultTrendAnalyticsEngineStarts> findByVinNumberAndOrganizationIdAndRulEngineStartsRange(String vinNumber, Integer organizationId, Integer fromRulEngineStarts, Integer toRulEngineStarts, Pageable pageable);


    @Query(value = "select count(*) from fault_trend_analytics_engine_starts " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_in_engine_starts >= :fromRulEngineStarts and rul_in_engine_starts <= :toRulEngineStarts")
    int pageCount(String vinNumber, Integer organizationId, Integer fromRulEngineStarts, Integer toRulEngineStarts);

    @Query(value = "select * from fault_trend_analytics_engine_starts " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_in_engine_starts >= :fromRulEngineStarts and rul_in_engine_starts <= :toRulEngineStarts")
    Slice<FaultTrendAnalyticsEngineStarts> findAllByVinNumberAndOrganizationIdAndRulEngineStartsRange(CassandraPageRequest pageRequest, String vinNumber, Integer organizationId, Integer fromRulEngineStarts, Integer toRulEngineStarts);
}