package com.futuresense.autonostix360.repository.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.UsageBasedMaintenance;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.UUID;

public interface UsageBasedMaintenanceRepository extends CassandraRepository<UsageBasedMaintenance, UUID> {
    @Query(value = "select * from usage_based_maintenance " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    Slice<UsageBasedMaintenance> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, String statsDate, Pageable pageable);

    @Query(value = "select count(*) from usage_based_maintenance " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    int pageCount(String vinNumber, Integer organizationId, String statsDate);

    @Query(value = "select * from usage_based_maintenance  " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    Slice<UsageBasedMaintenance> findByVinNumberAndOrganizationIdAndStatsDate(CassandraPageRequest pageRequest, String vinNumber, Integer organizationId, String statsDate);
}