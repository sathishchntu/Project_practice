package com.futuresense.autonostix360.mappers.ftanalytics.graphs;

import com.futuresense.autonostix360.domain.ftanalytics.graphs.FaultTrendAnalyticsRulGraphsThresholds;
import com.futuresense.autonostix360.dto.ftanalytics.graphs.FaultTrendAnalyticsRulGraphsThresholdsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class FaultTrendAnalyticsRulGraphsThresholdsMapper implements EntityMapper<FaultTrendAnalyticsRulGraphsThresholds, FaultTrendAnalyticsRulGraphsThresholdsDto> {
    @Override
    public FaultTrendAnalyticsRulGraphsThresholds buildEntity(FaultTrendAnalyticsRulGraphsThresholdsDto dto) {
        final FaultTrendAnalyticsRulGraphsThresholds entity = new FaultTrendAnalyticsRulGraphsThresholds();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setDtcCode(dto.getDtcCode());
        entity.setGraphName(dto.getGraphName());
        entity.setThresholdStart(dto.getThresholdStart());
        entity.setThresholdEnd(dto.getThresholdEnd());
        entity.setUnits(dto.getUnits());

        return entity;
    }

    @Override
    public String dtoClassName() {
        return FaultTrendAnalyticsRulGraphsThresholdsDto.class.getCanonicalName();
    }

    @Override
    public FaultTrendAnalyticsRulGraphsThresholdsDto buildDto(FaultTrendAnalyticsRulGraphsThresholds entity) {
        final FaultTrendAnalyticsRulGraphsThresholdsDto dto = new FaultTrendAnalyticsRulGraphsThresholdsDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setDtcCode(entity.getDtcCode());
        dto.setGraphName(entity.getGraphName());
        dto.setThresholdStart(entity.getThresholdStart());
        dto.setThresholdEnd(entity.getThresholdEnd());
        dto.setUnits(entity.getUnits());

        return dto;
    }

    @Override
    public String entityClassName() {
        return FaultTrendAnalyticsRulGraphsThresholds.class.getCanonicalName();
    }
}