package com.futuresense.autonostix360.mappers.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.TimeDrivenActions;
import com.futuresense.autonostix360.dto.maintenancelogs.score.TimeDrivenActionDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class TimeDrivenActionsMapper implements EntityMapper<TimeDrivenActions, TimeDrivenActionDto> {
    @Override
    public TimeDrivenActions buildEntity(TimeDrivenActionDto dto) {
        final TimeDrivenActions entity = new TimeDrivenActions();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setCompleted(dto.getCompleted());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setMetric(dto.getMetric());
        entity.setOdometer(dto.getOdometer());
        entity.setMileage(dto.getMileage());
        entity.setScheduled(dto.getScheduled());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMonthsInService(dto.getMonthsInService());
        entity.setViolation(dto.getViolation());
        entity.setWeighingFactor(dto.getWeighingFactor());
        entity.setPreScheduledMaintenance(dto.getPreScheduledMaintenance());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TimeDrivenActionDto.class.getCanonicalName();
    }

    @Override
    public TimeDrivenActionDto buildDto(TimeDrivenActions entity) {
        final TimeDrivenActionDto dto = new TimeDrivenActionDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setCompleted(entity.getCompleted());
        dto.setOdometer(entity.getOdometer());
        dto.setMileage(entity.getMileage());
        dto.setMetric(entity.getMetric());
        dto.setScheduled(entity.getScheduled());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMonthsInService(entity.getMonthsInService());
        dto.setViolation(entity.getViolation());
        dto.setPreScheduledMaintenance(entity.getPreScheduledMaintenance());
        dto.setWeighingFactor(entity.getWeighingFactor());
        dto.setLastUpdated(entity.getLastUpdated());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TimeDrivenActions.class.getCanonicalName();
    }
}
