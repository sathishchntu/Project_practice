package com.futuresense.autonostix360.mappers.ftanalytics;

import com.futuresense.autonostix360.domain.ftanalytics.FaultTrendAnalyticsMiles;
import com.futuresense.autonostix360.dto.ftanalytics.FaultTrendAnalyticsMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */

@Service
public class FaultTrendAnalyticsMilesMapper implements EntityMapper<FaultTrendAnalyticsMiles, FaultTrendAnalyticsMilesDto> {


    @Override
    public FaultTrendAnalyticsMiles buildEntity(FaultTrendAnalyticsMilesDto dto) {
        final FaultTrendAnalyticsMiles entity = new FaultTrendAnalyticsMiles();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setName(dto.getName());
        entity.setDtcCode(dto.getDtcCode());
        entity.setDescription(dto.getDescription());
        entity.setSubSystem(dto.getSubSystem());
        entity.setRulMiles(dto.getRulMiles());
        entity.setModule(dto.getModule());
        entity.setOdometer(dto.getOdometer());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setRulHours(dto.getRulHours());
        entity.setRulEngineRunTime(dto.getRulEngineRunTime());
        entity.setRulKeyStarts(dto.getRulKeyStarts());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return FaultTrendAnalyticsMilesDto.class.getCanonicalName();
    }

    @Override
    public FaultTrendAnalyticsMilesDto buildDto(FaultTrendAnalyticsMiles entity) {
        final FaultTrendAnalyticsMilesDto dto = new FaultTrendAnalyticsMilesDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setName(entity.getName());
        dto.setDtcCode(entity.getDtcCode());
        dto.setDescription(entity.getDescription());
        dto.setSubSystem(entity.getSubSystem());
        dto.setRulMiles(entity.getRulMiles());
        dto.setModule(entity.getModule());
        dto.setOdometer(entity.getOdometer());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setRulHours(entity.getRulHours());
        dto.setRulEngineRunTime(entity.getRulEngineRunTime());
        dto.setRulKeyStarts(entity.getRulKeyStarts());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return FaultTrendAnalyticsMiles.class.getCanonicalName();
    }
}
