package com.futuresense.autonostix360.dto.vehiclehealthcheck;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.vehiclehealthcheck.RightRearValveOutLet}.
 */
public class RightRearValveOutLetDto implements Serializable {

    private UUID id;

    private String vinNumber;

    private Integer organizationId;

    private String statsDate;

    private Integer odometer;

    private Timestamp lastUpdated;

    private String module;

    private Double time;

    private Integer valveActuationDutyCyclePWM;

    private Double breakFluidPressure20k;

    private Double breakFluidPressure50k;

    private Double breakFluidPressure100k;

    private Double breakFluidPressure120k;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public Double getTime() {
        return time;
    }

    public void setTime(Double time) {
        this.time = time;
    }

    public Integer getValveActuationDutyCyclePWM() {
        return valveActuationDutyCyclePWM;
    }

    public void setValveActuationDutyCyclePWM(Integer valveActuationDutyCyclePWM) {
        this.valveActuationDutyCyclePWM = valveActuationDutyCyclePWM;
    }

    public Double getBreakFluidPressure20k() {
        return breakFluidPressure20k;
    }

    public void setBreakFluidPressure20k(Double breakFluidPressure20k) {
        this.breakFluidPressure20k = breakFluidPressure20k;
    }

    public Double getBreakFluidPressure50k() {
        return breakFluidPressure50k;
    }

    public void setBreakFluidPressure50k(Double breakFluidPressure50k) {
        this.breakFluidPressure50k = breakFluidPressure50k;
    }

    public Double getBreakFluidPressure100k() {
        return breakFluidPressure100k;
    }

    public void setBreakFluidPressure100k(Double breakFluidPressure100k) {
        this.breakFluidPressure100k = breakFluidPressure100k;
    }

    public Double getBreakFluidPressure120k() {
        return breakFluidPressure120k;
    }

    public void setBreakFluidPressure120k(Double breakFluidPressure120k) {
        this.breakFluidPressure120k = breakFluidPressure120k;
    }
}
