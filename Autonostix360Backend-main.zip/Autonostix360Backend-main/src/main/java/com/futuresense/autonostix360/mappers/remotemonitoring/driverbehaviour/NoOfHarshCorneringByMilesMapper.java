package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfHarshCorneringByMiles;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfHarshCorneringByMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfHarshCorneringByMilesMapper implements EntityMapper<NoOfHarshCorneringByMiles, NoOfHarshCorneringByMilesDto> {
    @Override
    public NoOfHarshCorneringByMiles buildEntity(NoOfHarshCorneringByMilesDto dto) {
        final NoOfHarshCorneringByMiles entity = new NoOfHarshCorneringByMiles();
        entity.setId(dto.getId());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setNoOfHarshCornering(dto.getNoOfHarshCornering());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return NoOfHarshCorneringByMilesDto.class.getCanonicalName();
    }

    @Override
    public NoOfHarshCorneringByMilesDto buildDto(NoOfHarshCorneringByMiles entity) {
        final NoOfHarshCorneringByMilesDto dto = new NoOfHarshCorneringByMilesDto();
        dto.setId(entity.getId());
        dto.setMiles(entity.getMiles());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setNoOfHarshCornering(entity.getNoOfHarshCornering());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfHarshCorneringByMiles.class.getCanonicalName();
    }
}
