package com.futuresense.autonostix360.dto.usageprofile.aggregator;

import com.futuresense.autonostix360.dto.usageprofile.*;

import java.io.Serializable;
import java.util.List;

public class UsageProfileMilesApisAggregatorDto implements Serializable {

    private List<BreakPressureByLastMilesDto> breakPressureByLastMiles;

    private List<EngineCoolantTemperatureByLastMilesDto> engineCoolantTemperatureByLastMiles;

    private List<EngineOilLevelByLastMilesDto> engineOilLevelByLastMiles;

    private List<EngineOilTemperatureByLastMilesDto> engineOilTemperatureByLastMiles;

    private List<EngineSpeedByLastMilesDto> engineSpeedByLastMiles;

    private List<EngineTorqueByLastMilesDto> engineTorqueByLastMiles;

    private List<RemainingEngineLifeByLastMilesDto> remainingEngineLifeByLastMiles;

    private List<TirePressureByLastMilesDto> tirePressureByLastMiles;

    private List<TransmissionGearByLastMilesDto> transmissionGearByLastMiles;

    private List<TransmissionOilTemperatureByLastMilesDto> transmissionOilTemperatureByLastMiles;

    public List<BreakPressureByLastMilesDto> getBreakPressureByLastMiles() {
        return breakPressureByLastMiles;
    }

    public void setBreakPressureByLastMiles(List<BreakPressureByLastMilesDto> breakPressureByLastMiles) {
        this.breakPressureByLastMiles = breakPressureByLastMiles;
    }

    public List<EngineCoolantTemperatureByLastMilesDto> getEngineCoolantTemperatureByLastMiles() {
        return engineCoolantTemperatureByLastMiles;
    }

    public void setEngineCoolantTemperatureByLastMiles(List<EngineCoolantTemperatureByLastMilesDto> engineCoolantTemperatureByLastMiles) {
        this.engineCoolantTemperatureByLastMiles = engineCoolantTemperatureByLastMiles;
    }

    public List<EngineOilLevelByLastMilesDto> getEngineOilLevelByLastMiles() {
        return engineOilLevelByLastMiles;
    }

    public void setEngineOilLevelByLastMiles(List<EngineOilLevelByLastMilesDto> engineOilLevelByLastMiles) {
        this.engineOilLevelByLastMiles = engineOilLevelByLastMiles;
    }

    public List<EngineOilTemperatureByLastMilesDto> getEngineOilTemperatureByLastMiles() {
        return engineOilTemperatureByLastMiles;
    }

    public void setEngineOilTemperatureByLastMiles(List<EngineOilTemperatureByLastMilesDto> engineOilTemperatureByLastMiles) {
        this.engineOilTemperatureByLastMiles = engineOilTemperatureByLastMiles;
    }

    public List<EngineSpeedByLastMilesDto> getEngineSpeedByLastMiles() {
        return engineSpeedByLastMiles;
    }

    public void setEngineSpeedByLastMiles(List<EngineSpeedByLastMilesDto> engineSpeedByLastMiles) {
        this.engineSpeedByLastMiles = engineSpeedByLastMiles;
    }

    public List<EngineTorqueByLastMilesDto> getEngineTorqueByLastMiles() {
        return engineTorqueByLastMiles;
    }

    public void setEngineTorqueByLastMiles(List<EngineTorqueByLastMilesDto> engineTorqueByLastMiles) {
        this.engineTorqueByLastMiles = engineTorqueByLastMiles;
    }

    public List<RemainingEngineLifeByLastMilesDto> getRemainingEngineLifeByLastMiles() {
        return remainingEngineLifeByLastMiles;
    }

    public void setRemainingEngineLifeByLastMiles(List<RemainingEngineLifeByLastMilesDto> remainingEngineLifeByLastMiles) {
        this.remainingEngineLifeByLastMiles = remainingEngineLifeByLastMiles;
    }

    public List<TirePressureByLastMilesDto> getTirePressureByLastMiles() {
        return tirePressureByLastMiles;
    }

    public void setTirePressureByLastMiles(List<TirePressureByLastMilesDto> tirePressureByLastMiles) {
        this.tirePressureByLastMiles = tirePressureByLastMiles;
    }

    public List<TransmissionGearByLastMilesDto> getTransmissionGearByLastMiles() {
        return transmissionGearByLastMiles;
    }

    public void setTransmissionGearByLastMiles(List<TransmissionGearByLastMilesDto> transmissionGearByLastMiles) {
        this.transmissionGearByLastMiles = transmissionGearByLastMiles;
    }

    public List<TransmissionOilTemperatureByLastMilesDto> getTransmissionOilTemperatureByLastMiles() {
        return transmissionOilTemperatureByLastMiles;
    }

    public void setTransmissionOilTemperatureByLastMiles(List<TransmissionOilTemperatureByLastMilesDto> transmissionOilTemperatureByLastMiles) {
        this.transmissionOilTemperatureByLastMiles = transmissionOilTemperatureByLastMiles;
    }
}
