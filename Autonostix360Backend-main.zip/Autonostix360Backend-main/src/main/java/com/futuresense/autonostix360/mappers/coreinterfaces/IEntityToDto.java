package com.futuresense.autonostix360.mappers.coreinterfaces;

public interface IEntityToDto<E, D> {
    D buildDto(E entity);

    String entityClassName();
}
