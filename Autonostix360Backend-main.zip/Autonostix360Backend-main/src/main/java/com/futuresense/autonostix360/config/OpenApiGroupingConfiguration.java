package com.futuresense.autonostix360.config;

import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Config file that groups apis on swagger by modules
 */
@Configuration
public class OpenApiGroupingConfiguration {

    @Bean
    GroupedOpenApi vehicleUsageProfileApis() {
        return GroupedOpenApi.builder().group("usageProfile").pathsToMatch("/**/usage_profile/**").build();
    }

    @Bean
    GroupedOpenApi vehicleHealthCheckApis() {
        return GroupedOpenApi.builder().group("vehicleHealthCheck").pathsToMatch("/**/vehicle_health_check/**").build();
    }

    @Bean
    GroupedOpenApi propertiesApis() {
        return GroupedOpenApi.builder().group("properties").pathsToMatch("/**/properties/**").build();
    }

    @Bean
    GroupedOpenApi faultTrendAnalyticsApis() {
        return GroupedOpenApi.builder().group("faultTrendAnalytics").pathsToMatch("/**/fault_trend_analytics/**").build();
    }

    @Bean
    GroupedOpenApi maintenanceLogsApis() {
        return GroupedOpenApi.builder().group("maintenanceLogs").pathsToMatch("/**/maintenance_logs/**").build();
    }

    @Bean
    GroupedOpenApi remoteMonitoringApis() {
        return GroupedOpenApi.builder().group("remoteMonitoring").pathsToMatch("/**/remote_monitoring/**").build();
    }

    @Bean
    GroupedOpenApi maintenanceOnDemandApis() {
        return GroupedOpenApi.builder().group("maintenanceOnDemand").pathsToMatch("/**/mod/**").build();
    }

    @Bean
    GroupedOpenApi vehicleOverViewApis() {
        return GroupedOpenApi.builder().group("vehicleOverView").pathsToMatch("/**/vehicle_overview/**").build();
    }
}
