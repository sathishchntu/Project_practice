package com.futuresense.autonostix360.mappers.properties;

import com.futuresense.autonostix360.domain.properties.AutonostixProperties;
import com.futuresense.autonostix360.dto.properties.AutonostixPropertiesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class AutonostixPropertiesMapper implements EntityMapper<AutonostixProperties, AutonostixPropertiesDto> {


    @Override
    public AutonostixProperties buildEntity(AutonostixPropertiesDto dto) {
        final AutonostixProperties entity = new AutonostixProperties();
        entity.setId(dto.getId());
        entity.setPropertyForTable(dto.getPropertyForTable());
        entity.setPropertyName(dto.getPropertyName());
        entity.setPropertyValue(dto.getPropertyValue());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setLastUpdated(dto.getLastUpdated());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return AutonostixPropertiesDto.class.getCanonicalName();
    }

    @Override
    public AutonostixPropertiesDto buildDto(AutonostixProperties entity) {
        final AutonostixPropertiesDto dto = new AutonostixPropertiesDto();
        dto.setId(entity.getId());
        dto.setPropertyForTable(entity.getPropertyForTable());
        dto.setPropertyName(entity.getPropertyName());
        dto.setPropertyValue(entity.getPropertyValue());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setLastUpdated(entity.getLastUpdated());
        return dto;
    }

    @Override
    public String entityClassName() {
        return AutonostixProperties.class.getCanonicalName();
    }
}
