package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.EngineRunTimeDistanceTravelledByMiles;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.EngineRunTimeDistanceTravelledByMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineRunTimeDistanceTravelledByMilesMapper implements EntityMapper<EngineRunTimeDistanceTravelledByMiles, EngineRunTimeDistanceTravelledByMilesDto> {
    @Override
    public EngineRunTimeDistanceTravelledByMiles buildEntity(EngineRunTimeDistanceTravelledByMilesDto dto) {
        final EngineRunTimeDistanceTravelledByMiles entity = new EngineRunTimeDistanceTravelledByMiles();
        entity.setId(dto.getId());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineRunTimeDistanceTravelledByMilesDto.class.getCanonicalName();
    }

    @Override
    public EngineRunTimeDistanceTravelledByMilesDto buildDto(EngineRunTimeDistanceTravelledByMiles entity) {
        final EngineRunTimeDistanceTravelledByMilesDto dto = new EngineRunTimeDistanceTravelledByMilesDto();
        dto.setId(entity.getId());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineRunTimeDistanceTravelledByMiles.class.getCanonicalName();
    }
}
