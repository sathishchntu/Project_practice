package com.futuresense.autonostix360.dto.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineCoolantTemperatureByLastTrip;

import java.io.Serializable;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link EngineCoolantTemperatureByLastTrip}.
 */
public class EngineCoolantTemperatureByLastTripDto implements Serializable {

    private UUID id;

    private Integer trip;

    private Integer temperatureInFahrenheit;

    private Double miles;

    private Double hours;

    private Integer engineRunTime;

    private Integer keyStarts;

    private String threshold;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Integer getTrip() {
        return trip;
    }

    public void setTrip(Integer trip) {
        this.trip = trip;
    }

    public Double getMiles() {
        return miles;
    }

    public void setMiles(Double miles) {
        this.miles = miles;
    }

    public Double getHours() {
        return hours;
    }

    public void setHours(Double hours) {
        this.hours = hours;
    }

    public Integer getEngineRunTime() {
        return engineRunTime;
    }

    public void setEngineRunTime(Integer engineRunTime) {
        this.engineRunTime = engineRunTime;
    }

    public Integer getKeyStarts() {
        return keyStarts;
    }

    public void setKeyStarts(Integer keyStarts) {
        this.keyStarts = keyStarts;
    }

    public String getThreshold() {
        return threshold;
    }

    public void setThreshold(String threshold) {
        this.threshold = threshold;
    }

    public Integer getTemperatureInFahrenheit() {
        return temperatureInFahrenheit;
    }

    public void setTemperatureInFahrenheit(Integer temperatureInFahrenheit) {
        this.temperatureInFahrenheit = temperatureInFahrenheit;
    }
}
