package com.futuresense.autonostix360.dto.vehiclehealthcheck;

import java.util.UUID;

public class KoeoPostTestResultsDto {

    private UUID id;

    private String statsDate;

    private String dtcCode;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }
}
