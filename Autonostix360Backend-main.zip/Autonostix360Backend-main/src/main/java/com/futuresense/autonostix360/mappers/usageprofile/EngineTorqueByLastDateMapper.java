package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineTorqueByLastDate;
import com.futuresense.autonostix360.dto.usageprofile.EngineTorqueByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineTorqueByLastDateMapper implements EntityMapper<EngineTorqueByLastDate, EngineTorqueByLastDateDto> {

    @Override
    public EngineTorqueByLastDate buildEntity(EngineTorqueByLastDateDto dto) {
        final EngineTorqueByLastDate entity = new EngineTorqueByLastDate();
        entity.setId(dto.getId());
        entity.setEngineTorque(dto.getEngineTorque());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineTorqueByLastDateDto.class.getCanonicalName();
    }

    @Override
    public EngineTorqueByLastDateDto buildDto(EngineTorqueByLastDate entity) {
        final EngineTorqueByLastDateDto dto = new EngineTorqueByLastDateDto();
        dto.setId(entity.getId());
        dto.setEngineTorque(entity.getEngineTorque());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineTorqueByLastDate.class.getCanonicalName();
    }
}
