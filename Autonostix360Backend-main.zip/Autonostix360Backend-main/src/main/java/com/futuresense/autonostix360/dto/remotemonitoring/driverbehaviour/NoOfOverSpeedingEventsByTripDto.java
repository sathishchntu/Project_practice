package com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfOverSpeedingEventsByTrip}.
 */

public class NoOfOverSpeedingEventsByTripDto implements Serializable {

    private UUID id;

    private Integer trip;

    private Integer miles;

    private Double hours;

    private Integer engineRunTime;

    private Integer keyStarts;

    private Integer noOfOverSpeeding;

    private Date statsDate;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Integer getTrip() {
        return trip;
    }

    public void setTrip(Integer trip) {
        this.trip = trip;
    }

    public Integer getMiles() {
        return miles;
    }

    public void setMiles(Integer miles) {
        this.miles = miles;
    }

    public Double getHours() {
        return hours;
    }

    public void setHours(Double hours) {
        this.hours = hours;
    }

    public Integer getEngineRunTime() {
        return engineRunTime;
    }

    public void setEngineRunTime(Integer engineRunTime) {
        this.engineRunTime = engineRunTime;
    }

    public Integer getKeyStarts() {
        return keyStarts;
    }

    public void setKeyStarts(Integer keyStarts) {
        this.keyStarts = keyStarts;
    }

    public Integer getNoOfOverSpeeding() {
        return noOfOverSpeeding;
    }

    public void setNoOfOverSpeeding(Integer noOfOverSpeeding) {
        this.noOfOverSpeeding = noOfOverSpeeding;
    }

    public Date getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(Date statsDate) {
        this.statsDate = statsDate;
    }
}
