package com.futuresense.autonostix360.repository.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.BatteryEnergyConsumptionAtKeyOffByLastTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * BatteryEnergyConsumptionAtKeyOffByLastTripRepository
 */
public interface BatteryEnergyConsumptionAtKeyOffByLastTripRepository extends CassandraRepository<BatteryEnergyConsumptionAtKeyOffByLastTrip, Long> {

    @Query(value = "select max(trip) from battery_energy_consumption_at_key_off_by_last_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from battery_energy_consumption_at_key_off_by_last_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<BatteryEnergyConsumptionAtKeyOffByLastTrip> findBatteryEnergyConsumptionAtKeyOffByLastTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}
