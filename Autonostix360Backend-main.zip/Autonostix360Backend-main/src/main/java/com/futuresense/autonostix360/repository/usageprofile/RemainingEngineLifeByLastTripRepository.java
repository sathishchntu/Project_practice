package com.futuresense.autonostix360.repository.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.RemainingEngineLifeByLastTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * EngineLifeByLastTripRepository
 */
public interface RemainingEngineLifeByLastTripRepository extends CassandraRepository<RemainingEngineLifeByLastTrip, Long> {

    @Query(value = "select max(trip) from remaining_engine_life_by_last_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from remaining_engine_life_by_last_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<RemainingEngineLifeByLastTrip> findEngineLifeByLastTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}
