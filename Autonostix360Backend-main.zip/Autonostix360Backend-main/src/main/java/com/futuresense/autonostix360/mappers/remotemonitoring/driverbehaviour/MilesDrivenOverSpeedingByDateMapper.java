package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.MilesDrivenOverSpeedingByDate;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.MilesDrivenOverSpeedingByDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class MilesDrivenOverSpeedingByDateMapper implements EntityMapper<MilesDrivenOverSpeedingByDate, MilesDrivenOverSpeedingByDateDto> {

    @Override
    public MilesDrivenOverSpeedingByDate buildEntity(MilesDrivenOverSpeedingByDateDto dto) {
        MilesDrivenOverSpeedingByDate entity = new MilesDrivenOverSpeedingByDate();
        entity.setId(dto.getId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setThreshold(dto.getThreshold());
        entity.setHours(dto.getHours());
        entity.setMiles(dto.getMiles());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return MilesDrivenOverSpeedingByDateDto.class.getCanonicalName();
    }

    @Override
    public MilesDrivenOverSpeedingByDateDto buildDto(MilesDrivenOverSpeedingByDate entity) {
        MilesDrivenOverSpeedingByDateDto dto = new MilesDrivenOverSpeedingByDateDto();
        dto.setId(entity.getId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setThreshold(entity.getThreshold());
        dto.setHours(entity.getHours());
        dto.setMiles(entity.getMiles());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return MilesDrivenOverSpeedingByDate.class.getCanonicalName();
    }
}