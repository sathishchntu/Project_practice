package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;


import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.EngineOnDistanceTravelledExtremeWeatherByDate;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.Date;
import java.util.List;

/**
 * EngineOnDistanceTravelledExtremeWeatherByDateRepository
 */
public interface EngineOnDistanceTravelledExtremeWeatherByDateRepository extends CassandraRepository<EngineOnDistanceTravelledExtremeWeatherByDate, String> {

    @Query(value = "select * from engine_on_distance_travelled_extreme_weather_by_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date = :dateString")
    List<EngineOnDistanceTravelledExtremeWeatherByDate> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, Date dateString);

    @Query(value = "select * from engine_on_distance_travelled_extreme_weather_by_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    List<EngineOnDistanceTravelledExtremeWeatherByDate> findAllByVinNumberAndOrganizationId(String vinNumber, Integer organizationId);

    @Query(value = "select * from engine_on_distance_travelled_extreme_weather_by_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date >= :fromDate and stats_date <= :toDate")
    List<EngineOnDistanceTravelledExtremeWeatherByDate> findByVinNumberAndOrganizationIdAndStatsDateRange(String vinNumber, Integer organizationId, Date fromDate, Date toDate);
}