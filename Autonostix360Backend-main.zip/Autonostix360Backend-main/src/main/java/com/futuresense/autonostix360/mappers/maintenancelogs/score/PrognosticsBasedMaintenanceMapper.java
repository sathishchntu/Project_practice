package com.futuresense.autonostix360.mappers.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.PrognosticsBasedMaintenance;
import com.futuresense.autonostix360.dto.maintenancelogs.score.PrognosticsBasedMaintenanceDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class PrognosticsBasedMaintenanceMapper implements EntityMapper<PrognosticsBasedMaintenance, PrognosticsBasedMaintenanceDto> {
    @Override
    public PrognosticsBasedMaintenance buildEntity(PrognosticsBasedMaintenanceDto dto) {
        PrognosticsBasedMaintenance entity = new PrognosticsBasedMaintenance();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setMaintenanceActivity(dto.getMaintenanceActivity());
        entity.setMetric(dto.getMetric());
        entity.setScheduled(dto.getScheduled());
        entity.setCompleted(dto.getCompleted());
        entity.setViolation(dto.getViolation());
        entity.setWeighnigFactor(dto.getWeighnigFactor());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return PrognosticsBasedMaintenanceDto.class.getCanonicalName();
    }

    @Override
    public PrognosticsBasedMaintenanceDto buildDto(PrognosticsBasedMaintenance entity) {
        PrognosticsBasedMaintenanceDto dto = new PrognosticsBasedMaintenanceDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setMaintenanceActivity(entity.getMaintenanceActivity());
        dto.setMetric(entity.getMetric());
        dto.setScheduled(entity.getScheduled());
        dto.setCompleted(entity.getCompleted());
        dto.setViolation(entity.getViolation());
        dto.setWeighnigFactor(entity.getWeighnigFactor());
        return dto;
    }

    @Override
    public String entityClassName() {
        return PrognosticsBasedMaintenance.class.getCanonicalName();
    }
}
