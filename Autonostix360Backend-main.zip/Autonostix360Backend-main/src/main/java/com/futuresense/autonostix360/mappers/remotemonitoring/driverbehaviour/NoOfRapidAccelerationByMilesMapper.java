package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfRapidAccelerationByMiles;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfRapidAccelerationByMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfRapidAccelerationByMilesMapper implements EntityMapper<NoOfRapidAccelerationByMiles, NoOfRapidAccelerationByMilesDto> {

    @Override
    public NoOfRapidAccelerationByMiles buildEntity(NoOfRapidAccelerationByMilesDto dto) {
        final NoOfRapidAccelerationByMiles entity = new NoOfRapidAccelerationByMiles();
        entity.setId(dto.getId());
        entity.setNoOfRapidAcceleration(dto.getNoOfRapidAcceleration());
        entity.setHours(dto.getHours());
        entity.setMiles(dto.getMiles());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return NoOfRapidAccelerationByMilesDto.class.getCanonicalName();
    }

    @Override
    public NoOfRapidAccelerationByMilesDto buildDto(NoOfRapidAccelerationByMiles entity) {
        final NoOfRapidAccelerationByMilesDto dto = new NoOfRapidAccelerationByMilesDto();
        dto.setId(entity.getId());
        dto.setNoOfRapidAcceleration(entity.getNoOfRapidAcceleration());
        dto.setHours(entity.getHours());
        dto.setMiles(entity.getMiles());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfRapidAccelerationByMiles.class.getCanonicalName();
    }
}