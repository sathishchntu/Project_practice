package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.StopSignViolationByDate;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.StopSignViolationByDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class StopSignViolationByDateMapper implements EntityMapper<StopSignViolationByDate, StopSignViolationByDateDto> {

    @Override
    public StopSignViolationByDate buildEntity(StopSignViolationByDateDto dto) {
        StopSignViolationByDate entity = new StopSignViolationByDate();
        entity.setId(dto.getId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setStopSignViolation(dto.getStopSignViolation());
        entity.setHours(dto.getHours());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return StopSignViolationByDateDto.class.getCanonicalName();
    }

    @Override
    public StopSignViolationByDateDto buildDto(StopSignViolationByDate entity) {
        StopSignViolationByDateDto dto = new StopSignViolationByDateDto();
        dto.setId(entity.getId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setStopSignViolation(entity.getStopSignViolation());
        dto.setHours(entity.getHours());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return StopSignViolationByDate.class.getCanonicalName();
    }
}
