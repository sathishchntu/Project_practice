package com.futuresense.autonostix360.mappers.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.Location;
import com.futuresense.autonostix360.dto.maintenancelogs.score.LocationDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class LocationMapper implements EntityMapper<Location, LocationDto> {
    @Override
    public Location buildEntity(LocationDto dto) {
        final Location entity = new Location();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setStatsDate(dto.getStatsDate());
        entity.setWeighingFactor(dto.getWeighingFactor());
        entity.setLocationOfService(dto.getLocationOfService());
        entity.setComponentReplaced(dto.getComponentReplaced());
        entity.setServiceCenterRanking(dto.getServiceCenterRanking());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return LocationDto.class.getCanonicalName();
    }

    @Override
    public LocationDto buildDto(Location entity) {
        final LocationDto dto = new LocationDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setStatsDate(entity.getStatsDate());
        dto.setLocationOfService(entity.getLocationOfService());
        dto.setWeighingFactor(entity.getWeighingFactor());
        dto.setServiceCenterRanking(entity.getServiceCenterRanking());
        dto.setComponentReplaced(entity.getComponentReplaced());
        return dto;
    }

    @Override
    public String entityClassName() {
        return Location.class.getCanonicalName();
    }
}
