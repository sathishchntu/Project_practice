package com.futuresense.autonostix360.repository.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.MaintenanceScoreCard;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

/**
 * Repository for maintenance_score_card
 */
public interface MaintenanceScoreCardRepository extends CassandraRepository<MaintenanceScoreCard, String> {

    @Query(value = "select * from maintenance_score_card where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    MaintenanceScoreCard findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, String statsDate);
}