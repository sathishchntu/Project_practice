package com.futuresense.autonostix360.mappers.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.MaintenanceScoreCard;
import com.futuresense.autonostix360.dto.maintenancelogs.score.MaintenanceScoreCardDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class MaintenanceScoreCardMapper implements EntityMapper<MaintenanceScoreCard, MaintenanceScoreCardDto> {
    @Override
    public MaintenanceScoreCard buildEntity(MaintenanceScoreCardDto dto) {
        final MaintenanceScoreCard entity = new MaintenanceScoreCard();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setOdometer(dto.getOdometer());
        entity.setMaintenanceStatus(dto.getMaintenanceStatus());
        entity.setScore(dto.getScore());
        entity.setUnit(dto.getUnit());

        return entity;
    }

    @Override
    public String dtoClassName() {
        return MaintenanceScoreCardDto.class.getCanonicalName();
    }

    @Override
    public MaintenanceScoreCardDto buildDto(MaintenanceScoreCard entity) {
        final MaintenanceScoreCardDto dto = new MaintenanceScoreCardDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setOdometer(entity.getOdometer());
        dto.setMaintenanceStatus(entity.getMaintenanceStatus());
        dto.setScore(entity.getScore());
        dto.setUnit(entity.getUnit());

        return dto;
    }

    @Override
    public String entityClassName() {
        return MaintenanceScoreCard.class.getCanonicalName();
    }
}