package com.futuresense.autonostix360.domain.ftanalytics.graphs;

import com.datastax.oss.driver.api.mapper.annotations.ClusteringColumn;
import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

/**
 * Entity FaultTrendAnalyticsRulGraphsThresholds represents table fault_trend_analytics_rul_graphs_thresholds
 */
@Table(value = "fault_trend_analytics_rul_graphs_thresholds")
public class FaultTrendAnalyticsRulGraphsThresholds {

    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("stats_date")
    private String statsDate;

    @PartitionKey(4)
    @Column("dtc_code")
    private String dtcCode;

    @PartitionKey(5)
    @Column("graph_name")
    private String graphName;

    @ClusteringColumn
    @Column("last_updated")
    private Timestamp lastUpdated;

    @Column("threshold_start")
    private List<Double> thresholdStart;

    @Column("threshold_end")
    private List<Double> thresholdEnd;

    @Column("units")
    private String units;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getGraphName() {
        return graphName;
    }

    public void setGraphName(String graphName) {
        this.graphName = graphName;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public List<Double> getThresholdStart() {
        return thresholdStart;
    }

    public void setThresholdStart(List<Double> thresholdStart) {
        this.thresholdStart = thresholdStart;
    }

    public List<Double> getThresholdEnd() {
        return thresholdEnd;
    }

    public void setThresholdEnd(List<Double> thresholdEnd) {
        this.thresholdEnd = thresholdEnd;
    }

    public String getUnits() {
        return units;
    }

    public void setUnits(String units) {
        this.units = units;
    }
}