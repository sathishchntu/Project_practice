package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.UreaDieselConsumptionByLastMiles;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.UreaDieselConsumptionByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class UreaDieselConsumptionByLastMilesMapper implements EntityMapper<UreaDieselConsumptionByLastMiles, UreaDieselConsumptionByLastMilesDto> {

    @Override
    public UreaDieselConsumptionByLastMiles buildEntity(UreaDieselConsumptionByLastMilesDto dto) {
        final UreaDieselConsumptionByLastMiles entity = new UreaDieselConsumptionByLastMiles();
        entity.setId(dto.getId());
        entity.setTimeToStartTheEngineSeconds(dto.getTimeToStartTheEngineSeconds());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return UreaDieselConsumptionByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public UreaDieselConsumptionByLastMilesDto buildDto(UreaDieselConsumptionByLastMiles entity) {
        final UreaDieselConsumptionByLastMilesDto dto = new UreaDieselConsumptionByLastMilesDto();
        dto.setId(entity.getId());
        dto.setTimeToStartTheEngineSeconds(entity.getTimeToStartTheEngineSeconds());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());

        return dto;
    }

    @Override
    public String entityClassName() {
        return UreaDieselConsumptionByLastMiles.class.getCanonicalName();
    }
}
