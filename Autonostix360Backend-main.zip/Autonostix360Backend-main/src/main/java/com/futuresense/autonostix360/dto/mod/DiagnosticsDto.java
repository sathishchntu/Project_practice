package com.futuresense.autonostix360.dto.mod;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

/**
 * Dto class for entity Diagnostics entity
 */
public class DiagnosticsDto implements Serializable {

    private UUID id;

    private String vinNumber;

    private Integer organizationId;

    private String statsDate;

    private String name;

    private String dtcCode;

    private String description;

    private String subsystem;

    private String module;

    private String rcaAndProbability;

    private Timestamp lastUpdated;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSubsystem() {
        return subsystem;
    }

    public void setSubsystem(String subsystem) {
        this.subsystem = subsystem;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getRcaAndProbability() {
        return rcaAndProbability;
    }

    public void setRcaAndProbability(String rcaAndProbability) {
        this.rcaAndProbability = rcaAndProbability;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
