package com.futuresense.autonostix360.dto.vehiclehealthcheck;

import java.util.UUID;

public class KoeoDto {

    private UUID id;

    private String statsDate;

    private String dtc;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getDtc() {
        return dtc;
    }

    public void setDtc(String dtc) {
        this.dtc = dtc;
    }
}
