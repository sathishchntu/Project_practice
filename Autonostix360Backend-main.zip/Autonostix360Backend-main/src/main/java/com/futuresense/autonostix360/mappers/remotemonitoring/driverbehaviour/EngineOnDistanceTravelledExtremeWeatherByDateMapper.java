package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.EngineOnDistanceTravelledExtremeWeatherByDate;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.EngineOnDistanceTravelledExtremeWeatherByDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineOnDistanceTravelledExtremeWeatherByDateMapper implements EntityMapper<EngineOnDistanceTravelledExtremeWeatherByDate, EngineOnDistanceTravelledExtremeWeatherByDateDto> {

    @Override
    public EngineOnDistanceTravelledExtremeWeatherByDate buildEntity(EngineOnDistanceTravelledExtremeWeatherByDateDto dto) {
        final EngineOnDistanceTravelledExtremeWeatherByDate entity = new EngineOnDistanceTravelledExtremeWeatherByDate();
        entity.setId(dto.getId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineOnDistanceTravelledExtremeWeatherByDateDto.class.getCanonicalName();
    }

    @Override
    public EngineOnDistanceTravelledExtremeWeatherByDateDto buildDto(EngineOnDistanceTravelledExtremeWeatherByDate entity) {
        final EngineOnDistanceTravelledExtremeWeatherByDateDto dto = new EngineOnDistanceTravelledExtremeWeatherByDateDto();
        dto.setId(entity.getId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineOnDistanceTravelledExtremeWeatherByDate.class.getCanonicalName();
    }
}