package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.MilesDrivenOverSpeedingByDate;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.Date;
import java.util.List;

/**
 * MilesDrivenOverSpeedingByDateRepository
 */
public interface MilesDrivenOverSpeedingByDateRepository extends CassandraRepository<MilesDrivenOverSpeedingByDate, String> {

    @Query(value = "select * from miles_driven_over_speeding_by_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date = :dateString")
    List<MilesDrivenOverSpeedingByDate> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, Date dateString);

    @Query(value = "select * from miles_driven_over_speeding_by_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    List<MilesDrivenOverSpeedingByDate> findAllByVinNumberAndOrganizationId(String vinNumber, Integer organizationId);

    @Query(value = "select * from miles_driven_over_speeding_by_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date >= :fromDate and stats_date <= :toDate")
    List<MilesDrivenOverSpeedingByDate> findByVinNumberAndOrganizationIdAndStatsDateRange(String vinNumber, Integer organizationId, Date fromDate, Date toDate);
}