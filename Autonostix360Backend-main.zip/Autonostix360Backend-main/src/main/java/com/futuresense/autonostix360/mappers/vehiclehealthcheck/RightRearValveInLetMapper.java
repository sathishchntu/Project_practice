package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.RightRearValveInLet;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.RightRearValveInLetDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class RightRearValveInLetMapper implements EntityMapper<RightRearValveInLet, RightRearValveInLetDto> {

    @Override
    public RightRearValveInLet buildEntity(RightRearValveInLetDto dto) {
        final RightRearValveInLet entity = new RightRearValveInLet();
        entity.setId(dto.getId());
        entity.setModule(dto.getModule());
        entity.setTime(dto.getTime());
        entity.setValveActuationDutyCyclePWM(dto.getValveActuationDutyCyclePWM());
        entity.setBreakFluidPressure20k(dto.getBreakFluidPressure20k());
        entity.setBreakFluidPressure50k(dto.getBreakFluidPressure50k());
        entity.setBreakFluidPressure100k(dto.getBreakFluidPressure100k());
        entity.setBreakFluidPressure120k(dto.getBreakFluidPressure120k());
        entity.setBreakFluidPressure150k(dto.getBreakFluidPressure150k());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setOdometer(dto.getOdometer());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return RightRearValveInLetDto.class.getCanonicalName();
    }

    @Override
    public RightRearValveInLetDto buildDto(RightRearValveInLet entity) {
        final RightRearValveInLetDto dto = new RightRearValveInLetDto();
        dto.setId(entity.getId());
        dto.setModule(entity.getModule());
        dto.setTime(entity.getTime());
        dto.setBreakFluidPressure20k(entity.getBreakFluidPressure20k());
        dto.setBreakFluidPressure50k(entity.getBreakFluidPressure50k());
        dto.setValveActuationDutyCyclePWM(entity.getValveActuationDutyCyclePWM());
        dto.setBreakFluidPressure100k(entity.getBreakFluidPressure100k());
        dto.setBreakFluidPressure120k(entity.getBreakFluidPressure120k());
        dto.setBreakFluidPressure150k(entity.getBreakFluidPressure150k());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setStatsDate(entity.getStatsDate());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOdometer(entity.getOdometer());
        return dto;
    }

    @Override
    public String entityClassName() {
        return RightRearValveInLet.class.getCanonicalName();
    }
}
