package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.DTCDetails;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.DtcDetailsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class DTCDetailsMapper implements EntityMapper<DTCDetails, DtcDetailsDto> {

    @Override
    public DTCDetails buildEntity(DtcDetailsDto dto) {
        final DTCDetails entity = new DTCDetails();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setDtcCode(dto.getDtcCode());
        entity.setCausalProbability(dto.getCausalProbability());
        entity.setAssociatedDtcs(dto.getAssociatedDtcs());
        entity.setDescription(dto.getDescription());
        entity.setHistoricalRootCause(dto.getHistoricalRootCause());
        entity.setPotentialSolution(dto.getPotentialSolution());
        entity.setOdometer(dto.getOdometer());
        entity.setLastUpdated(dto.getLastUpdated());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return DtcDetailsDto.class.getCanonicalName();
    }

    @Override
    public DtcDetailsDto buildDto(DTCDetails entity) {
        final DtcDetailsDto dto = new DtcDetailsDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setDtcCode(entity.getDtcCode());
        dto.setCausalProbability(entity.getCausalProbability());
        dto.setAssociatedDtcs(entity.getAssociatedDtcs());
        dto.setDescription(entity.getDescription());
        dto.setHistoricalRootCause(entity.getHistoricalRootCause());
        dto.setPotentialSolution(entity.getPotentialSolution());
        dto.setOdometer(entity.getOdometer());
        dto.setLastUpdated(entity.getLastUpdated());
        return dto;
    }

    @Override
    public String entityClassName() {
        return DTCDetails.class.getCanonicalName();
    }
}
