package com.futuresense.autonostix360.dto.vehiclehealthcheck;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.vehiclehealthcheck.DTCDetails}.
 */
public class DtcDetailsDto implements Serializable {

    private UUID id;

    private String vinNumber;

    private Integer organizationId;

    private String statsDate;

    private String dtcCode;

    private String causalProbability;

    private String associatedDtcs;

    private String description;

    private String historicalRootCause;

    private String potentialSolution;

    private Integer odometer;

    private Timestamp lastUpdated;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getCausalProbability() {
        return causalProbability;
    }

    public void setCausalProbability(String causalProbability) {
        this.causalProbability = causalProbability;
    }

    public String getAssociatedDtcs() {
        return associatedDtcs;
    }

    public void setAssociatedDtcs(String associatedDtcs) {
        this.associatedDtcs = associatedDtcs;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getHistoricalRootCause() {
        return historicalRootCause;
    }

    public void setHistoricalRootCause(String historicalRootCause) {
        this.historicalRootCause = historicalRootCause;
    }

    public String getPotentialSolution() {
        return potentialSolution;
    }

    public void setPotentialSolution(String potentialSolution) {
        this.potentialSolution = potentialSolution;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
