package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.UreaDieselConsumptionByLastDate;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.UreaDieselConsumptionByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class UreaDieselConsumptionByLastDateMapper implements EntityMapper<UreaDieselConsumptionByLastDate, UreaDieselConsumptionByLastDateDto> {

    @Override
    public UreaDieselConsumptionByLastDate buildEntity(UreaDieselConsumptionByLastDateDto dto) {
        final UreaDieselConsumptionByLastDate entity = new UreaDieselConsumptionByLastDate();
        entity.setId(dto.getId());
        entity.setTimeToStartTheEngineSeconds(dto.getTimeToStartTheEngineSeconds());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return UreaDieselConsumptionByLastDateDto.class.getCanonicalName();
    }

    @Override
    public UreaDieselConsumptionByLastDateDto buildDto(UreaDieselConsumptionByLastDate entity) {
        final UreaDieselConsumptionByLastDateDto dto = new UreaDieselConsumptionByLastDateDto();
        dto.setId(entity.getId());
        dto.setTimeToStartTheEngineSeconds(entity.getTimeToStartTheEngineSeconds());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return UreaDieselConsumptionByLastDate.class.getCanonicalName();
    }
}
