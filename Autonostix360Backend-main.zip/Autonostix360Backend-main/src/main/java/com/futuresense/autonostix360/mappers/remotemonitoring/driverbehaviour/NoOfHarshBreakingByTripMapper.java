package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfHarshBreakingByTrip;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfHarshBreakingByTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfHarshBreakingByTripMapper implements EntityMapper<NoOfHarshBreakingByTrip, NoOfHarshBreakingByTripDto> {

    @Override
    public NoOfHarshBreakingByTrip buildEntity(NoOfHarshBreakingByTripDto dto) {
        final NoOfHarshBreakingByTrip entity = new NoOfHarshBreakingByTrip();
        entity.setId(dto.getId());
        entity.setTrip(dto.getTrip());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setNoOfHarshBreaking(dto.getNoOfHarshBreaking());
        entity.setStatsDate(dto.getStatsDate());
        return entity;

    }

    @Override
    public String dtoClassName() {
        return NoOfHarshBreakingByTripDto.class.getCanonicalName();
    }

    @Override
    public NoOfHarshBreakingByTripDto buildDto(NoOfHarshBreakingByTrip entity) {
        final NoOfHarshBreakingByTripDto dto = new NoOfHarshBreakingByTripDto();
        dto.setId(entity.getId());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setNoOfHarshBreaking(entity.getNoOfHarshBreaking());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfHarshBreakingByTrip.class.getCanonicalName();
    }
}

