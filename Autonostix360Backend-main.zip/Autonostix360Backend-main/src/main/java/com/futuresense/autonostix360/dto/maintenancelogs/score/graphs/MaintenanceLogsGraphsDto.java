package com.futuresense.autonostix360.dto.maintenancelogs.score.graphs;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

/**
 * Dto class for entity MaintenanceLogsGraphs entity
 */
public class MaintenanceLogsGraphsDto implements Serializable {

    private UUID id;

    private String vinNumber;

    private Integer organizationId;

    private String statsDate;

    private String graphName;

    private Timestamp lastUpdated;

    private String xAxisName;

    private String yAxisName;

    private Double xAxisData;

    private Double yAxisData;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getGraphName() {
        return graphName;
    }

    public void setGraphName(String graphName) {
        this.graphName = graphName;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getxAxisName() {
        return xAxisName;
    }

    public void setxAxisName(String xAxisName) {
        this.xAxisName = xAxisName;
    }

    public String getyAxisName() {
        return yAxisName;
    }

    public void setyAxisName(String yAxisName) {
        this.yAxisName = yAxisName;
    }

    public Double getxAxisData() {
        return xAxisData;
    }

    public void setxAxisData(Double xAxisData) {
        this.xAxisData = xAxisData;
    }

    public Double getyAxisData() {
        return yAxisData;
    }

    public void setyAxisData(Double yAxisData) {
        this.yAxisData = yAxisData;
    }
}