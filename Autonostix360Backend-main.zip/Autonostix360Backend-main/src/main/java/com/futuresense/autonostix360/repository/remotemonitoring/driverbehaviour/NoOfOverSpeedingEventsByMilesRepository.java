package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfOverSpeedingEventsByMiles;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * NoOfOverSpeedingEventsByMilesRepository
 */
public interface NoOfOverSpeedingEventsByMilesRepository extends CassandraRepository<NoOfOverSpeedingEventsByMiles, Long> {
    @Query("select * from no_of_over_speeding_events_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    List<NoOfOverSpeedingEventsByMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId);

    @Query("select max(odometer) from no_of_over_speeding_events_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    Integer findMaxOdometerReadingByVinAndOrganizationId(String vinNumber, Integer organizationId);

    @Query("select * from no_of_over_speeding_events_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and odometer >= :fromOdometerReading and odometer <= :maxOdometerReading")
    List<NoOfOverSpeedingEventsByMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId, int fromOdometerReading, Integer maxOdometerReading);


}
