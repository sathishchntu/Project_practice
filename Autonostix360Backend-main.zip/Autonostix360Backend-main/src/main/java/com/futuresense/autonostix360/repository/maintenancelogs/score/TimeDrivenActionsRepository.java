package com.futuresense.autonostix360.repository.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.TimeDrivenActions;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.UUID;

/**
 * TimeDrivenActions Repository
 */
public interface TimeDrivenActionsRepository extends CassandraRepository<TimeDrivenActions, UUID> {

    @Query(value = "select * from time_driven_actions where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    Slice<TimeDrivenActions> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, String statsDate, Pageable pageable);

    @Query(value = "select count(*) from time_driven_actions where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    int pageCount(String vinNumber, Integer organizationId, String statsDate);

    @Query(value = "select * from time_driven_actions where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    Slice<TimeDrivenActions> findByVinNumberAndOrganizationIdAndStatsDate(CassandraPageRequest pageRequest, String vinNumber, Integer organizationId, String statsDate);
}