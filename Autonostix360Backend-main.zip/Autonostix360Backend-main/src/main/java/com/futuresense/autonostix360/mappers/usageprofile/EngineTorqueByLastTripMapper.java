package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineTorqueByLastTrip;
import com.futuresense.autonostix360.dto.usageprofile.EngineTorqueByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineTorqueByLastTripMapper implements EntityMapper<EngineTorqueByLastTrip, EngineTorqueByLastTripDto> {
    @Override
    public EngineTorqueByLastTrip buildEntity(EngineTorqueByLastTripDto dto) {
        final EngineTorqueByLastTrip entity = new EngineTorqueByLastTrip();
        entity.setId(dto.getId());
        entity.setEngineTorque(dto.getEngineTorque());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineTorqueByLastTripDto.class.getCanonicalName();
    }

    @Override
    public EngineTorqueByLastTripDto buildDto(EngineTorqueByLastTrip entity) {
        final EngineTorqueByLastTripDto dto = new EngineTorqueByLastTripDto();
        dto.setId(entity.getId());
        dto.setEngineTorque(entity.getEngineTorque());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineTorqueByLastTrip.class.getCanonicalName();
    }
}
