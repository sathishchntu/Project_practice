package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.EngineRunTimeDistanceTravelledByTrip;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.EngineRunTimeDistanceTravelledByTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineRunTimeDistanceTravelledByTripMapper implements EntityMapper<EngineRunTimeDistanceTravelledByTrip, EngineRunTimeDistanceTravelledByTripDto> {

    @Override
    public EngineRunTimeDistanceTravelledByTrip buildEntity(EngineRunTimeDistanceTravelledByTripDto dto) {
        final EngineRunTimeDistanceTravelledByTrip entity = new EngineRunTimeDistanceTravelledByTrip();
        entity.setId(dto.getId());
        entity.setTrip(dto.getTrip());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setStatsDate(dto.getStatsDate());
        return entity;

    }

    @Override
    public String dtoClassName() {
        return EngineRunTimeDistanceTravelledByTripDto.class.getCanonicalName();
    }

    @Override
    public EngineRunTimeDistanceTravelledByTripDto buildDto(EngineRunTimeDistanceTravelledByTrip entity) {
        final EngineRunTimeDistanceTravelledByTripDto dto = new EngineRunTimeDistanceTravelledByTripDto();
        dto.setId(entity.getId());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineRunTimeDistanceTravelledByTrip.class.getCanonicalName();
    }
}

