package com.futuresense.autonostix360.mappers.mod;

import com.futuresense.autonostix360.domain.mod.Prognostics;
import com.futuresense.autonostix360.dto.mod.PrognosticsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */

@Service
public class PrognosticsMapper implements EntityMapper<Prognostics, PrognosticsDto> {


    @Override
    public Prognostics buildEntity(PrognosticsDto dto) {
        final Prognostics entity = new Prognostics();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setName(dto.getName());
        entity.setDtcCode(dto.getDtcCode());
        entity.setDescription(dto.getDescription());
        entity.setSubSystem(dto.getSubSystem());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setStatsDate(dto.getStatsDate());
        entity.setRcaAndProbability(dto.getRcaAndProbability());

        return entity;
    }

    @Override
    public String dtoClassName() {
        return PrognosticsDto.class.getCanonicalName();
    }

    @Override
    public PrognosticsDto buildDto(Prognostics entity) {
        final PrognosticsDto dto = new PrognosticsDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setName(entity.getName());
        dto.setDtcCode(entity.getDtcCode());
        dto.setDescription(entity.getDescription());
        dto.setSubSystem(entity.getSubSystem());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setStatsDate(entity.getStatsDate());
        dto.setRcaAndProbability(entity.getRcaAndProbability());

        return dto;
    }

    @Override
    public String entityClassName() {
        return Prognostics.class.getCanonicalName();
    }
}
