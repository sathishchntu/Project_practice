package com.futuresense.autonostix360.dto.search;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Search dto when searching by sub systems or dtc codes
 */
public class FilterSearchDto implements Serializable {

    @NotNull
    private String vinNumber;

    @NotNull
    private Integer organizationId;

    private String[] subSystems;

    private String[] dtcCodes;

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String[] getSubSystems() {
        return subSystems;
    }

    public void setSubSystems(String[] subSystems) {
        this.subSystems = subSystems;
    }

    public String[] getDtcCodes() {
        return dtcCodes;
    }

    public void setDtcCodes(String[] dtcCodes) {
        this.dtcCodes = dtcCodes;
    }
}
