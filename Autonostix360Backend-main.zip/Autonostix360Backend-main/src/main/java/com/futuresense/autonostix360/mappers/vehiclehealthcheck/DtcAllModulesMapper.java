package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.DTCAllModules;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.DTCAllModulesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class DtcAllModulesMapper implements EntityMapper<DTCAllModules, DTCAllModulesDto> {
    @Override
    public DTCAllModules buildEntity(DTCAllModulesDto dto) {
        final DTCAllModules entity = new DTCAllModules();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setDtcCode(dto.getDtcCode());
        entity.setDescription(dto.getDescription());
        entity.setDtcStatus(dto.getDtcStatus());
        entity.setOdometer(dto.getOdometer());
        entity.setStatsDate(dto.getStatsDate());
        entity.setCategory(dto.getCategory());
        entity.setLastUpdated(dto.getLastUpdated());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return DTCAllModulesDto.class.getCanonicalName();
    }

    @Override
    public DTCAllModulesDto buildDto(DTCAllModules entity) {
        final DTCAllModulesDto dto = new DTCAllModulesDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setDtcCode(entity.getDtcCode());
        dto.setDescription(entity.getDescription());
        dto.setDtcStatus(entity.getDtcStatus());
        dto.setOdometer(entity.getOdometer());
        dto.setStatsDate(entity.getStatsDate());
        dto.setCategory(entity.getCategory());
        dto.setLastUpdated(entity.getLastUpdated());
        return dto;
    }

    @Override
    public String entityClassName() {
        return DTCAllModules.class.getCanonicalName();
    }
}
