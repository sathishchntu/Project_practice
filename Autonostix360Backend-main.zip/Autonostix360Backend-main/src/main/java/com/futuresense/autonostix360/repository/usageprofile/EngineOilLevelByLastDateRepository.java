package com.futuresense.autonostix360.repository.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineOilLevelByLastDate;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.Date;
import java.util.List;

/**
 * EngineOilLevelByLastDateRepository
 */
public interface EngineOilLevelByLastDateRepository extends CassandraRepository<EngineOilLevelByLastDate, String> {

    @Query(value = "select * from engine_oil_level_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date = :dateString")
    List<EngineOilLevelByLastDate> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, Date dateString);

    @Query(value = "select * from engine_oil_level_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    List<EngineOilLevelByLastDate> findAllByVinNumberAndOrganizationId(String vinNumber, Integer organizationId);

    @Query(value = "select * from engine_oil_level_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date >= :fromDate and stats_date <= :toDate")
    List<EngineOilLevelByLastDate> findByVinNumberAndOrganizationIdAndStatsDateRange(String vinNumber, Integer organizationId, Date fromDate, Date toDate);
}
