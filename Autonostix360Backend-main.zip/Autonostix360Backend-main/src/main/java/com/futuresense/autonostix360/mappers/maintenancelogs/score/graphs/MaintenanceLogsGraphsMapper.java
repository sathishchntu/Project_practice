package com.futuresense.autonostix360.mappers.maintenancelogs.score.graphs;

import com.futuresense.autonostix360.domain.maintenancelogs.score.graphs.MaintenanceLogsGraphs;
import com.futuresense.autonostix360.dto.maintenancelogs.score.graphs.MaintenanceLogsGraphsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class MaintenanceLogsGraphsMapper implements EntityMapper<MaintenanceLogsGraphs, MaintenanceLogsGraphsDto> {
    @Override
    public MaintenanceLogsGraphs buildEntity(MaintenanceLogsGraphsDto dto) {
        final MaintenanceLogsGraphs entity = new MaintenanceLogsGraphs();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setGraphName(dto.getGraphName());
        entity.setxAxisName(dto.getxAxisName());
        entity.setyAxisName(dto.getyAxisName());
        entity.setxAxisData(dto.getxAxisData());
        entity.setyAxisData(dto.getyAxisData());

        return entity;
    }

    @Override
    public String dtoClassName() {
        return MaintenanceLogsGraphsDto.class.getCanonicalName();
    }

    @Override
    public MaintenanceLogsGraphsDto buildDto(MaintenanceLogsGraphs entity) {
        final MaintenanceLogsGraphsDto dto = new MaintenanceLogsGraphsDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setGraphName(entity.getGraphName());
        dto.setxAxisName(entity.getxAxisName());
        dto.setyAxisName(entity.getyAxisName());
        dto.setxAxisData(entity.getxAxisData());
        dto.setyAxisData(entity.getyAxisData());

        return dto;
    }

    @Override
    public String entityClassName() {
        return MaintenanceLogsGraphs.class.getCanonicalName();
    }
}