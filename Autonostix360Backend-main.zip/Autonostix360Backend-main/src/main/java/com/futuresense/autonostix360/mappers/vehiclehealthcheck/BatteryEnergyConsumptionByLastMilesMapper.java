package com.futuresense.autonostix360.mappers.vehiclehealthcheck;


import com.futuresense.autonostix360.domain.vehiclehealthcheck.BatteryEnergyConsumptionByLastMiles;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.BatteryEnergyConsumptionByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class BatteryEnergyConsumptionByLastMilesMapper implements EntityMapper<BatteryEnergyConsumptionByLastMiles, BatteryEnergyConsumptionByLastMilesDto> {

    @Override
    public BatteryEnergyConsumptionByLastMiles buildEntity(BatteryEnergyConsumptionByLastMilesDto dto) {
        final BatteryEnergyConsumptionByLastMiles entity = new BatteryEnergyConsumptionByLastMiles();
        entity.setId(dto.getId());
        entity.setBatteryEnergyConsumptionKwhPer100Miles(dto.getBatteryEnergyConsumptionKwhPer100Miles());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return BatteryEnergyConsumptionByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public BatteryEnergyConsumptionByLastMilesDto buildDto(BatteryEnergyConsumptionByLastMiles entity) {
        final BatteryEnergyConsumptionByLastMilesDto dto = new BatteryEnergyConsumptionByLastMilesDto();
        dto.setId(entity.getId());
        dto.setBatteryEnergyConsumptionKwhPer100Miles(entity.getBatteryEnergyConsumptionKwhPer100Miles());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return BatteryEnergyConsumptionByLastMiles.class.getCanonicalName();
    }
}
