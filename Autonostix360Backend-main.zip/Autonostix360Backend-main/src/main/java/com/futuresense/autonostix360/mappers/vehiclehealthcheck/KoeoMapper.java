package com.futuresense.autonostix360.mappers.vehiclehealthcheck;


import com.futuresense.autonostix360.domain.vehiclehealthcheck.Koeo;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoeoDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class that converts dto to entity and vice versa
 */
@Service
public class KoeoMapper implements EntityMapper<Koeo, KoeoDto> {
    @Override
    public Koeo buildEntity(KoeoDto dto) {
        final Koeo entity = new Koeo();
        entity.setId(dto.getId());
        entity.setDtc(dto.getDtc());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return KoeoDto.class.getCanonicalName();
    }

    @Override
    public KoeoDto buildDto(Koeo entity) {
        final KoeoDto dto = new KoeoDto();
        dto.setId(entity.getId());
        dto.setDtc(entity.getDtc());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return Koeo.class.getCanonicalName();
    }
}
