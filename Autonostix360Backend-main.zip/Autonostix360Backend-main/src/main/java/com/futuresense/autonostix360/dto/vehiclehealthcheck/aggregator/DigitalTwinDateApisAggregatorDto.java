package com.futuresense.autonostix360.dto.vehiclehealthcheck.aggregator;

import com.futuresense.autonostix360.dto.vehiclehealthcheck.*;

import java.io.Serializable;
import java.util.List;

/**
 * Dto class for aggregated api for Digital Twin Date apis
 */
public class DigitalTwinDateApisAggregatorDto implements Serializable {

    private List<BatteryEnergyConsumptionAtKeyOffByLastDateDto> batteryEnergyConsumptionAtKeyOffByLastDates;

    private List<BatteryEnergyConsumptionByLastDateDto> batteryEnergyConsumptionByLastDates;

    private List<EngineFuelConsumptionByLastDateDto> engineFuelConsumptionByLastDates;

    private List<FuelConsumptionGalPer100MilesByLastDateDto> fuelConsumptionGalPer100MilesByLastDates;

    private List<RemainingOilLifeByLastDateDto> remainingOilLifeByLastDates;

    private List<TimeBetweenParticularFilterRegenByLastDateDto> timeBetweenParticularFilterRegenByLastDates;

    private List<TimeToStartEngineByLastDateDto> timeToStartEngineByLastDates;

    private List<UreaDieselConsumptionByLastDateDto> ureaDieselConsumptionByLastDates;

    public List<BatteryEnergyConsumptionAtKeyOffByLastDateDto> getBatteryEnergyConsumptionAtKeyOffByLastDates() {
        return batteryEnergyConsumptionAtKeyOffByLastDates;
    }

    public void setBatteryEnergyConsumptionAtKeyOffByLastDates(List<BatteryEnergyConsumptionAtKeyOffByLastDateDto> batteryEnergyConsumptionAtKeyOffByLastDates) {
        this.batteryEnergyConsumptionAtKeyOffByLastDates = batteryEnergyConsumptionAtKeyOffByLastDates;
    }

    public List<BatteryEnergyConsumptionByLastDateDto> getBatteryEnergyConsumptionByLastDates() {
        return batteryEnergyConsumptionByLastDates;
    }

    public void setBatteryEnergyConsumptionByLastDates(List<BatteryEnergyConsumptionByLastDateDto> batteryEnergyConsumptionByLastDates) {
        this.batteryEnergyConsumptionByLastDates = batteryEnergyConsumptionByLastDates;
    }

    public List<EngineFuelConsumptionByLastDateDto> getEngineFuelConsumptionByLastDates() {
        return engineFuelConsumptionByLastDates;
    }

    public void setEngineFuelConsumptionByLastDates(List<EngineFuelConsumptionByLastDateDto> engineFuelConsumptionByLastDates) {
        this.engineFuelConsumptionByLastDates = engineFuelConsumptionByLastDates;
    }

    public List<FuelConsumptionGalPer100MilesByLastDateDto> getFuelConsumptionGalPer100MilesByLastDates() {
        return fuelConsumptionGalPer100MilesByLastDates;
    }

    public void setFuelConsumptionGalPer100MilesByLastDates(List<FuelConsumptionGalPer100MilesByLastDateDto> fuelConsumptionGalPer100MilesByLastDates) {
        this.fuelConsumptionGalPer100MilesByLastDates = fuelConsumptionGalPer100MilesByLastDates;
    }

    public List<RemainingOilLifeByLastDateDto> getRemainingOilLifeByLastDates() {
        return remainingOilLifeByLastDates;
    }

    public void setRemainingOilLifeByLastDates(List<RemainingOilLifeByLastDateDto> remainingOilLifeByLastDates) {
        this.remainingOilLifeByLastDates = remainingOilLifeByLastDates;
    }

    public List<TimeBetweenParticularFilterRegenByLastDateDto> getTimeBetweenParticularFilterRegenByLastDates() {
        return timeBetweenParticularFilterRegenByLastDates;
    }

    public void setTimeBetweenParticularFilterRegenByLastDates(List<TimeBetweenParticularFilterRegenByLastDateDto> timeBetweenParticularFilterRegenByLastDates) {
        this.timeBetweenParticularFilterRegenByLastDates = timeBetweenParticularFilterRegenByLastDates;
    }

    public List<TimeToStartEngineByLastDateDto> getTimeToStartEngineByLastDates() {
        return timeToStartEngineByLastDates;
    }

    public void setTimeToStartEngineByLastDates(List<TimeToStartEngineByLastDateDto> timeToStartEngineByLastDates) {
        this.timeToStartEngineByLastDates = timeToStartEngineByLastDates;
    }

    public List<UreaDieselConsumptionByLastDateDto> getUreaDieselConsumptionByLastDates() {
        return ureaDieselConsumptionByLastDates;
    }

    public void setUreaDieselConsumptionByLastDates(List<UreaDieselConsumptionByLastDateDto> ureaDieselConsumptionByLastDates) {
        this.ureaDieselConsumptionByLastDates = ureaDieselConsumptionByLastDates;
    }
}
