package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.KoeoPreTestResults;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoeoPreTestResultsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class that converts dto to entity and vice versa
 */
@Service
public class KoeoPreTestResultsMapper implements EntityMapper<KoeoPreTestResults, KoeoPreTestResultsDto> {
    @Override
    public KoeoPreTestResults buildEntity(KoeoPreTestResultsDto dto) {
        final KoeoPreTestResults entity = new KoeoPreTestResults();
        entity.setId(dto.getId());
        entity.setDtcCode(dto.getDtcCode());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return KoeoPreTestResultsDto.class.getCanonicalName();
    }

    @Override
    public KoeoPreTestResultsDto buildDto(KoeoPreTestResults entity) {
        final KoeoPreTestResultsDto dto = new KoeoPreTestResultsDto();
        dto.setId(entity.getId());
        dto.setDtcCode(entity.getDtcCode());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return KoeoPreTestResults.class.getCanonicalName();
    }
}
