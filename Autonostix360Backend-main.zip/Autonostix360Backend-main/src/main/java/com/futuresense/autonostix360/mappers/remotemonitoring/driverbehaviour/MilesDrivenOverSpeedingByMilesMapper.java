package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.MilesDrivenOverSpeedingByMiles;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.MilesDrivenOverSpeedingByMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class MilesDrivenOverSpeedingByMilesMapper implements EntityMapper<MilesDrivenOverSpeedingByMiles, MilesDrivenOverSpeedingByMilesDto> {
    @Override
    public MilesDrivenOverSpeedingByMiles buildEntity(MilesDrivenOverSpeedingByMilesDto dto) {
        final MilesDrivenOverSpeedingByMiles entity = new MilesDrivenOverSpeedingByMiles();
        entity.setId(dto.getId());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return MilesDrivenOverSpeedingByMilesDto.class.getCanonicalName();
    }

    @Override
    public MilesDrivenOverSpeedingByMilesDto buildDto(MilesDrivenOverSpeedingByMiles entity) {
        final MilesDrivenOverSpeedingByMilesDto dto = new MilesDrivenOverSpeedingByMilesDto();
        dto.setId(entity.getId());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setThreshold(entity.getThreshold());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setEngineRunTime(entity.getEngineRunTime());
        return dto;
    }

    @Override
    public String entityClassName() {
        return MilesDrivenOverSpeedingByMiles.class.getCanonicalName();
    }
}
