package com.futuresense.autonostix360.dto.vehiclehealthcheck;

import java.util.UUID;

/**
 * Dto class for Entity {@link com.futuresense.autonostix360.domain.vehiclehealthcheck.KoerPostTestResults}
 */
public class KoerPostTestResultsDto {

    private UUID id;

    private String statsDate;

    private String dtcCode;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }
}
