package com.futuresense.autonostix360.mappers.maintenancelogs.score.graphs;

import com.futuresense.autonostix360.domain.maintenancelogs.score.graphs.MaintenanceLogsGraphsThresholds;
import com.futuresense.autonostix360.dto.maintenancelogs.score.graphs.MaintenanceLogsGraphsThresholdsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class MaintenanceLogsGraphsThresholdsMapper implements EntityMapper<MaintenanceLogsGraphsThresholds, MaintenanceLogsGraphsThresholdsDto> {
    @Override
    public MaintenanceLogsGraphsThresholds buildEntity(MaintenanceLogsGraphsThresholdsDto dto) {
        final MaintenanceLogsGraphsThresholds entity = new MaintenanceLogsGraphsThresholds();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setGraphName(dto.getGraphName());
        entity.setThresholdStart(dto.getThresholdStart());
        entity.setThresholdEnd(dto.getThresholdEnd());

        return entity;
    }

    @Override
    public String dtoClassName() {
        return MaintenanceLogsGraphsThresholdsDto.class.getCanonicalName();
    }

    @Override
    public MaintenanceLogsGraphsThresholdsDto buildDto(MaintenanceLogsGraphsThresholds entity) {
        final MaintenanceLogsGraphsThresholdsDto dto = new MaintenanceLogsGraphsThresholdsDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setGraphName(entity.getGraphName());
        dto.setThresholdStart(entity.getThresholdStart());
        dto.setThresholdEnd(entity.getThresholdEnd());

        return dto;
    }

    @Override
    public String entityClassName() {
        return MaintenanceLogsGraphsThresholds.class.getCanonicalName();
    }
}