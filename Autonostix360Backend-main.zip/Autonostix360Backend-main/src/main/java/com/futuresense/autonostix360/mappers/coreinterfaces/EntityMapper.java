package com.futuresense.autonostix360.mappers.coreinterfaces;

public interface EntityMapper<E, D> extends IDtoToEntity<E, D>, IEntityToDto<E, D> {
}
