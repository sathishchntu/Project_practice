package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.BatteryEnergyConsumptionAtKeyOffByLastMiles;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.BatteryEnergyConsumptionAtKeyOffByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class BatteryEnergyConsumptionAtKeyOffByLastMilesMapper implements EntityMapper<BatteryEnergyConsumptionAtKeyOffByLastMiles, BatteryEnergyConsumptionAtKeyOffByLastMilesDto> {

    @Override
    public BatteryEnergyConsumptionAtKeyOffByLastMiles buildEntity(BatteryEnergyConsumptionAtKeyOffByLastMilesDto dto) {
        final BatteryEnergyConsumptionAtKeyOffByLastMiles entity = new BatteryEnergyConsumptionAtKeyOffByLastMiles();
        entity.setId(dto.getId());
        entity.setBatteryEnergyConsumptionWH(dto.getBatteryEnergyConsumptionWH());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return BatteryEnergyConsumptionAtKeyOffByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public BatteryEnergyConsumptionAtKeyOffByLastMilesDto buildDto(BatteryEnergyConsumptionAtKeyOffByLastMiles entity) {
        final BatteryEnergyConsumptionAtKeyOffByLastMilesDto dto = new BatteryEnergyConsumptionAtKeyOffByLastMilesDto();
        dto.setId(entity.getId());
        dto.setBatteryEnergyConsumptionWH(entity.getBatteryEnergyConsumptionWH());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());

        return dto;
    }

    @Override
    public String entityClassName() {
        return BatteryEnergyConsumptionAtKeyOffByLastMiles.class.getCanonicalName();
    }
}
