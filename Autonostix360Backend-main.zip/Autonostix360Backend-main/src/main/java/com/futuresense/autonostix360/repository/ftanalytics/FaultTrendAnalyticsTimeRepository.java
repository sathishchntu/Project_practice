package com.futuresense.autonostix360.repository.ftanalytics;

import com.futuresense.autonostix360.domain.ftanalytics.FaultTrendAnalyticsTime;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

/**
 * FaultTrendAnalyticsTimeRepository
 */
public interface FaultTrendAnalyticsTimeRepository extends CassandraRepository<FaultTrendAnalyticsTime, String> {

    @Query(value = "select * from fault_trend_analytics_time " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_time_hours >= :fromRulTimeHours and rul_time_hours <= :toRulTimeHours")
    Slice<FaultTrendAnalyticsTime> findByVinNumberAndOrganizationIdAndRulTimeRange(String vinNumber, Integer organizationId, Double fromRulTimeHours, Double toRulTimeHours, Pageable pageable);

    @Query(value = "select count(*) from fault_trend_analytics_time " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_time_hours >= :fromRulTimeHours and rul_time_hours <= :toRulTimeHours")
    int pageCount(String vinNumber, Integer organizationId, Double fromRulTimeHours, Double toRulTimeHours);


    @Query(value = "select * from fault_trend_analytics_time " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_time_hours >= :fromRulTimeHours and rul_time_hours <= :toRulTimeHours")
    Slice<FaultTrendAnalyticsTime> findAllByVinNumberAndOrganizationIdAndRulTimeRange(CassandraPageRequest pageRequest, String vinNumber, Integer organizationId, Double fromRulTimeHours, Double toRulTimeHours);
}