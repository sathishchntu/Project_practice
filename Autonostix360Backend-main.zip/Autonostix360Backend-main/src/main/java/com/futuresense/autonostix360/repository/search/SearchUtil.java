package com.futuresense.autonostix360.repository.search;

import com.futuresense.autonostix360.domain.maintenancelogs.MaintenanceLogs;
import com.futuresense.autonostix360.domain.search.MaintenanceLog;
import com.futuresense.autonostix360.dto.search.FilterSearchDto;
import com.futuresense.autonostix360.dto.search.MaintenanceLogsSearchDto;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.index.query.*;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.data.domain.Pageable;
import org.tinylog.Logger;

import static com.futuresense.autonostix360.util.Indices.MAINTENANCE_LOGS_INDEX;

/**
 * Util class that provides different types of search for ElasticSearch
 */
public class SearchUtil {
    //TODO: Tuhin -> this class needs some clean up.

    private SearchUtil() {
    }

    public static SearchRequest buildSearchRequest(final String indexName,
                                                   final ElasticSearchDTO dto,
                                                   final MaintenanceLogsSearchDto maintenanceLogsSearchDto,
                                                   Pageable pageable) {
        try {
            final int page = pageable.getPageNumber();
            final int size = pageable.getPageSize();
            final int from = page <= 0 ? 0 : pageable.getPageSize();

            return prepareSearchQuery(indexName, dto, maintenanceLogsSearchDto, size, from);
        } catch (final Exception e) {
            Logger.error("error {}", e.getMessage());
            return null;
        }
    }

    public static SearchRequest buildSearchRequestForHitCount(final String indexName,
                                                              final ElasticSearchDTO dto,
                                                              final MaintenanceLogsSearchDto maintenanceLogsSearchDto) {
        try {
            final int size = -1;
            final int from = -1;

            return prepareSearchQuery(indexName, dto, maintenanceLogsSearchDto, size, from);
        } catch (final Exception e) {
            Logger.error("error {}", e.getMessage());
            return null;
        }
    }

    private static SearchRequest prepareSearchQuery(String indexName, ElasticSearchDTO dto, MaintenanceLogsSearchDto maintenanceLogsSearchDto, int size, int from) {

        SearchRequest searchRequest = getSearchRequest(indexName);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();

        final QueryBuilder vinQuery = QueryBuilders.termQuery("vinNumber.keyword", maintenanceLogsSearchDto.getVinNumber());
        final QueryBuilder orgIdQuery = QueryBuilders.termQuery("organizationId", maintenanceLogsSearchDto.getOrganizationId());

        boolQueryBuilder.must(vinQuery);
        boolQueryBuilder.must(orgIdQuery);

        boolQueryBuilder.minimumShouldMatch(1);

        if (dto.getMultiMatchFields() != null && dto.getMultiMatchFields().size() > 0) {
            Logger.debug("MultiMatchQueryBuilder");
            MultiMatchQueryBuilder multiMatchQueryBuilder = new MultiMatchQueryBuilder(dto.getSearchTerm(), dto.getMultiMatchFields().toArray(new String[0]));
            multiMatchQueryBuilder.operator(Operator.OR);
            boolQueryBuilder.should(multiMatchQueryBuilder);
        }

        if (dto.getWildCardFields() != null && dto.getWildCardFields().size() > 0) {
            dto.getWildCardFields().forEach(wildcard -> {
                Logger.debug("wildcardQuery");
                boolQueryBuilder.should(QueryBuilders.wildcardQuery(wildcard, "*" + dto.getSearchTerm() + "*"));
            });
        }

        searchSourceBuilder.query(boolQueryBuilder);

        if (from > 0 && size > 0) {
            searchSourceBuilder
                    .from(from)
                    .size(size);
        }

        searchSourceBuilder.sort(SortBuilders.fieldSort("statsDate")
                                         .order(SortOrder.DESC));

        return searchRequest.source(searchSourceBuilder);
    }

    public static MaintenanceLog elasticSearchMaintenanceLogObject(MaintenanceLogs savedEntity) {
        MaintenanceLog maintenanceLog = new MaintenanceLog();
        maintenanceLog.setId(String.valueOf(savedEntity.getId()));
        maintenanceLog.setMaintenanceActivity(savedEntity.getMaintenanceActivity());
        maintenanceLog.setVinNumber(savedEntity.getVinNumber());
        maintenanceLog.setOrganizationId(savedEntity.getOrganizationId());
        maintenanceLog.setPartitionYear(savedEntity.getPartitionYear());
        maintenanceLog.setDtcCode(savedEntity.getDtcCode());
        maintenanceLog.setSubSystem(savedEntity.getSubSystem());
        maintenanceLog.setDescription(savedEntity.getDescription());
        maintenanceLog.setOdometer(savedEntity.getOdometer());
        maintenanceLog.setStatsDate(savedEntity.getStatsDate());
        return maintenanceLog;
    }

    public static SearchRequest prepareSearchRequestForFilter(FilterSearchDto searchDto, int size, int from) {
        SearchRequest searchRequest = getSearchRequest(MAINTENANCE_LOGS_INDEX);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();

        final QueryBuilder vinQuery = QueryBuilders.termQuery("vinNumber.keyword", searchDto.getVinNumber());
        final QueryBuilder orgIdQuery = QueryBuilders.termQuery("organizationId", searchDto.getOrganizationId());

        boolQueryBuilder.must(vinQuery);
        boolQueryBuilder.must(orgIdQuery);

        boolQueryBuilder.minimumShouldMatch(1);

        if (searchDto.getDtcCodes() != null && searchDto.getDtcCodes().length > 0) {
            boolQueryBuilder.should(QueryBuilders.termsQuery("dtcCode.keyword", searchDto.getDtcCodes()));
        }

        if (searchDto.getSubSystems() != null && searchDto.getSubSystems().length > 0) {
            boolQueryBuilder.should(QueryBuilders.termsQuery("subSystem.keyword", searchDto.getSubSystems()));
        }

        searchSourceBuilder.query(boolQueryBuilder);

        searchSourceBuilder
                .from(from)
                .size(size);

        searchSourceBuilder.sort(SortBuilders.fieldSort("statsDate")
                                         .order(SortOrder.DESC));

        SearchRequest source1 = searchRequest.source(searchSourceBuilder);
        return source1;
    }

    private static SearchRequest getSearchRequest(String maintenanceLogsIndex) {
        SearchRequest searchRequest = new SearchRequest(maintenanceLogsIndex);
        return searchRequest;
    }

    public static SearchRequest getFilterSearchRequestForCounts(FilterSearchDto searchDto) {
        SearchRequest searchRequest = getSearchRequest(MAINTENANCE_LOGS_INDEX);

        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();

        final QueryBuilder vinQuery = QueryBuilders.termQuery("vinNumber.keyword", searchDto.getVinNumber());
        final QueryBuilder orgIdQuery = QueryBuilders.termQuery("organizationId", searchDto.getOrganizationId());

        boolQueryBuilder.must(vinQuery);
        boolQueryBuilder.must(orgIdQuery);

        boolQueryBuilder.minimumShouldMatch(1);

        if (searchDto.getDtcCodes() != null && searchDto.getDtcCodes().length > 0) {
            boolQueryBuilder.should(QueryBuilders.termsQuery("dtcCode.keyword", searchDto.getDtcCodes()));
        }

        if (searchDto.getSubSystems() != null && searchDto.getSubSystems().length > 0) {
            boolQueryBuilder.should(QueryBuilders.termsQuery("subSystem.keyword", searchDto.getSubSystems()));
        }

        searchSourceBuilder.query(boolQueryBuilder);

        searchSourceBuilder.sort(SortBuilders.fieldSort("statsDate")
                                         .order(SortOrder.DESC));

        SearchRequest source = searchRequest.source(searchSourceBuilder);
        return source;
    }
}
