package com.futuresense.autonostix360.mappers.maintenancelogs;

import com.futuresense.autonostix360.domain.maintenancelogs.MaintenanceLogs;
import com.futuresense.autonostix360.dto.maintenancelogs.MaintenanceLogsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class MaintenanceLogsMapper implements EntityMapper<MaintenanceLogs, MaintenanceLogsDto> {
    @Override
    public MaintenanceLogs buildEntity(MaintenanceLogsDto dto) {
        final MaintenanceLogs entity = new MaintenanceLogs();
        entity.setId(dto.getId());
        entity.setMaintenanceActivity(dto.getMaintenanceActivity());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setPartitionYear(String.valueOf(LocalDate.now().getYear()));
        entity.setDtcCode(StringUtils.isNotEmpty(dto.getDtcCode()) ? dto.getDtcCode() : "");
        entity.setSubSystem(StringUtils.isNotEmpty(dto.getSubSystem()) ? dto.getSubSystem() : "");
        entity.setDescription(StringUtils.isNotEmpty(dto.getDescription()) ? dto.getDescription() : "");
        entity.setOdometer(dto.getOdometer());
        Timestamp timestamp = Timestamp.from(Instant.now());
        entity.setLastUpdated(timestamp);
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return MaintenanceLogsDto.class.getCanonicalName();
    }

    @Override
    public MaintenanceLogsDto buildDto(MaintenanceLogs entity) {
        final MaintenanceLogsDto dto = new MaintenanceLogsDto();
        dto.setId(entity.getId());
        dto.setMaintenanceActivity(entity.getMaintenanceActivity());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setDtcCode(entity.getDtcCode());
        dto.setSubSystem(entity.getSubSystem());
        dto.setDescription(entity.getDescription());
        dto.setOdometer(entity.getOdometer());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return MaintenanceLogs.class.getCanonicalName();
    }
}
