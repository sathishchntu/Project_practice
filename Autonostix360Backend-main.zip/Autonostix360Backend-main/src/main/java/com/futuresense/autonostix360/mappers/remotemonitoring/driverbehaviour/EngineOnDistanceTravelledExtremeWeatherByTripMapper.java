package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.EngineOnDistanceTravelledExtremeWeatherByTrip;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.EngineOnDistanceTravelledExtremeWeatherByTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineOnDistanceTravelledExtremeWeatherByTripMapper implements EntityMapper<EngineOnDistanceTravelledExtremeWeatherByTrip, EngineOnDistanceTravelledExtremeWeatherByTripDto> {

    @Override
    public EngineOnDistanceTravelledExtremeWeatherByTrip buildEntity(EngineOnDistanceTravelledExtremeWeatherByTripDto dto) {
        final EngineOnDistanceTravelledExtremeWeatherByTrip entity = new EngineOnDistanceTravelledExtremeWeatherByTrip();
        entity.setId(dto.getId());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineOnDistanceTravelledExtremeWeatherByTripDto.class.getCanonicalName();
    }

    @Override
    public EngineOnDistanceTravelledExtremeWeatherByTripDto buildDto(EngineOnDistanceTravelledExtremeWeatherByTrip entity) {
        final EngineOnDistanceTravelledExtremeWeatherByTripDto dto = new EngineOnDistanceTravelledExtremeWeatherByTripDto();
        dto.setId(entity.getId());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineOnDistanceTravelledExtremeWeatherByTrip.class.getCanonicalName();
    }
}