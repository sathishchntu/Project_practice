package com.futuresense.autonostix360.repository.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TransmissionOilTemperatureByLastDate;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.Date;
import java.util.List;

/**
 * TransmissionOilTemperatureByLastDateRepository
 */
public interface TransmissionOilTemperatureByLastDateRepository extends CassandraRepository<TransmissionOilTemperatureByLastDate, String> {

    @Query(value = "select * from transmission_oil_temperature_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date = :dateString")
    List<TransmissionOilTemperatureByLastDate> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, Date dateString);

    @Query(value = "select * from transmission_oil_temperature_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    List<TransmissionOilTemperatureByLastDate> findAllByVinNumberAndOrganizationId(String vinNumber, Integer organizationId);

    @Query(value = "select * from transmission_oil_temperature_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date > :fromDate and stats_date <= :toDate")
    List<TransmissionOilTemperatureByLastDate> findByVinNumberAndOrganizationIdAndStatsDateRange(String vinNumber, Integer organizationId, Date fromDate, Date toDate);
}
