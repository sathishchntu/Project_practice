package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.TrafficSignalViolationByMiles;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * TrafficSignalViolationByMilesRepository
 */
public interface TrafficSignalViolationByMilesRepository extends CassandraRepository<TrafficSignalViolationByMiles, String> {

    @Query("select * from traffic_signal_violation_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    List<TrafficSignalViolationByMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId);

    @Query("select max(odometer) from traffic_signal_violation_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    Integer findMaxOdometerReadingByVinAndOrganizationId(String vinNumber, Integer organizationId);

    @Query("select * from traffic_signal_violation_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and odometer >= :fromOdometerReading and odometer <= :maxOdometerReading")
    List<TrafficSignalViolationByMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId, int fromOdometerReading, Integer maxOdometerReading);
}