package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineOilLevelByLastMiles;
import com.futuresense.autonostix360.dto.usageprofile.EngineOilLevelByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineOilLevelByLastMilesMapper implements EntityMapper<EngineOilLevelByLastMiles, EngineOilLevelByLastMilesDto> {
    @Override
    public EngineOilLevelByLastMiles buildEntity(EngineOilLevelByLastMilesDto dto) {
        final EngineOilLevelByLastMiles entity = new EngineOilLevelByLastMiles();
        entity.setId(dto.getId());
        entity.setEngineOilLevel(dto.getEngineOilLevel());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineOilLevelByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public EngineOilLevelByLastMilesDto buildDto(EngineOilLevelByLastMiles entity) {
        final EngineOilLevelByLastMilesDto dto = new EngineOilLevelByLastMilesDto();
        dto.setId(entity.getId());
        dto.setEngineOilLevel(entity.getEngineOilLevel());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineOilLevelByLastMiles.class.getCanonicalName();
    }
}
