package com.futuresense.autonostix360.repository.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.BatteryEnergyConsumptionAtKeyOffByLastMiles;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * BatteryEnergyConsumptionAtKeyOffByLastMilesRepository
 */
public interface BatteryEnergyConsumptionAtKeyOffByLastMilesRepository extends CassandraRepository<BatteryEnergyConsumptionAtKeyOffByLastMiles, Long> {
    @Query("select * from battery_energy_consumption_at_key_off_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    List<BatteryEnergyConsumptionAtKeyOffByLastMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId);

    @Query("select max(odometer) from battery_energy_consumption_at_key_off_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    Integer findMaxOdometerReadingByVinAndOrganizationId(String vinNumber, Integer organizationId);

    @Query("select * from battery_energy_consumption_at_key_off_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and odometer >= :fromOdometerReading and odometer <= :maxOdometerReading")
    List<BatteryEnergyConsumptionAtKeyOffByLastMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId, int fromOdometerReading, Integer maxOdometerReading);


}
