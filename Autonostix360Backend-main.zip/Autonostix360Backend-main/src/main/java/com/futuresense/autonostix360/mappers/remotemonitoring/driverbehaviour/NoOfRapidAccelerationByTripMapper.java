package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfRapidAccelerationByTrip;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfRapidAccelerationByTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfRapidAccelerationByTripMapper implements EntityMapper<NoOfRapidAccelerationByTrip, NoOfRapidAccelerationByTripDto> {

    @Override
    public NoOfRapidAccelerationByTrip buildEntity(NoOfRapidAccelerationByTripDto dto) {
        final NoOfRapidAccelerationByTrip entity = new NoOfRapidAccelerationByTrip();
        entity.setId(dto.getId());
        entity.setTrip(dto.getTrip());
        entity.setNoOfRapidAcceleration(dto.getNoOfRapidAcceleration());
        entity.setHours(dto.getHours());
        entity.setMiles(dto.getMiles());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return NoOfRapidAccelerationByTripDto.class.getCanonicalName();
    }

    @Override
    public NoOfRapidAccelerationByTripDto buildDto(NoOfRapidAccelerationByTrip entity) {
        final NoOfRapidAccelerationByTripDto dto = new NoOfRapidAccelerationByTripDto();
        dto.setId(entity.getId());
        dto.setTrip(entity.getTrip());
        dto.setNoOfRapidAcceleration(entity.getNoOfRapidAcceleration());
        dto.setHours(entity.getHours());
        dto.setMiles(entity.getMiles());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfRapidAccelerationByTrip.class.getCanonicalName();
    }
}