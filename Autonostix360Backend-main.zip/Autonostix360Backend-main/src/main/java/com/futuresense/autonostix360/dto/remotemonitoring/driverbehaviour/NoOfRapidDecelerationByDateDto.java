package com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfRapidDecelerationByDate}.
 */
public class NoOfRapidDecelerationByDateDto implements Serializable {

    private UUID id;

    private Date statsDate;

    private Integer noOfRapidDeceleration;

    private Double hours;

    private Integer miles;

    private Integer engineRunTime;

    private Integer keyStarts;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Date getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(Date statsDate) {
        this.statsDate = statsDate;
    }

    public Integer getNoOfRapidDeceleration() {
        return noOfRapidDeceleration;
    }

    public void setNoOfRapidDeceleration(Integer noOfRapidDeceleration) {
        this.noOfRapidDeceleration = noOfRapidDeceleration;
    }

    public Double getHours() {
        return hours;
    }

    public void setHours(Double hours) {
        this.hours = hours;
    }

    public Integer getEngineRunTime() {
        return engineRunTime;
    }

    public void setEngineRunTime(Integer engineRunTime) {
        this.engineRunTime = engineRunTime;
    }

    public Integer getKeyStarts() {
        return keyStarts;
    }

    public void setKeyStarts(Integer keyStarts) {
        this.keyStarts = keyStarts;
    }

    public Integer getMiles() {
        return miles;
    }

    public void setMiles(Integer miles) {
        this.miles = miles;
    }
}