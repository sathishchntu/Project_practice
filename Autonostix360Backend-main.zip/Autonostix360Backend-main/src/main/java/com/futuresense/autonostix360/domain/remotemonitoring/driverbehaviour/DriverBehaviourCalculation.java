package com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour;

import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entity DriverBehaviourCalculation represents table driver_behaviour_calculation
 */
@Table(value = "driver_behaviour_calculation")
public class DriverBehaviourCalculation {

    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("stats_date")
    private String statsDate;

    @Column("property")
    private String property;

    @Column("property_value")
    private Double propertyValue;

    @Column("color")
    private String color;

    @Column("elementary_score")
    private Integer elementaryScore;

    @Column("weight_of_element")
    private Integer weightOfElement;

    @Column("total")
    private Double total;

    @Column("total_possible")
    private Double totalPossible;

    @Column("odometer")
    private Integer odometer;

    @Column("last_updated")
    private Timestamp lastUpdated;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public Double getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(Double propertyValue) {
        this.propertyValue = propertyValue;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getElementaryScore() {
        return elementaryScore;
    }

    public void setElementaryScore(Integer elementaryScore) {
        this.elementaryScore = elementaryScore;
    }

    public Integer getWeightOfElement() {
        return weightOfElement;
    }

    public void setWeightOfElement(Integer weightOfElement) {
        this.weightOfElement = weightOfElement;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Double getTotalPossible() {
        return totalPossible;
    }

    public void setTotalPossible(Double totalPossible) {
        this.totalPossible = totalPossible;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
