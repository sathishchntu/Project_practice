package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.EngineFuelConsumptionByLastDate;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.EngineFuelConsumptionByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineFuelConsumptionByLastDateMapper implements EntityMapper<EngineFuelConsumptionByLastDate, EngineFuelConsumptionByLastDateDto> {

    @Override
    public EngineFuelConsumptionByLastDate buildEntity(EngineFuelConsumptionByLastDateDto dto) {
        final EngineFuelConsumptionByLastDate entity = new EngineFuelConsumptionByLastDate();
        entity.setId(dto.getId());
        entity.setAverageFuelConsumption(dto.getAverageFuelConsumption());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineFuelConsumptionByLastDateDto.class.getCanonicalName();
    }

    @Override
    public EngineFuelConsumptionByLastDateDto buildDto(EngineFuelConsumptionByLastDate entity) {
        final EngineFuelConsumptionByLastDateDto dto = new EngineFuelConsumptionByLastDateDto();
        dto.setId(entity.getId());
        dto.setAverageFuelConsumption(entity.getAverageFuelConsumption());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setStatsDate(entity.getStatsDate());

        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineFuelConsumptionByLastDate.class.getCanonicalName();
    }
}
