package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfRapidDecelerationByTrip;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfRapidDecelerationByTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfRapidDecelerationByTripMapper implements EntityMapper<NoOfRapidDecelerationByTrip, NoOfRapidDecelerationByTripDto> {

    @Override
    public NoOfRapidDecelerationByTrip buildEntity(NoOfRapidDecelerationByTripDto dto) {
        final NoOfRapidDecelerationByTrip entity = new NoOfRapidDecelerationByTrip();
        entity.setId(dto.getId());
        entity.setTrip(dto.getTrip());
        entity.setNoOfRapidDeceleration(dto.getNoOfRapidDeceleration());
        entity.setHours(dto.getHours());
        entity.setMiles(dto.getMiles());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return NoOfRapidDecelerationByTripDto.class.getCanonicalName();
    }

    @Override
    public NoOfRapidDecelerationByTripDto buildDto(NoOfRapidDecelerationByTrip entity) {
        final NoOfRapidDecelerationByTripDto dto = new NoOfRapidDecelerationByTripDto();
        dto.setId(entity.getId());
        dto.setTrip(entity.getTrip());
        dto.setNoOfRapidDeceleration(entity.getNoOfRapidDeceleration());
        dto.setHours(entity.getHours());
        dto.setMiles(entity.getMiles());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfRapidDecelerationByTrip.class.getCanonicalName();
    }
}
