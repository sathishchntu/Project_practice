package com.futuresense.autonostix360.repository.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineOilLevelByLastTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * EngineOilLevelByLastTripRepository
 */
public interface EngineOilLevelByLastTripRepository extends CassandraRepository<EngineOilLevelByLastTrip, Long> {

    @Query(value = "select max(trip) from engine_oil_level_by_last_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from engine_oil_level_by_last_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<EngineOilLevelByLastTrip> findEngineOilLevelByLastTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}
