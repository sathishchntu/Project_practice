package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.TrafficSignalViolationByDate;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.TrafficSignalViolationByDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TrafficSignalViolationByDateMapper implements EntityMapper<TrafficSignalViolationByDate, TrafficSignalViolationByDateDto> {

    @Override
    public TrafficSignalViolationByDate buildEntity(TrafficSignalViolationByDateDto dto) {
        TrafficSignalViolationByDate entity = new TrafficSignalViolationByDate();
        entity.setId(dto.getId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setNoOfSignalViolation(dto.getNoOfSignalViolation());
        entity.setHours(dto.getHours());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TrafficSignalViolationByDateDto.class.getCanonicalName();
    }

    @Override
    public TrafficSignalViolationByDateDto buildDto(TrafficSignalViolationByDate entity) {
        TrafficSignalViolationByDateDto dto = new TrafficSignalViolationByDateDto();
        dto.setId(entity.getId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setNoOfSignalViolation(entity.getNoOfSignalViolation());
        dto.setHours(entity.getHours());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TrafficSignalViolationByDate.class.getCanonicalName();
    }
}
