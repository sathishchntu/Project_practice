package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TransmissionOilTemperatureByLastDate;
import com.futuresense.autonostix360.dto.usageprofile.TransmissionOilTemperatureByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TransmissionOilTemperatureByLastDateMapper implements EntityMapper<TransmissionOilTemperatureByLastDate, TransmissionOilTemperatureByLastDateDto> {

    @Override
    public TransmissionOilTemperatureByLastDate buildEntity(TransmissionOilTemperatureByLastDateDto dto) {
        final TransmissionOilTemperatureByLastDate entity = new TransmissionOilTemperatureByLastDate();
        entity.setId(dto.getId());
        entity.setTransmissionOilTemperatureFahrenheit(dto.getTransmissionOilTemperatureFahrenheit());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TransmissionOilTemperatureByLastDateDto.class.getCanonicalName();
    }

    @Override
    public TransmissionOilTemperatureByLastDateDto buildDto(TransmissionOilTemperatureByLastDate entity) {
        final TransmissionOilTemperatureByLastDateDto dto = new TransmissionOilTemperatureByLastDateDto();
        dto.setId(entity.getId());
        dto.setTransmissionOilTemperatureFahrenheit(entity.getTransmissionOilTemperatureFahrenheit());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TransmissionOilTemperatureByLastDate.class.getCanonicalName();
    }
}
