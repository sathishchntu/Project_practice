package com.futuresense.autonostix360.mappers.mod;

import com.futuresense.autonostix360.domain.mod.RoutineMaintenance;
import com.futuresense.autonostix360.dto.mod.RoutineMaintenanceDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class RoutineMaintenanceMapper implements EntityMapper<RoutineMaintenance, RoutineMaintenanceDto> {
    @Override
    public RoutineMaintenance buildEntity(RoutineMaintenanceDto dto) {
        final RoutineMaintenance entity = new RoutineMaintenance();
        entity.setId(dto.getId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setAttributeName(dto.getAttributeName());
        entity.setStatus(dto.getStatus());
        entity.setAttributeValue(dto.getAttributeValue());
        entity.setLowerLimit(dto.getLowerLimit());
        entity.setUpperLimit(dto.getUpperLimit());
        entity.setMessage(dto.getMessage());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return RoutineMaintenanceDto.class.getCanonicalName();
    }

    @Override
    public RoutineMaintenanceDto buildDto(RoutineMaintenance entity) {
        final RoutineMaintenanceDto dto = new RoutineMaintenanceDto();
        dto.setId(entity.getId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setAttributeName(entity.getAttributeName());
        dto.setStatus(entity.getStatus());
        dto.setAttributeValue(entity.getAttributeValue());
        dto.setLowerLimit(entity.getLowerLimit());
        dto.setUpperLimit(entity.getUpperLimit());
        dto.setMessage(entity.getMessage());
        return dto;
    }

    @Override
    public String entityClassName() {
        return RoutineMaintenance.class.getCanonicalName();
    }
}
