package com.futuresense.autonostix360.repository.mod;

import com.futuresense.autonostix360.domain.mod.RoutineMaintenance;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;
import java.util.UUID;

/**
 * RoutineMaintenance repository
 */
public interface RoutineMaintenanceRepository extends CassandraRepository<RoutineMaintenance, UUID> {

    @Query(value = "select * from routine_maintenance where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    List<RoutineMaintenance> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, String statsDate);
}
