package com.futuresense.autonostix360.mappers.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.Quality;
import com.futuresense.autonostix360.dto.maintenancelogs.score.QualityDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class QualityMapper implements EntityMapper<Quality, QualityDto> {
    @Override
    public Quality buildEntity(QualityDto dto) {
        final Quality entity = new Quality();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setStatsDate(dto.getStatsDate());
        entity.setWeighingFactor(dto.getWeighingFactor());
        entity.setVehicleCompatibleComponents(dto.getVehicleCompatibleComponents());
        entity.setComponentReplaced(dto.getComponentReplaced());
        entity.setActualReplacedComponents(dto.getActualReplacedComponents());
        entity.setViolation(dto.getViolation());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return QualityDto.class.getCanonicalName();
    }

    @Override
    public QualityDto buildDto(Quality entity) {
        final QualityDto dto = new QualityDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setStatsDate(entity.getStatsDate());
        dto.setVehicleCompatibleComponents(entity.getVehicleCompatibleComponents());
        dto.setWeighingFactor(entity.getWeighingFactor());
        dto.setActualReplacedComponents(entity.getActualReplacedComponents());
        dto.setComponentReplaced(entity.getComponentReplaced());
        dto.setViolation(entity.getViolation());
        return dto;
    }

    @Override
    public String entityClassName() {
        return Quality.class.getCanonicalName();
    }
}
