package com.futuresense.autonostix360.dto.ftanalytics.graphs;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

/**
 * Dto class for entity FaultTrendAnalyticsRulGraphsThresholds entity
 */
public class FaultTrendAnalyticsRulGraphsThresholdsDto implements Serializable {

    private UUID id;

    private String vinNumber;

    private Integer organizationId;

    private String statsDate;

    private String dtcCode;

    private String graphName;

    private Timestamp lastUpdated;

    private List<Double> thresholdStart;

    private List<Double> thresholdEnd;

    private String units;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getGraphName() {
        return graphName;
    }

    public void setGraphName(String graphName) {
        this.graphName = graphName;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public List<Double> getThresholdStart() {
        return thresholdStart;
    }

    public void setThresholdStart(List<Double> thresholdStart) {
        this.thresholdStart = thresholdStart;
    }

    public List<Double> getThresholdEnd() {
        return thresholdEnd;
    }

    public void setThresholdEnd(List<Double> thresholdEnd) {
        this.thresholdEnd = thresholdEnd;
    }

    public String getUnits() {
        return units;
    }

    public void setUnits(String units) {
        this.units = units;
    }
}