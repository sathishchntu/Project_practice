package com.futuresense.autonostix360.repository.maintenancelogs.score.graphs;

import com.futuresense.autonostix360.domain.maintenancelogs.score.graphs.MaintenanceLogsGraphs;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * Repository for MaintenanceLogsGraphs
 */
public interface MaintenanceLogsGraphsRepository extends CassandraRepository<MaintenanceLogsGraphs, String> {

    @Query(value = "select * from maintenance_logs_graphs " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate " +
            "and graph_name = :graphName")
    List<MaintenanceLogsGraphs> findByVinNumberAndOrganizationIdAndStatsDateAndGraphName(final String vinNumber,
                                                                                         final Integer organizationId, final
                                                                                         String statsDate, final String graphName);
}
