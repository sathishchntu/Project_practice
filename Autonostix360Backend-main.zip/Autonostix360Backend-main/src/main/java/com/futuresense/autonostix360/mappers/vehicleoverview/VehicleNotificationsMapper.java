package com.futuresense.autonostix360.mappers.vehicleoverview;

import com.futuresense.autonostix360.domain.vehicleoverview.VehicleNotifications;
import com.futuresense.autonostix360.dto.vehicleoverview.VehicleNotificationDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class VehicleNotificationsMapper implements EntityMapper<VehicleNotifications, VehicleNotificationDto> {
    @Override
    public VehicleNotifications buildEntity(VehicleNotificationDto dto) {
        final VehicleNotifications entity = new VehicleNotifications();
        entity.setId(dto.getId());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setStatsDate(dto.getStatsDate());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setOdometer(dto.getOdometer());
        entity.setDtc(dto.getDtc());
        entity.setNotificationType(dto.getNotificationType());
        entity.setIssue(dto.getIssue());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return VehicleNotificationDto.class.getCanonicalName();
    }

    @Override
    public VehicleNotificationDto buildDto(VehicleNotifications entity) {
        final VehicleNotificationDto dto = new VehicleNotificationDto();
        dto.setId(entity.getId());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setStatsDate(entity.getStatsDate());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setDtc(entity.getDtc());
        dto.setNotificationType(entity.getNotificationType());
        dto.setOdometer(entity.getOdometer());
        dto.setIssue(entity.getIssue());
        return dto;
    }

    @Override
    public String entityClassName() {
        return VehicleNotifications.class.getCanonicalName();
    }
}
