package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TirePressureByLastDate;
import com.futuresense.autonostix360.dto.usageprofile.TirePressureByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TirePressureByLastDateMapper implements EntityMapper<TirePressureByLastDate, TirePressureByLastDateDto> {

    @Override
    public TirePressureByLastDate buildEntity(TirePressureByLastDateDto dto) {
        final TirePressureByLastDate entity = new TirePressureByLastDate();
        entity.setId(dto.getId());
        entity.setTirePressurePsi(dto.getTirePressurePsi());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TirePressureByLastDateDto.class.getCanonicalName();
    }

    @Override
    public TirePressureByLastDateDto buildDto(TirePressureByLastDate entity) {
        final TirePressureByLastDateDto dto = new TirePressureByLastDateDto();
        dto.setId(entity.getId());
        dto.setTirePressurePsi(entity.getTirePressurePsi());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TirePressureByLastDate.class.getCanonicalName();
    }
}
