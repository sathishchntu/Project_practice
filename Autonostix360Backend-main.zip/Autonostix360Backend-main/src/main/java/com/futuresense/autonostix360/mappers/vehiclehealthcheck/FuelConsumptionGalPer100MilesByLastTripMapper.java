package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.FuelConsumptionGalPer100MilesByLastTrip;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.FuelConsumptionGalPer100MilesByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class FuelConsumptionGalPer100MilesByLastTripMapper implements EntityMapper<FuelConsumptionGalPer100MilesByLastTrip, FuelConsumptionGalPer100MilesByLastTripDto> {

    @Override
    public FuelConsumptionGalPer100MilesByLastTrip buildEntity(FuelConsumptionGalPer100MilesByLastTripDto dto) {
        final FuelConsumptionGalPer100MilesByLastTrip entity = new FuelConsumptionGalPer100MilesByLastTrip();
        entity.setId(dto.getId());
        entity.setGalPer100Miles(dto.getGalPer100Miles());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());

        return entity;
    }

    @Override
    public String dtoClassName() {
        return FuelConsumptionGalPer100MilesByLastTripDto.class.getCanonicalName();
    }

    @Override
    public FuelConsumptionGalPer100MilesByLastTripDto buildDto(FuelConsumptionGalPer100MilesByLastTrip entity) {
        final FuelConsumptionGalPer100MilesByLastTripDto dto = new FuelConsumptionGalPer100MilesByLastTripDto();
        dto.setId(entity.getId());
        dto.setGalPer100Miles(entity.getGalPer100Miles());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());

        return dto;
    }

    @Override
    public String entityClassName() {
        return FuelConsumptionGalPer100MilesByLastTrip.class.getCanonicalName();
    }
}
