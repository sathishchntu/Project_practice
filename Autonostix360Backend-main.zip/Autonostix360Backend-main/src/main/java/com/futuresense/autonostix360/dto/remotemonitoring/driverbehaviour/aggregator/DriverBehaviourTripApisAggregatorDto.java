package com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.aggregator;

import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.*;

import java.io.Serializable;
import java.util.List;

/**
 * Dto class for aggregated api for Driver Behaviour Trip apis
 */
public class DriverBehaviourTripApisAggregatorDto implements Serializable {

    private List<DrivingUnpavedRoadRouteAdherenceByTripDto> drivingUnpavedRoadRouteAdherenceByTrips;

    private List<TrafficSignalViolationByTripDto> trafficSignalViolationByTrips;

    private List<StopSignViolationByTripDto> stopSignViolationByTrips;

    private List<EngineRunTimeDistanceTravelledByTripDto> engineRunTimeDistanceTravelledByTrips;

    private List<NoOfHarshBreakingByTripDto> noOfHarshBreakingByTrips;

    private List<NoOfHarshCorneringByTripDto> noOfHarshCorneringByTrips;

    private List<NoOfOverSpeedingEventsByTripDto> noOfOverSpeedingEventsByTrips;

    private List<MilesDrivenOverSpeedingByTripDto> milesDrivenOverSpeedingByTrips;

    private List<MilesDrivenInLaneTrackingZoneByTripDto> milesDrivenInLaneTrackingZoneByTrips;

    private List<NoOfRapidAccelerationByTripDto> noOfRapidAccelerationByTrips;

    private List<NoOfRapidDecelerationByTripDto> noOfRapidDecelerationByTrips;

    private List<EngineOnDistanceTravelledExtremeWeatherByTripDto> engineOnDistanceTravelledExtremeWeatherByTrips;

    public List<DrivingUnpavedRoadRouteAdherenceByTripDto> getDrivingUnpavedRoadRouteAdherenceByTrips() {
        return drivingUnpavedRoadRouteAdherenceByTrips;
    }

    public void setDrivingUnpavedRoadRouteAdherenceByTrips(List<DrivingUnpavedRoadRouteAdherenceByTripDto> drivingUnpavedRoadRouteAdherenceByTrips) {
        this.drivingUnpavedRoadRouteAdherenceByTrips = drivingUnpavedRoadRouteAdherenceByTrips;
    }

    public List<TrafficSignalViolationByTripDto> getTrafficSignalViolationByTrips() {
        return trafficSignalViolationByTrips;
    }

    public void setTrafficSignalViolationByTrips(List<TrafficSignalViolationByTripDto> trafficSignalViolationByTrips) {
        this.trafficSignalViolationByTrips = trafficSignalViolationByTrips;
    }

    public List<StopSignViolationByTripDto> getStopSignViolationByTrips() {
        return stopSignViolationByTrips;
    }

    public void setStopSignViolationByTrips(List<StopSignViolationByTripDto> stopSignViolationByTrips) {
        this.stopSignViolationByTrips = stopSignViolationByTrips;
    }

    public List<EngineRunTimeDistanceTravelledByTripDto> getEngineRunTimeDistanceTravelledByTrips() {
        return engineRunTimeDistanceTravelledByTrips;
    }

    public void setEngineRunTimeDistanceTravelledByTrips(List<EngineRunTimeDistanceTravelledByTripDto> engineRunTimeDistanceTravelledByTrips) {
        this.engineRunTimeDistanceTravelledByTrips = engineRunTimeDistanceTravelledByTrips;
    }

    public List<NoOfHarshBreakingByTripDto> getNoOfHarshBreakingByTrips() {
        return noOfHarshBreakingByTrips;
    }

    public void setNoOfHarshBreakingByTrips(List<NoOfHarshBreakingByTripDto> noOfHarshBreakingByTrips) {
        this.noOfHarshBreakingByTrips = noOfHarshBreakingByTrips;
    }

    public List<NoOfHarshCorneringByTripDto> getNoOfHarshCorneringByTrips() {
        return noOfHarshCorneringByTrips;
    }

    public void setNoOfHarshCorneringByTrips(List<NoOfHarshCorneringByTripDto> noOfHarshCorneringByTrips) {
        this.noOfHarshCorneringByTrips = noOfHarshCorneringByTrips;
    }

    public List<NoOfOverSpeedingEventsByTripDto> getNoOfOverSpeedingEventsByTrips() {
        return noOfOverSpeedingEventsByTrips;
    }

    public void setNoOfOverSpeedingEventsByTrips(List<NoOfOverSpeedingEventsByTripDto> noOfOverSpeedingEventsByTrips) {
        this.noOfOverSpeedingEventsByTrips = noOfOverSpeedingEventsByTrips;
    }

    public List<MilesDrivenOverSpeedingByTripDto> getMilesDrivenOverSpeedingByTrips() {
        return milesDrivenOverSpeedingByTrips;
    }

    public void setMilesDrivenOverSpeedingByTrips(List<MilesDrivenOverSpeedingByTripDto> milesDrivenOverSpeedingByTrips) {
        this.milesDrivenOverSpeedingByTrips = milesDrivenOverSpeedingByTrips;
    }

    public List<MilesDrivenInLaneTrackingZoneByTripDto> getMilesDrivenInLaneTrackingZoneByTrips() {
        return milesDrivenInLaneTrackingZoneByTrips;
    }

    public void setMilesDrivenInLaneTrackingZoneByTrips(List<MilesDrivenInLaneTrackingZoneByTripDto> milesDrivenInLaneTrackingZoneByTrips) {
        this.milesDrivenInLaneTrackingZoneByTrips = milesDrivenInLaneTrackingZoneByTrips;
    }

    public List<NoOfRapidAccelerationByTripDto> getNoOfRapidAccelerationByTrips() {
        return noOfRapidAccelerationByTrips;
    }

    public void setNoOfRapidAccelerationByTrips(List<NoOfRapidAccelerationByTripDto> noOfRapidAccelerationByTrips) {
        this.noOfRapidAccelerationByTrips = noOfRapidAccelerationByTrips;
    }

    public List<NoOfRapidDecelerationByTripDto> getNoOfRapidDecelerationByTrips() {
        return noOfRapidDecelerationByTrips;
    }

    public void setNoOfRapidDecelerationByTrips(List<NoOfRapidDecelerationByTripDto> noOfRapidDecelerationByTrips) {
        this.noOfRapidDecelerationByTrips = noOfRapidDecelerationByTrips;
    }

    public List<EngineOnDistanceTravelledExtremeWeatherByTripDto> getEngineOnDistanceTravelledExtremeWeatherByTrips() {
        return engineOnDistanceTravelledExtremeWeatherByTrips;
    }

    public void setEngineOnDistanceTravelledExtremeWeatherByTrips(List<EngineOnDistanceTravelledExtremeWeatherByTripDto> engineOnDistanceTravelledExtremeWeatherByTrips) {
        this.engineOnDistanceTravelledExtremeWeatherByTrips = engineOnDistanceTravelledExtremeWeatherByTrips;
    }
}
