package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.MilesDrivenOverSpeedingByTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * MilesDrivenOverSpeedingByTripRepository
 */
public interface MilesDrivenOverSpeedingByTripRepository extends CassandraRepository<MilesDrivenOverSpeedingByTrip, Long> {

    @Query(value = "select max(trip) from miles_driven_over_speeding_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from miles_driven_over_speeding_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<MilesDrivenOverSpeedingByTrip> findMilesDrivenOverSpeedingByTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}
