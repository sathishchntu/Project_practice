package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.FuelConsumptionGalPer100MilesByLastDate;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.FuelConsumptionGalPer100MilesByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class FuelConsumptionGalPer100MilesByLastDateMapper implements EntityMapper<FuelConsumptionGalPer100MilesByLastDate, FuelConsumptionGalPer100MilesByLastDateDto> {

    @Override
    public FuelConsumptionGalPer100MilesByLastDate buildEntity(FuelConsumptionGalPer100MilesByLastDateDto dto) {
        final FuelConsumptionGalPer100MilesByLastDate entity = new FuelConsumptionGalPer100MilesByLastDate();
        entity.setId(dto.getId());
        entity.setGalPer100Miles(dto.getGalPer100Miles());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return FuelConsumptionGalPer100MilesByLastDateDto.class.getCanonicalName();
    }

    @Override
    public FuelConsumptionGalPer100MilesByLastDateDto buildDto(FuelConsumptionGalPer100MilesByLastDate entity) {
        final FuelConsumptionGalPer100MilesByLastDateDto dto = new FuelConsumptionGalPer100MilesByLastDateDto();
        dto.setId(entity.getId());
        dto.setGalPer100Miles(entity.getGalPer100Miles());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return FuelConsumptionGalPer100MilesByLastDate.class.getCanonicalName();
    }
}
