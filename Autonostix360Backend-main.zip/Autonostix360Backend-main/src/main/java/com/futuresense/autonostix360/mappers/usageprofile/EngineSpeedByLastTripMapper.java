package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineSpeedByLastTrip;
import com.futuresense.autonostix360.dto.usageprofile.EngineSpeedByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineSpeedByLastTripMapper implements EntityMapper<EngineSpeedByLastTrip, EngineSpeedByLastTripDto> {
    @Override
    public EngineSpeedByLastTrip buildEntity(EngineSpeedByLastTripDto dto) {
        final EngineSpeedByLastTrip entity = new EngineSpeedByLastTrip();
        entity.setId(dto.getId());
        entity.setEngineSpeed(dto.getEngineSpeed());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineSpeedByLastTripDto.class.getCanonicalName();
    }

    @Override
    public EngineSpeedByLastTripDto buildDto(EngineSpeedByLastTrip entity) {
        final EngineSpeedByLastTripDto dto = new EngineSpeedByLastTripDto();
        dto.setId(entity.getId());
        dto.setEngineSpeed(entity.getEngineSpeed());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineSpeedByLastTrip.class.getCanonicalName();
    }
}

