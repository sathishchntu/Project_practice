package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineSpeedByLastDate;
import com.futuresense.autonostix360.dto.usageprofile.EngineSpeedByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineSpeedByLastDateMapper implements EntityMapper<EngineSpeedByLastDate, EngineSpeedByLastDateDto> {

    @Override
    public EngineSpeedByLastDate buildEntity(EngineSpeedByLastDateDto dto) {
        final EngineSpeedByLastDate entity = new EngineSpeedByLastDate();
        entity.setId(dto.getId());
        entity.setEngineSpeed(dto.getEngineSpeed());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineSpeedByLastDateDto.class.getCanonicalName();
    }

    @Override
    public EngineSpeedByLastDateDto buildDto(EngineSpeedByLastDate entity) {
        final EngineSpeedByLastDateDto dto = new EngineSpeedByLastDateDto();
        dto.setId(entity.getId());
        dto.setEngineSpeed(entity.getEngineSpeed());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineSpeedByLastDate.class.getCanonicalName();
    }
}
