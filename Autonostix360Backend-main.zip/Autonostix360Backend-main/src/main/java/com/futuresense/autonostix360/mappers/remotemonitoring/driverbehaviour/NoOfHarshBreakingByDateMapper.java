package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfHarshBreakingByDate;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfHarshBreakingByDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfHarshBreakingByDateMapper implements EntityMapper<NoOfHarshBreakingByDate, NoOfHarshBreakingByDateDto> {

    @Override
    public NoOfHarshBreakingByDate buildEntity(NoOfHarshBreakingByDateDto dto) {
        NoOfHarshBreakingByDate entity = new NoOfHarshBreakingByDate();
        entity.setId(dto.getId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setNoOfHarshBreaking(dto.getNoOfHarshBreaking());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return NoOfHarshBreakingByDateDto.class.getCanonicalName();
    }

    @Override
    public NoOfHarshBreakingByDateDto buildDto(NoOfHarshBreakingByDate entity) {
        NoOfHarshBreakingByDateDto dto = new NoOfHarshBreakingByDateDto();
        dto.setId(entity.getId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setNoOfHarshBreaking(entity.getNoOfHarshBreaking());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfHarshBreakingByDateDto.class.getCanonicalName();
    }
}