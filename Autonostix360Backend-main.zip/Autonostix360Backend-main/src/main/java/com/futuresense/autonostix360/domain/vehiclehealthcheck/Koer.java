package com.futuresense.autonostix360.domain.vehiclehealthcheck;

import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

@Table(value = "koer")
public class Koer {
    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("stats_date")
    private String statsDate;

    @Column("dtc_code")
    private String dtc;

    @Column("odometer")
    private Integer odometer;

    @Column("last_updated")
    private Timestamp lastUpdated;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getDtc() {
        return dtc;
    }

    public void setDtc(String dtc) {
        this.dtc = dtc;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
