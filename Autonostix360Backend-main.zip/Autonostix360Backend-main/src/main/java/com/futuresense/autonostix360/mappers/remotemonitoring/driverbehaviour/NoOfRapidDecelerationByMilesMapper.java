package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfRapidDecelerationByMiles;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfRapidDecelerationByMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfRapidDecelerationByMilesMapper implements EntityMapper<NoOfRapidDecelerationByMiles, NoOfRapidDecelerationByMilesDto> {

    @Override
    public NoOfRapidDecelerationByMiles buildEntity(NoOfRapidDecelerationByMilesDto dto) {
        final NoOfRapidDecelerationByMiles entity = new NoOfRapidDecelerationByMiles();
        entity.setId(dto.getId());
        entity.setMiles(dto.getMiles());
        entity.setNoOfRapidDeceleration(dto.getNoOfRapidDeceleration());
        entity.setHours(dto.getHours());
        entity.setMiles(dto.getMiles());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return NoOfRapidDecelerationByMilesDto.class.getCanonicalName();
    }

    @Override
    public NoOfRapidDecelerationByMilesDto buildDto(NoOfRapidDecelerationByMiles entity) {
        final NoOfRapidDecelerationByMilesDto dto = new NoOfRapidDecelerationByMilesDto();
        dto.setId(entity.getId());
        dto.setNoOfRapidDeceleration(entity.getNoOfRapidDeceleration());
        dto.setHours(entity.getHours());
        dto.setMiles(entity.getMiles());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfRapidDecelerationByMiles.class.getCanonicalName();
    }
}
