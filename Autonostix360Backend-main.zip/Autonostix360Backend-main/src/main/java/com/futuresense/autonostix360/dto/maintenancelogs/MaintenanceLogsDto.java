package com.futuresense.autonostix360.dto.maintenancelogs;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.maintenancelogs.MaintenanceLogs}.
 */
public class MaintenanceLogsDto implements Serializable {

    private UUID id;

    @NotNull
    @Size(min = 5, message = "maintenanceActivity 5 characters")
    private String maintenanceActivity;

    @NotNull
    @Size(min = 15, message = "vinNumber 15 characters")
    private String vinNumber;

    @NotNull
    private Integer organizationId;

    private String dtcCode;

    private String subSystem;

    private String description;

    @NotNull
    @Size(min = 10, max = 10, message = "date string in YYYY-MM-DD format")
    private String statsDate;

    private Integer odometer;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getMaintenanceActivity() {
        return maintenanceActivity;
    }

    public void setMaintenanceActivity(String maintenanceActivity) {
        this.maintenanceActivity = maintenanceActivity;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getSubSystem() {
        return subSystem;
    }

    public void setSubSystem(String subSystem) {
        this.subSystem = subSystem;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }
}
