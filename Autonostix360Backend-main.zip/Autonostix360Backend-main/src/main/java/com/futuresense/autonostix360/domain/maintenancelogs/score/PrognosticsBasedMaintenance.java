package com.futuresense.autonostix360.domain.maintenancelogs.score;

import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entity PrognosticsBasedMaintenance represents table prognostics_based_maintenance
 */
@Table(value = "prognostics_based_maintenance")
public class PrognosticsBasedMaintenance {
    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("stats_date")
    private String statsDate;

    @Column("last_updated")
    private Timestamp lastUpdated;

    @Column("maintenance_activity")
    private String maintenanceActivity;

    @Column("metric")
    private String metric;

    @Column("scheduled")
    private Integer scheduled;

    @Column("completed")
    private Integer completed;

    @Column("violation")
    private Integer violation;

    @Column("weighnig_factor")
    private Double weighnigFactor;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getMaintenanceActivity() {
        return maintenanceActivity;
    }

    public void setMaintenanceActivity(String maintenanceActivity) {
        this.maintenanceActivity = maintenanceActivity;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public Integer getScheduled() {
        return scheduled;
    }

    public void setScheduled(Integer scheduled) {
        this.scheduled = scheduled;
    }

    public Integer getCompleted() {
        return completed;
    }

    public void setCompleted(Integer completed) {
        this.completed = completed;
    }

    public Integer getViolation() {
        return violation;
    }

    public void setViolation(Integer violation) {
        this.violation = violation;
    }

    public Double getWeighnigFactor() {
        return weighnigFactor;
    }

    public void setWeighnigFactor(Double weighnigFactor) {
        this.weighnigFactor = weighnigFactor;
    }
}
