package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineOilTemperatureByLastMiles;
import com.futuresense.autonostix360.dto.usageprofile.EngineOilTemperatureByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineOilTemperatureByLastMilesMapper implements EntityMapper<EngineOilTemperatureByLastMiles, EngineOilTemperatureByLastMilesDto> {

    @Override
    public EngineOilTemperatureByLastMiles buildEntity(EngineOilTemperatureByLastMilesDto dto) {
        final EngineOilTemperatureByLastMiles entity = new EngineOilTemperatureByLastMiles();
        entity.setId(dto.getId());
        entity.setOilTemperatureFahrenheit(dto.getOilTemperatureFahrenheit());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineOilTemperatureByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public EngineOilTemperatureByLastMilesDto buildDto(EngineOilTemperatureByLastMiles entity) {
        final EngineOilTemperatureByLastMilesDto dto = new EngineOilTemperatureByLastMilesDto();
        dto.setId(entity.getId());
        dto.setOilTemperatureFahrenheit(entity.getOilTemperatureFahrenheit());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineOilTemperatureByLastMiles.class.getCanonicalName();
    }
}
