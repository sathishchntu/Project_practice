package com.futuresense.autonostix360.dto.search;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Searchdto for post request on Maintenance logs search
 */
public class MaintenanceLogsSearchDto implements Serializable {

    @NotNull
    private String vinNumber;

    @NotNull
    private Integer organizationId;

    String searchString;

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getSearchString() {
        return searchString;
    }

    public void setSearchString(String searchString) {
        this.searchString = searchString;
    }
}
