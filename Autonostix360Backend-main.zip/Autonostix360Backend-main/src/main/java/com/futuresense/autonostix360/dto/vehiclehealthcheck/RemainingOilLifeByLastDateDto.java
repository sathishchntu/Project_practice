package com.futuresense.autonostix360.dto.vehiclehealthcheck;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.vehiclehealthcheck.RemainingOilLifeByLastDate}.
 */
public class RemainingOilLifeByLastDateDto implements Serializable {

    private UUID id;

    private Date statsDate;

    private Integer milesSinceLastOilChange;

    private Integer initial;

    private Integer fourtyKMiles;

    private Integer eightyKMiles;

    private Integer oneTwentyKMiles;

    private Double miles;

    private Double hours;

    private Integer engineRunTime;

    private Integer keyStarts;


    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Date getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(Date statsDate) {
        this.statsDate = statsDate;
    }

    public Integer getMilesSinceLastOilChange() {
        return milesSinceLastOilChange;
    }

    public void setMilesSinceLastOilChange(Integer milesSinceLastOilChange) {
        this.milesSinceLastOilChange = milesSinceLastOilChange;
    }

    public Integer getInitial() {
        return initial;
    }

    public void setInitial(Integer initial) {
        this.initial = initial;
    }

    public Integer getFourtyKMiles() {
        return fourtyKMiles;
    }

    public void setFourtyKMiles(Integer fourtyKMiles) {
        this.fourtyKMiles = fourtyKMiles;
    }

    public Integer getEightyKMiles() {
        return eightyKMiles;
    }

    public void setEightyKMiles(Integer eightyKMiles) {
        this.eightyKMiles = eightyKMiles;
    }

    public Integer getOneTwentyKMiles() {
        return oneTwentyKMiles;
    }

    public void setOneTwentyKMiles(Integer oneTwentyKMiles) {
        this.oneTwentyKMiles = oneTwentyKMiles;
    }

    public Double getMiles() {
        return miles;
    }

    public void setMiles(Double miles) {
        this.miles = miles;
    }

    public Double getHours() {
        return hours;
    }

    public void setHours(Double hours) {
        this.hours = hours;
    }

    public Integer getEngineRunTime() {
        return engineRunTime;
    }

    public void setEngineRunTime(Integer engineRunTime) {
        this.engineRunTime = engineRunTime;
    }

    public Integer getKeyStarts() {
        return keyStarts;
    }

    public void setKeyStarts(Integer keyStarts) {
        this.keyStarts = keyStarts;
    }

}
