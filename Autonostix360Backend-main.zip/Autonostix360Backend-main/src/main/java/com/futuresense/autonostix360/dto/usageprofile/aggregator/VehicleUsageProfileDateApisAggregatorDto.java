package com.futuresense.autonostix360.dto.usageprofile.aggregator;

import com.futuresense.autonostix360.dto.usageprofile.*;

import java.io.Serializable;
import java.util.List;


public class VehicleUsageProfileDateApisAggregatorDto implements Serializable {

    private List<BreakPressureByLastDateDto> breakPressureByLastDate;

    private List<EngineCoolantTemperatureByLastDateDto> engineCoolantTemperatureByLastDate;

    private List<EngineOilLevelByLastDateDto> engineOilLevelByLastDate;

    private List<EngineOilTemperatureByLastDateDto> engineOilTemperatureByLastDate;

    private List<EngineSpeedByLastDateDto> engineSpeedByLastDate;

    private List<EngineTorqueByLastDateDto> engineTorqueByLastDate;

    private List<RemainingEngineLifeByLastDateDto> remainingEngineLifeByLastDate;

    private List<TirePressureByLastDateDto> tirePressureByLastDate;

    private List<TransmissionGearByLastDateDto> transmissionGearByLastDate;

    private List<TransmissionOilTemperatureByLastDateDto> transmissionOilTemperatureByLastDate;


    public List<BreakPressureByLastDateDto> getBreakPressureByLastDate() {
        return breakPressureByLastDate;
    }

    public void setBreakPressureByLastDate(List<BreakPressureByLastDateDto> breakPressureByLastDate) {
        this.breakPressureByLastDate = breakPressureByLastDate;
    }

    public List<EngineCoolantTemperatureByLastDateDto> getEngineCoolantTemperatureByLastDate() {
        return engineCoolantTemperatureByLastDate;
    }

    public void setEngineCoolantTemperatureByLastDate(List<EngineCoolantTemperatureByLastDateDto> engineCoolantTemperatureByLastDate) {
        this.engineCoolantTemperatureByLastDate = engineCoolantTemperatureByLastDate;
    }

    public List<EngineOilLevelByLastDateDto> getEngineOilLevelByLastDate() {
        return engineOilLevelByLastDate;
    }

    public void setEngineOilLevelByLastDate(List<EngineOilLevelByLastDateDto> engineOilLevelByLastDate) {
        this.engineOilLevelByLastDate = engineOilLevelByLastDate;
    }

    public List<EngineOilTemperatureByLastDateDto> getEngineOilTemperatureByLastDate() {
        return engineOilTemperatureByLastDate;
    }

    public void setEngineOilTemperatureByLastDate(List<EngineOilTemperatureByLastDateDto> engineOilTemperatureByLastDate) {
        this.engineOilTemperatureByLastDate = engineOilTemperatureByLastDate;
    }

    public List<EngineSpeedByLastDateDto> getEngineSpeedByLastDate() {
        return engineSpeedByLastDate;
    }

    public void setEngineSpeedByLastDate(List<EngineSpeedByLastDateDto> engineSpeedByLastDate) {
        this.engineSpeedByLastDate = engineSpeedByLastDate;
    }

    public List<EngineTorqueByLastDateDto> getEngineTorqueByLastDate() {
        return engineTorqueByLastDate;
    }

    public void setEngineTorqueByLastDate(List<EngineTorqueByLastDateDto> engineTorqueByLastDate) {
        this.engineTorqueByLastDate = engineTorqueByLastDate;
    }

    public List<RemainingEngineLifeByLastDateDto> getRemainingEngineLifeByLastDate() {
        return remainingEngineLifeByLastDate;
    }

    public void setRemainingEngineLifeByLastDate(List<RemainingEngineLifeByLastDateDto> remainingEngineLifeByLastDate) {
        this.remainingEngineLifeByLastDate = remainingEngineLifeByLastDate;
    }

    public List<TirePressureByLastDateDto> getTirePressureByLastDate() {
        return tirePressureByLastDate;
    }

    public void setTirePressureByLastDate(List<TirePressureByLastDateDto> tirePressureByLastDate) {
        this.tirePressureByLastDate = tirePressureByLastDate;
    }

    public List<TransmissionGearByLastDateDto> getTransmissionGearByLastDate() {
        return transmissionGearByLastDate;
    }

    public void setTransmissionGearByLastDate(List<TransmissionGearByLastDateDto> transmissionGearByLastDate) {
        this.transmissionGearByLastDate = transmissionGearByLastDate;
    }

    public List<TransmissionOilTemperatureByLastDateDto> getTransmissionOilTemperatureByLastDate() {
        return transmissionOilTemperatureByLastDate;
    }

    public void setTransmissionOilTemperatureByLastDate(List<TransmissionOilTemperatureByLastDateDto> transmissionOilTemperatureByLastDate) {
        this.transmissionOilTemperatureByLastDate = transmissionOilTemperatureByLastDate;
    }
}
