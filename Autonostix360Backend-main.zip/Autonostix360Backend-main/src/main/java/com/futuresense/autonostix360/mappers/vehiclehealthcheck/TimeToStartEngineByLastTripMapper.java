package com.futuresense.autonostix360.mappers.vehiclehealthcheck;


import com.futuresense.autonostix360.domain.vehiclehealthcheck.TimeToStartEngineByLastTrip;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.TimeToStartEngineByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TimeToStartEngineByLastTripMapper implements EntityMapper<TimeToStartEngineByLastTrip, TimeToStartEngineByLastTripDto> {
    @Override
    public TimeToStartEngineByLastTrip buildEntity(TimeToStartEngineByLastTripDto dto) {
        final TimeToStartEngineByLastTrip entity = new TimeToStartEngineByLastTrip();
        entity.setId(dto.getId());
        entity.setTimeToStartEngine(dto.getTimeToStartEngine());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TimeToStartEngineByLastTripDto.class.getCanonicalName();
    }

    @Override
    public TimeToStartEngineByLastTripDto buildDto(TimeToStartEngineByLastTrip entity) {
        final TimeToStartEngineByLastTripDto dto = new TimeToStartEngineByLastTripDto();
        dto.setId(entity.getId());
        dto.setTimeToStartEngine(entity.getTimeToStartEngine());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TimeToStartEngineByLastTrip.class.getCanonicalName();
    }
}
