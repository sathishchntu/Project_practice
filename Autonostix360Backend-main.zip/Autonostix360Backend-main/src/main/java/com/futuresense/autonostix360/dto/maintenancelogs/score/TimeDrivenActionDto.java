package com.futuresense.autonostix360.dto.maintenancelogs.score;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.maintenancelogs.score.TimeDrivenActions}.
 */
public class TimeDrivenActionDto implements Serializable {

    private UUID id;

    private String vinNumber;

    private Integer organizationId;

    private String statsDate;

    private Timestamp lastUpdated;

    private String preScheduledMaintenance;

    private String metric;

    private Double scheduled;

    private Integer completed;

    private Double mileage;

    private Integer odometer;

    private Double monthsInService;

    private Integer violation;

    private Double weighingFactor;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getPreScheduledMaintenance() {
        return preScheduledMaintenance;
    }

    public void setPreScheduledMaintenance(String preScheduledMaintenance) {
        this.preScheduledMaintenance = preScheduledMaintenance;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public Double getScheduled() {
        return scheduled;
    }

    public void setScheduled(Double scheduled) {
        this.scheduled = scheduled;
    }

    public Integer getCompleted() {
        return completed;
    }

    public void setCompleted(Integer completed) {
        this.completed = completed;
    }

    public Double getMileage() {
        return mileage;
    }

    public void setMileage(Double mileage) {
        this.mileage = mileage;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Double getMonthsInService() {
        return monthsInService;
    }

    public void setMonthsInService(Double monthsInService) {
        this.monthsInService = monthsInService;
    }

    public Integer getViolation() {
        return violation;
    }

    public void setViolation(Integer violation) {
        this.violation = violation;
    }

    public Double getWeighingFactor() {
        return weighingFactor;
    }

    public void setWeighingFactor(Double weighingFactor) {
        this.weighingFactor = weighingFactor;
    }
}
