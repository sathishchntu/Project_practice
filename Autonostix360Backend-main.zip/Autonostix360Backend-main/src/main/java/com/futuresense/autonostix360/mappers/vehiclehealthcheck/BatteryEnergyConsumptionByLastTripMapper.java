package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.BatteryEnergyConsumptionByLastTrip;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.BatteryEnergyConsumptionByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class BatteryEnergyConsumptionByLastTripMapper implements EntityMapper<BatteryEnergyConsumptionByLastTrip, BatteryEnergyConsumptionByLastTripDto> {
    @Override
    public BatteryEnergyConsumptionByLastTrip buildEntity(BatteryEnergyConsumptionByLastTripDto dto) {
        final BatteryEnergyConsumptionByLastTrip entity = new BatteryEnergyConsumptionByLastTrip();
        entity.setId(dto.getId());
        entity.setBatteryEnergyConsumptionKwhPer100Miles(dto.getBatteryEnergyConsumptionKwhPer100Miles());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return BatteryEnergyConsumptionByLastTripDto.class.getCanonicalName();
    }

    @Override
    public BatteryEnergyConsumptionByLastTripDto buildDto(BatteryEnergyConsumptionByLastTrip entity) {
        final BatteryEnergyConsumptionByLastTripDto dto = new BatteryEnergyConsumptionByLastTripDto();
        dto.setId(entity.getId());
        dto.setBatteryEnergyConsumptionKwhPer100Miles(entity.getBatteryEnergyConsumptionKwhPer100Miles());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return BatteryEnergyConsumptionByLastTrip.class.getCanonicalName();
    }
}
