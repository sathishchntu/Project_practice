package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.BatteryEnergyConsumptionAtKeyOffByLastDate;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.BatteryEnergyConsumptionAtKeyOffByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class BatteryEnergyConsumptionAtKeyOffByLastDateMapper implements EntityMapper<BatteryEnergyConsumptionAtKeyOffByLastDate, BatteryEnergyConsumptionAtKeyOffByLastDateDto> {

    @Override
    public BatteryEnergyConsumptionAtKeyOffByLastDate buildEntity(BatteryEnergyConsumptionAtKeyOffByLastDateDto dto) {
        final BatteryEnergyConsumptionAtKeyOffByLastDate entity = new BatteryEnergyConsumptionAtKeyOffByLastDate();
        entity.setId(dto.getId());
        entity.setBatteryEnergyConsumptionWH(dto.getBatteryEnergyConsumptionWH());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return BatteryEnergyConsumptionAtKeyOffByLastDateDto.class.getCanonicalName();
    }

    @Override
    public BatteryEnergyConsumptionAtKeyOffByLastDateDto buildDto(BatteryEnergyConsumptionAtKeyOffByLastDate entity) {
        final BatteryEnergyConsumptionAtKeyOffByLastDateDto dto = new BatteryEnergyConsumptionAtKeyOffByLastDateDto();
        dto.setId(entity.getId());
        dto.setBatteryEnergyConsumptionWH(entity.getBatteryEnergyConsumptionWH());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return BatteryEnergyConsumptionAtKeyOffByLastDate.class.getCanonicalName();
    }
}
