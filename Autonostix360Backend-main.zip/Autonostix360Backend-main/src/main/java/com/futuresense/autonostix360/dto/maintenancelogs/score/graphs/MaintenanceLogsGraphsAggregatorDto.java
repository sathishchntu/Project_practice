package com.futuresense.autonostix360.dto.maintenancelogs.score.graphs;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

/**
 * Dto class for aggregated api for maintenance graph apis
 */
public class MaintenanceLogsGraphsAggregatorDto implements Serializable {

    private List<MaintenanceLogsGraphsDto> maintenanceLogsGraphs;

    private MaintenanceLogsGraphsThresholdsDto maintenanceLogsGraphsThresholds;

    public List<MaintenanceLogsGraphsDto> getMaintenanceLogsGraphs() {
        return maintenanceLogsGraphs;
    }

    public void setMaintenanceLogsGraphs(List<MaintenanceLogsGraphsDto> maintenanceLogsGraphs) {
        this.maintenanceLogsGraphs = maintenanceLogsGraphs;
    }

    public MaintenanceLogsGraphsThresholdsDto getMaintenanceLogsGraphsThresholds() {
        return maintenanceLogsGraphsThresholds;
    }

    public void setMaintenanceLogsGraphsThresholds(MaintenanceLogsGraphsThresholdsDto maintenanceLogsGraphsThresholds) {
        this.maintenanceLogsGraphsThresholds = maintenanceLogsGraphsThresholds;
    }
}
