package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.MilesDrivenInLaneTrackingZoneByTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * MilesDrivingUnpavedRoadRouteAdherenceByTripRepository
 */
public interface MilesDrivenInLaneTrackingZoneByTripRepository extends CassandraRepository<MilesDrivenInLaneTrackingZoneByTrip, Long> {

    @Query(value = "select max(trip) from miles_driven_in_lane_tracking_zone_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from miles_driven_in_lane_tracking_zone_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<MilesDrivenInLaneTrackingZoneByTrip> findMilesDrivenInLaneTrackingZoneByTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}
