package com.futuresense.autonostix360.repository.ftanalytics.graphs;

import com.futuresense.autonostix360.domain.ftanalytics.graphs.FaultTrendAnalyticsRulGraphsThresholds;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

/**
 * Repository for FaultTrendAnalyticsRulGraphsThresholds
 */
public interface FaultTrendAnalyticsRulGraphsThresholdsRepository extends CassandraRepository<FaultTrendAnalyticsRulGraphsThresholds, String> {

    @Query(value = "select * from fault_trend_analytics_rul_graphs_thresholds " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate " +
            "and dtc_code = :dtcCode " +
            "and graph_name = :graphName")
    FaultTrendAnalyticsRulGraphsThresholds findByVinNumberAndOrganizationIdAndStatsDateAndGraphName(final String vinNumber,
                                                                                                    final Integer organizationId, final
                                                                                                    String statsDate, final String dtcCode,
                                                                                                    final String graphName);
}
