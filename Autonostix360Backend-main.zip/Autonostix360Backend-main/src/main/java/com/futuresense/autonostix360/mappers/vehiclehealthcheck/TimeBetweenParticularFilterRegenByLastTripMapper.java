package com.futuresense.autonostix360.mappers.vehiclehealthcheck;


import com.futuresense.autonostix360.domain.vehiclehealthcheck.TimeBetweenParticularFilterRegenByLastTrip;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.TimeBetweenParticularFilterRegenByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TimeBetweenParticularFilterRegenByLastTripMapper implements EntityMapper<TimeBetweenParticularFilterRegenByLastTrip, TimeBetweenParticularFilterRegenByLastTripDto> {
    @Override
    public TimeBetweenParticularFilterRegenByLastTrip buildEntity(TimeBetweenParticularFilterRegenByLastTripDto dto) {
        final TimeBetweenParticularFilterRegenByLastTrip entity = new TimeBetweenParticularFilterRegenByLastTrip();
        entity.setId(dto.getId());
        entity.setTimeBetweenParticularFilterRegenMin(dto.getTimeBetweenParticularFilterRegenMin());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TimeBetweenParticularFilterRegenByLastTripDto.class.getCanonicalName();
    }

    @Override
    public TimeBetweenParticularFilterRegenByLastTripDto buildDto(TimeBetweenParticularFilterRegenByLastTrip entity) {
        final TimeBetweenParticularFilterRegenByLastTripDto dto = new TimeBetweenParticularFilterRegenByLastTripDto();
        dto.setId(entity.getId());
        dto.setTimeBetweenParticularFilterRegenMin(entity.getTimeBetweenParticularFilterRegenMin());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TimeBetweenParticularFilterRegenByLastTrip.class.getCanonicalName();
    }
}
