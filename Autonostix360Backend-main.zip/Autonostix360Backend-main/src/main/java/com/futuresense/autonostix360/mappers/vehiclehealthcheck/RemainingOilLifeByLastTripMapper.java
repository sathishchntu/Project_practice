package com.futuresense.autonostix360.mappers.vehiclehealthcheck;


import com.futuresense.autonostix360.domain.vehiclehealthcheck.RemainingOilLifeByLastTrip;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.RemainingOilLifeByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class RemainingOilLifeByLastTripMapper implements EntityMapper<RemainingOilLifeByLastTrip, RemainingOilLifeByLastTripDto> {
    @Override
    public RemainingOilLifeByLastTrip buildEntity(RemainingOilLifeByLastTripDto dto) {
        final RemainingOilLifeByLastTrip entity = new RemainingOilLifeByLastTrip();
        entity.setId(dto.getId());
        entity.setMilesSinceLastOilChange(dto.getMilesSinceLastOilChange());
        entity.setInitial(dto.getInitial());
        entity.setFourtyKMiles(dto.getFourtyKMiles());
        entity.setEightyKMiles(dto.getEightyKMiles());
        entity.setOneTwentyKMiles(dto.getOneTwentyKMiles());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return RemainingOilLifeByLastTripDto.class.getCanonicalName();
    }

    @Override
    public RemainingOilLifeByLastTripDto buildDto(RemainingOilLifeByLastTrip entity) {
        final RemainingOilLifeByLastTripDto dto = new RemainingOilLifeByLastTripDto();
        dto.setId(entity.getId());
        dto.setMilesSinceLastOilChange(entity.getMilesSinceLastOilChange());
        dto.setInitial(entity.getInitial());
        dto.setFourtyKMiles(entity.getFourtyKMiles());
        dto.setEightyKMiles(entity.getEightyKMiles());
        dto.setOneTwentyKMiles(entity.getOneTwentyKMiles());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return RemainingOilLifeByLastTrip.class.getCanonicalName();
    }
}
