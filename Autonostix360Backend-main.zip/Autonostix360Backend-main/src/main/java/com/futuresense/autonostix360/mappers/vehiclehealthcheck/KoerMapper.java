package com.futuresense.autonostix360.mappers.vehiclehealthcheck;


import com.futuresense.autonostix360.domain.vehiclehealthcheck.Koer;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoerDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class that converts dto to entity and vice versa
 */
@Service
public class KoerMapper implements EntityMapper<Koer, KoerDto> {
    @Override
    public Koer buildEntity(KoerDto dto) {
        final Koer entity = new Koer();
        entity.setId(dto.getId());
        entity.setDtc(dto.getDtc());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return KoerDto.class.getCanonicalName();
    }

    @Override
    public KoerDto buildDto(Koer entity) {
        final KoerDto dto = new KoerDto();
        dto.setId(entity.getId());
        dto.setDtc(entity.getDtc());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return Koer.class.getCanonicalName();
    }
}
