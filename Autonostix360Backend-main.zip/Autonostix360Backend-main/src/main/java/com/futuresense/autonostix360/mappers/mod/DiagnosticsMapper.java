package com.futuresense.autonostix360.mappers.mod;

import com.futuresense.autonostix360.domain.mod.Diagnostics;
import com.futuresense.autonostix360.dto.mod.DiagnosticsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapping class that converts DTO to Entity and vice versa
 */
@Service
public class DiagnosticsMapper implements EntityMapper<Diagnostics, DiagnosticsDto> {
    @Override
    public Diagnostics buildEntity(DiagnosticsDto dto) {
        final Diagnostics entity = new Diagnostics();
        entity.setId(dto.getId());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setStatsDate(dto.getStatsDate());
        entity.setDescription(dto.getDescription());
        entity.setDtcCode(dto.getDtcCode());
        entity.setModule(dto.getModule());
        entity.setName(dto.getName());
        entity.setSubsystem(dto.getSubsystem());
        entity.setRcaAndProbability(dto.getRcaAndProbability());
        entity.setLastUpdated(dto.getLastUpdated());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return DiagnosticsDto.class.getCanonicalName();
    }

    @Override
    public DiagnosticsDto buildDto(Diagnostics entity) {
        final DiagnosticsDto dto = new DiagnosticsDto();
        dto.setId(entity.getId());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setStatsDate(entity.getStatsDate());
        dto.setDescription(entity.getDescription());
        dto.setModule(entity.getModule());
        dto.setDtcCode(entity.getDtcCode());
        dto.setName(entity.getName());
        dto.setSubsystem(entity.getSubsystem());
        dto.setRcaAndProbability(entity.getRcaAndProbability());
        dto.setLastUpdated(entity.getLastUpdated());
        return dto;
    }

    @Override
    public String entityClassName() {
        return Diagnostics.class.getCanonicalName();
    }
}
