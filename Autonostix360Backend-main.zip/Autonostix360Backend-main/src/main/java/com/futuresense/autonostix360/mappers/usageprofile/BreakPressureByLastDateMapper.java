package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.BreakPressureByLastDate;
import com.futuresense.autonostix360.dto.usageprofile.BreakPressureByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class BreakPressureByLastDateMapper implements EntityMapper<BreakPressureByLastDate, BreakPressureByLastDateDto> {

    @Override
    public BreakPressureByLastDate buildEntity(BreakPressureByLastDateDto dto) {
        final BreakPressureByLastDate entity = new BreakPressureByLastDate();
        entity.setId(dto.getId());
        entity.setBreakPressurePsi(dto.getBreakPressurePsi());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return BreakPressureByLastDateDto.class.getCanonicalName();
    }

    @Override
    public BreakPressureByLastDateDto buildDto(BreakPressureByLastDate entity) {
        final BreakPressureByLastDateDto dto = new BreakPressureByLastDateDto();
        dto.setId(entity.getId());
        dto.setBreakPressurePsi(entity.getBreakPressurePsi());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return BreakPressureByLastDate.class.getCanonicalName();
    }
}
