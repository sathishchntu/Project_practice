package com.futuresense.autonostix360.repository.usageprofile;


import com.futuresense.autonostix360.domain.usageprofile.EngineOilTemperatureByLastMiles;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * EngineOilTemperatureByLastMilesRepository
 */
public interface EngineOilTemperatureByLastMilesRepository extends CassandraRepository<EngineOilTemperatureByLastMiles, Long> {
    @Query("select * from engine_oil_temperature_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    List<EngineOilTemperatureByLastMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId);

    @Query("select max(odometer) from engine_oil_temperature_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    Integer findMaxOdometerReadingByVinAndOrganizationId(String vinNumber, Integer organizationId);

    @Query("select * from engine_oil_temperature_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and odometer >= :fromOdometerReading and odometer <= :maxOdometerReading")
    List<EngineOilTemperatureByLastMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId, int fromOdometerReading, Integer maxOdometerReading);


}
