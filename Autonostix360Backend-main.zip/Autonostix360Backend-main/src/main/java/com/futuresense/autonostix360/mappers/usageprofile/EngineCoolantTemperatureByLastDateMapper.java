package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineCoolantTemperatureByLastDate;
import com.futuresense.autonostix360.dto.usageprofile.EngineCoolantTemperatureByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineCoolantTemperatureByLastDateMapper implements EntityMapper<EngineCoolantTemperatureByLastDate, EngineCoolantTemperatureByLastDateDto> {

    @Override
    public EngineCoolantTemperatureByLastDate buildEntity(EngineCoolantTemperatureByLastDateDto dto) {
        final EngineCoolantTemperatureByLastDate entity = new EngineCoolantTemperatureByLastDate();
        entity.setId(dto.getId());
        entity.setTemperatureInFahrenheit(dto.getTemperatureInFahrenheit());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineCoolantTemperatureByLastDateDto.class.getCanonicalName();
    }

    @Override
    public EngineCoolantTemperatureByLastDateDto buildDto(EngineCoolantTemperatureByLastDate entity) {
        final EngineCoolantTemperatureByLastDateDto dto = new EngineCoolantTemperatureByLastDateDto();
        dto.setId(entity.getId());
        dto.setTemperatureInFahrenheit(entity.getTemperatureInFahrenheit());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineCoolantTemperatureByLastDate.class.getCanonicalName();
    }
}
