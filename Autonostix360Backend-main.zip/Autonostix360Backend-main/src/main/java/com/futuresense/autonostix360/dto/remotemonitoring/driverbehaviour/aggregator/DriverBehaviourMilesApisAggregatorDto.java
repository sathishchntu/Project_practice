package com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.aggregator;

import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.*;

import java.io.Serializable;
import java.util.List;

/**
 * Dto class for aggregated api for Driver Behaviour Trip apis
 */
public class DriverBehaviourMilesApisAggregatorDto implements Serializable {

    private List<DrivingUnpavedRoadRouteAdherenceByMilesDto> drivingUnpavedRoadRouteAdherenceByMiles;

    private List<TrafficSignalViolationByMilesDto> trafficSignalViolationByMiles;

    private List<StopSignViolationByMilesDto> stopSignViolationByMiles;

    private List<EngineRunTimeDistanceTravelledByMilesDto> engineRunTimeDistanceTravelledByMiles;

    private List<NoOfHarshBreakingByMilesDto> noOfHarshBreakingByMiles;

    private List<NoOfHarshCorneringByMilesDto> noOfHarshCorneringByMiles;

    private List<NoOfOverSpeedingEventsByMilesDto> noOfOverSpeedingEventsByMiles;

    private List<MilesDrivenOverSpeedingByMilesDto> milesDrivenOverSpeedingByMiles;

    private List<MilesDrivenInLaneTrackingZoneByMilesDto> milesDrivenInLaneTrackingZoneByMiles;

    private List<NoOfRapidAccelerationByMilesDto> noOfRapidAccelerationByMiles;

    private List<NoOfRapidDecelerationByMilesDto> noOfRapidDecelerationByMiles;

    private List<EngineOnDistanceTravelledExtremeWeatherByMilesDto> engineOnDistanceTravelledExtremeWeatherByMiles;

    public List<DrivingUnpavedRoadRouteAdherenceByMilesDto> getDrivingUnpavedRoadRouteAdherenceByMiles() {
        return drivingUnpavedRoadRouteAdherenceByMiles;
    }

    public void setDrivingUnpavedRoadRouteAdherenceByMiles(List<DrivingUnpavedRoadRouteAdherenceByMilesDto> drivingUnpavedRoadRouteAdherenceByMiles) {
        this.drivingUnpavedRoadRouteAdherenceByMiles = drivingUnpavedRoadRouteAdherenceByMiles;
    }

    public List<TrafficSignalViolationByMilesDto> getTrafficSignalViolationByMiles() {
        return trafficSignalViolationByMiles;
    }

    public void setTrafficSignalViolationByMiles(List<TrafficSignalViolationByMilesDto> trafficSignalViolationByMiles) {
        this.trafficSignalViolationByMiles = trafficSignalViolationByMiles;
    }

    public List<StopSignViolationByMilesDto> getStopSignViolationByMiles() {
        return stopSignViolationByMiles;
    }

    public void setStopSignViolationByMiles(List<StopSignViolationByMilesDto> stopSignViolationByMiles) {
        this.stopSignViolationByMiles = stopSignViolationByMiles;
    }

    public List<EngineRunTimeDistanceTravelledByMilesDto> getEngineRunTimeDistanceTravellledByMiles() {
        return engineRunTimeDistanceTravelledByMiles;
    }

    public void setEngineRunTimeDistanceTravelledByMiles(List<EngineRunTimeDistanceTravelledByMilesDto> engineRunTimeDistanceTravelledByMiles) {
        this.engineRunTimeDistanceTravelledByMiles = engineRunTimeDistanceTravelledByMiles;
    }

    public List<NoOfHarshBreakingByMilesDto> getNoOfHarshBreakingByMiles() {
        return noOfHarshBreakingByMiles;
    }

    public void setNoOfHarshBreakingByMiles(List<NoOfHarshBreakingByMilesDto> noOfHarshBreakingByMiles) {
        this.noOfHarshBreakingByMiles = noOfHarshBreakingByMiles;
    }

    public List<NoOfHarshCorneringByMilesDto> getNoOfHarshCorneringByMiles() {
        return noOfHarshCorneringByMiles;
    }

    public void setNoOfHarshCorneringByMiles(List<NoOfHarshCorneringByMilesDto> noOfHarshCorneringByMiles) {
        this.noOfHarshCorneringByMiles = noOfHarshCorneringByMiles;
    }

    public List<NoOfOverSpeedingEventsByMilesDto> getNoOfOverSpeedingEventsByMiles() {
        return noOfOverSpeedingEventsByMiles;
    }

    public void setNoOfOverSpeedingEventsByMiles(List<NoOfOverSpeedingEventsByMilesDto> noOfOverSpeedingEventsByMiles) {
        this.noOfOverSpeedingEventsByMiles = noOfOverSpeedingEventsByMiles;
    }

    public List<MilesDrivenOverSpeedingByMilesDto> getMilesDrivenOverSpeedingByMiles() {
        return milesDrivenOverSpeedingByMiles;
    }

    public void setMilesDrivenOverSpeedingByMiles(List<MilesDrivenOverSpeedingByMilesDto> milesDrivenOverSpeedingByMiles) {
        this.milesDrivenOverSpeedingByMiles = milesDrivenOverSpeedingByMiles;
    }

    public List<MilesDrivenInLaneTrackingZoneByMilesDto> getMilesDrivenInLaneTrackingZoneByMiles() {
        return milesDrivenInLaneTrackingZoneByMiles;
    }

    public void setMilesDrivenInLaneTrackingZoneByMiles(List<MilesDrivenInLaneTrackingZoneByMilesDto> milesDrivenInLaneTrackingZoneByMiles) {
        this.milesDrivenInLaneTrackingZoneByMiles = milesDrivenInLaneTrackingZoneByMiles;
    }

    public List<NoOfRapidAccelerationByMilesDto> getNoOfRapidAccelerationByMiles() {
        return noOfRapidAccelerationByMiles;
    }

    public void setNoOfRapidAccelerationByMiles(List<NoOfRapidAccelerationByMilesDto> noOfRapidAccelerationByMiles) {
        this.noOfRapidAccelerationByMiles = noOfRapidAccelerationByMiles;
    }

    public List<NoOfRapidDecelerationByMilesDto> getNoOfRapidDecelerationByMiles() {
        return noOfRapidDecelerationByMiles;
    }

    public void setNoOfRapidDecelerationByMiles(List<NoOfRapidDecelerationByMilesDto> noOfRapidDecelerationByMiles) {
        this.noOfRapidDecelerationByMiles = noOfRapidDecelerationByMiles;
    }

    public List<EngineOnDistanceTravelledExtremeWeatherByMilesDto> getEngineOnDistanceTravelledExtremeWeatherByMiles() {
        return engineOnDistanceTravelledExtremeWeatherByMiles;
    }

    public void setEngineOnDistanceTravelledExtremeWeatherByMiles(List<EngineOnDistanceTravelledExtremeWeatherByMilesDto> engineOnDistanceTravelledExtremeWeatherByMiles) {
        this.engineOnDistanceTravelledExtremeWeatherByMiles = engineOnDistanceTravelledExtremeWeatherByMiles;
    }
}
