package com.futuresense.autonostix360.dto.vehiclehealthcheck;


import java.io.Serializable;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.vehiclehealthcheck.BatteryEnergyConsumptionByLastMiles}.
 */
public class BatteryEnergyConsumptionByLastMilesDto implements Serializable {

    private UUID id;

    private Double batteryEnergyConsumptionKwhPer100Miles;

    private Double miles;

    private Double hours;

    private Integer engineRunTime;

    private Integer keyStarts;


    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Double getBatteryEnergyConsumptionKwhPer100Miles() {
        return batteryEnergyConsumptionKwhPer100Miles;
    }

    public void setBatteryEnergyConsumptionKwhPer100Miles(Double batteryEnergyConsumptionKwhPer100Miles) {
        this.batteryEnergyConsumptionKwhPer100Miles = batteryEnergyConsumptionKwhPer100Miles;
    }

    public Double getMiles() {
        return miles;
    }

    public void setMiles(Double miles) {
        this.miles = miles;
    }

    public Double getHours() {
        return hours;
    }

    public void setHours(Double hours) {
        this.hours = hours;
    }

    public Integer getEngineRunTime() {
        return engineRunTime;
    }

    public void setEngineRunTime(Integer engineRunTime) {
        this.engineRunTime = engineRunTime;
    }

    public Integer getKeyStarts() {
        return keyStarts;
    }

    public void setKeyStarts(Integer keyStarts) {
        this.keyStarts = keyStarts;
    }
}
