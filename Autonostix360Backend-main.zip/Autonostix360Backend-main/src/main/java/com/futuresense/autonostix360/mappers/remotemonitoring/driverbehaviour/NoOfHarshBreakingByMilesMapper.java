package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfHarshBreakingByMiles;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfHarshBreakingByMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfHarshBreakingByMilesMapper implements EntityMapper<NoOfHarshBreakingByMiles, NoOfHarshBreakingByMilesDto> {
    @Override
    public NoOfHarshBreakingByMiles buildEntity(NoOfHarshBreakingByMilesDto dto) {
        final NoOfHarshBreakingByMiles entity = new NoOfHarshBreakingByMiles();
        entity.setId(dto.getId());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setNoOfHarshBreaking(dto.getNoOfHarshBreaking());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return NoOfHarshBreakingByMilesDto.class.getCanonicalName();
    }

    @Override
    public NoOfHarshBreakingByMilesDto buildDto(NoOfHarshBreakingByMiles entity) {
        final NoOfHarshBreakingByMilesDto dto = new NoOfHarshBreakingByMilesDto();
        dto.setId(entity.getId());
        dto.setMiles(entity.getMiles());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setNoOfHarshBreaking(entity.getNoOfHarshBreaking());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfHarshBreakingByMiles.class.getCanonicalName();
    }
}
