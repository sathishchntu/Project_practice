package com.futuresense.autonostix360.mappers.ftanalytics.graphs;

import com.futuresense.autonostix360.domain.ftanalytics.graphs.FaultTrendAnalyticsRulGraphs;
import com.futuresense.autonostix360.dto.ftanalytics.graphs.FaultTrendAnalyticRulGraphsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class FaultTrendAnalyticsRulGraphsMapper implements EntityMapper<FaultTrendAnalyticsRulGraphs, FaultTrendAnalyticRulGraphsDto> {
    @Override
    public FaultTrendAnalyticsRulGraphs buildEntity(FaultTrendAnalyticRulGraphsDto dto) {
        final FaultTrendAnalyticsRulGraphs entity = new FaultTrendAnalyticsRulGraphs();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setDtcCode(dto.getDtcCode());
        entity.setGraphName(dto.getGraphName());
        entity.setxAxisName(dto.getxAxisName());
        entity.setyAxisName(dto.getyAxisName());
        entity.setxAxisData(dto.getxAxisData());
        entity.setyAxisData(dto.getyAxisData());

        return entity;
    }

    @Override
    public String dtoClassName() {
        return FaultTrendAnalyticRulGraphsDto.class.getCanonicalName();
    }

    @Override
    public FaultTrendAnalyticRulGraphsDto buildDto(FaultTrendAnalyticsRulGraphs entity) {
        final FaultTrendAnalyticRulGraphsDto dto = new FaultTrendAnalyticRulGraphsDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setDtcCode(entity.getDtcCode());
        dto.setGraphName(entity.getGraphName());
        dto.setxAxisName(entity.getxAxisName());
        dto.setyAxisName(entity.getyAxisName());
        dto.setxAxisData(entity.getxAxisData());
        dto.setyAxisData(entity.getyAxisData());

        return dto;
    }

    @Override
    public String entityClassName() {
        return FaultTrendAnalyticsRulGraphs.class.getCanonicalName();
    }
}