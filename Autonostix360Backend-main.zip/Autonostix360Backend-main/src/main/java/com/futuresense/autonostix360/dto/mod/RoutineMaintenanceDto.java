package com.futuresense.autonostix360.dto.mod;

import java.io.Serializable;
import java.util.UUID;

/**
 * Dto class for entity RoutineMaintenance entity
 */
public class RoutineMaintenanceDto implements Serializable {

    private UUID id;

    private String statsDate;

    private String attributeName;

    private Integer status;

    private Double attributeValue;

    private Double lowerLimit;

    private Double upperLimit;

    private String message;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Double getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(Double attributeValue) {
        this.attributeValue = attributeValue;
    }

    public Double getLowerLimit() {
        return lowerLimit;
    }

    public void setLowerLimit(Double lowerLimit) {
        this.lowerLimit = lowerLimit;
    }

    public Double getUpperLimit() {
        return upperLimit;
    }

    public void setUpperLimit(Double upperLimit) {
        this.upperLimit = upperLimit;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
