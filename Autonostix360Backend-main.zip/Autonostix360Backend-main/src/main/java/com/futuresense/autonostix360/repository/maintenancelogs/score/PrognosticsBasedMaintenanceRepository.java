package com.futuresense.autonostix360.repository.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.PrognosticsBasedMaintenance;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.UUID;

/**
 * Repository for prognostics_based_maintenance
 */
public interface PrognosticsBasedMaintenanceRepository extends CassandraRepository<PrognosticsBasedMaintenance, UUID> {
    @Query(value = "select * from prognostics_based_maintenance where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    Slice<PrognosticsBasedMaintenance> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, String statsDate, Pageable pageable);

    @Query(value = "select count(*) from prognostics_based_maintenance where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    int pageCount(String vinNumber, Integer organizationId, String statsDate);

    @Query(value = "select * from prognostics_based_maintenance where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    Slice<PrognosticsBasedMaintenance> findByVinNumberAndOrganizationIdAndStatsDate(CassandraPageRequest pageRequest, String vinNumber, Integer organizationId, String statsDate);

}
