package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.StopSignViolationByTrip;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.StopSignViolationByTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class StopSignViolationByTripMapper implements EntityMapper<StopSignViolationByTrip, StopSignViolationByTripDto> {

    @Override
    public StopSignViolationByTrip buildEntity(StopSignViolationByTripDto dto) {
        StopSignViolationByTrip entity = new StopSignViolationByTrip();
        entity.setId(dto.getId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setStopSignViolation(dto.getStopSignViolation());
        entity.setHours(dto.getHours());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return StopSignViolationByTripDto.class.getCanonicalName();
    }

    @Override
    public StopSignViolationByTripDto buildDto(StopSignViolationByTrip entity) {
        StopSignViolationByTripDto dto = new StopSignViolationByTripDto();
        dto.setId(entity.getId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setStopSignViolation(entity.getStopSignViolation());
        dto.setHours(entity.getHours());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return StopSignViolationByTrip.class.getCanonicalName();
    }
}
