package com.futuresense.autonostix360.repository.search;

import org.elasticsearch.search.sort.SortOrder;

import java.util.List;

public class ElasticSearchDTO extends PagedRequestDTO {

    private List<String> mustField;
    private List<String> multiMatchFields;
    private List<String> wildCardFields;
    private String searchTerm;
    private String sortBy;
    private SortOrder order;

    public List<String> getMustField() {
        return mustField;
    }

    public void setMustField(List<String> mustField) {
        this.mustField = mustField;
    }

    public List<String> getMultiMatchFields() {
        return multiMatchFields;
    }

    public void setMultiMatchFields(List<String> multiMatchFields) {
        this.multiMatchFields = multiMatchFields;
    }

    public List<String> getWildCardFields() {
        return wildCardFields;
    }

    public void setWildCardFields(List<String> wildCardFields) {
        this.wildCardFields = wildCardFields;
    }

    public String getSearchTerm() {
        return searchTerm;
    }

    public void setSearchTerm(String searchTerm) {
        this.searchTerm = searchTerm;
    }

    public String getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    public SortOrder getOrder() {
        return order;
    }

    public void setOrder(SortOrder order) {
        this.order = order;
    }
}
