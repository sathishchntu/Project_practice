package com.futuresense.autonostix360.domain.ftanalytics;

import com.datastax.oss.driver.api.mapper.annotations.ClusteringColumn;
import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entity faultTrendAnalyticsTime represents table fault_trend_analytics_time
 */
@Table(value = "fault_trend_analytics_time")
public class FaultTrendAnalyticsTime {

    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @ClusteringColumn
    @Column("rul_time_hours")
    private Double rulHours;

    @Column("odometer")
    private Integer odometer;

    @Column("last_updated")
    private Timestamp lastUpdated;

    @Column("name")
    private String name;

    @Column("dtc_code")
    private String dtcCode;

    @Column("description")
    private String description;

    @Column("subsystem")
    private String subSystem;

    @Column("module")
    private String module;

    @Column("rul_miles")
    private Double rulMiles;

    @Column("rul_engine_runtime")
    private Integer rulEngineRunTime;

    @Column("rul_key_starts")
    private Integer rulKeyStarts;

    @Column("stats_date")
    private String statsDate;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSubSystem() {
        return subSystem;
    }

    public void setSubSystem(String subSystem) {
        this.subSystem = subSystem;
    }

    public Double getRulHours() {
        return rulHours;
    }

    public void setRulHours(Double rulHours) {
        this.rulHours = rulHours;
    }

    public Double getRulMiles() {
        return rulMiles;
    }

    public void setRulMiles(Double rulMiles) {
        this.rulMiles = rulMiles;
    }

    public Integer getRulEngineRunTime() {
        return rulEngineRunTime;
    }

    public void setRulEngineRunTime(Integer rulEngineRunTime) {
        this.rulEngineRunTime = rulEngineRunTime;
    }

    public Integer getRulKeyStarts() {
        return rulKeyStarts;
    }

    public void setRulKeyStarts(Integer rulKeyStarts) {
        this.rulKeyStarts = rulKeyStarts;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }
}
