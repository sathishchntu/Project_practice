package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineOilLevelByLastTrip;
import com.futuresense.autonostix360.dto.usageprofile.EngineOilLevelByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineOilLevelByLastTripMapper implements EntityMapper<EngineOilLevelByLastTrip, EngineOilLevelByLastTripDto> {
    @Override
    public EngineOilLevelByLastTrip buildEntity(EngineOilLevelByLastTripDto dto) {
        final EngineOilLevelByLastTrip entity = new EngineOilLevelByLastTrip();
        entity.setId(dto.getId());
        entity.setEngineOilLevel(dto.getEngineOilLevel());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineOilLevelByLastTripDto.class.getCanonicalName();
    }

    @Override
    public EngineOilLevelByLastTripDto buildDto(EngineOilLevelByLastTrip entity) {
        final EngineOilLevelByLastTripDto dto = new EngineOilLevelByLastTripDto();
        dto.setId(entity.getId());
        dto.setEngineOilLevel(entity.getEngineOilLevel());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineOilLevelByLastTrip.class.getCanonicalName();
    }
}
