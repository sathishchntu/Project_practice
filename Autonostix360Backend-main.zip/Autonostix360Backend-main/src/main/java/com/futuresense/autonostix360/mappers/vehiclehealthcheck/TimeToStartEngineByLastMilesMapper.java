package com.futuresense.autonostix360.mappers.vehiclehealthcheck;


import com.futuresense.autonostix360.domain.vehiclehealthcheck.TimeToStartEngineByLastMiles;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.TimeToStartEngineByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TimeToStartEngineByLastMilesMapper implements EntityMapper<TimeToStartEngineByLastMiles, TimeToStartEngineByLastMilesDto> {
    @Override
    public TimeToStartEngineByLastMiles buildEntity(TimeToStartEngineByLastMilesDto dto) {
        final TimeToStartEngineByLastMiles entity = new TimeToStartEngineByLastMiles();
        entity.setId(dto.getId());
        entity.setTimeToStartEngine(dto.getTimeToStartEngine());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TimeToStartEngineByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public TimeToStartEngineByLastMilesDto buildDto(TimeToStartEngineByLastMiles entity) {
        final TimeToStartEngineByLastMilesDto dto = new TimeToStartEngineByLastMilesDto();
        dto.setId(entity.getId());
        dto.setTimeToStartEngine(entity.getTimeToStartEngine());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TimeToStartEngineByLastMiles.class.getCanonicalName();
    }
}
