package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.EngineRunTimeDistanceTravelledByTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * EngineRunTimeDistanceTravelledByTripRepository
 */
public interface EngineRunTimeDistanceTravelledByTripRepository extends CassandraRepository<EngineRunTimeDistanceTravelledByTrip, Long> {

    @Query(value = "select max(trip) from engine_run_time_distance_travelled_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from engine_run_time_distance_travelled_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<EngineRunTimeDistanceTravelledByTrip> findEngineRunTimeDistanceTravelledByTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}
