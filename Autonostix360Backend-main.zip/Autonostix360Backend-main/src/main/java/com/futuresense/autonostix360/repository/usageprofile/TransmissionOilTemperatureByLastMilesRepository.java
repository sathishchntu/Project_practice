package com.futuresense.autonostix360.repository.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TransmissionOilTemperatureByLastMiles;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * TransmissionOilTemperatureByLastMilesRepository
 */
public interface TransmissionOilTemperatureByLastMilesRepository extends CassandraRepository<TransmissionOilTemperatureByLastMiles, Long> {
    @Query("select * from transmission_oil_temperature_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    List<TransmissionOilTemperatureByLastMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId);

    @Query("select max(odometer) from transmission_oil_temperature_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    Integer findMaxOdometerReadingByVinAndOrganizationId(String vinNumber, Integer organizationId);

    @Query("select * from transmission_oil_temperature_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and odometer >= :fromOdometerReading and odometer <= :maxOdometerReading")
    List<TransmissionOilTemperatureByLastMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId, int fromOdometerReading, Integer maxOdometerReading);


}
