package com.futuresense.autonostix360.repository.maintenancelogs.score.graphs;

import com.futuresense.autonostix360.domain.maintenancelogs.score.graphs.MaintenanceLogsGraphsThresholds;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

/**
 * Repository for MaintenanceLogsGraphsThresholds
 */
public interface MaintenanceLogsGraphsThresholdsRepository extends CassandraRepository<MaintenanceLogsGraphsThresholds, String> {

    @Query(value = "select * from maintenance_logs_graphs_thresholds " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate " +
            "and graph_name = :graphName")
    MaintenanceLogsGraphsThresholds findByVinNumberAndOrganizationIdAndStatsDateAndGraphName(final String vinNumber,
                                                                                             final Integer organizationId, final
                                                                                             String statsDate, final String graphName);
}
