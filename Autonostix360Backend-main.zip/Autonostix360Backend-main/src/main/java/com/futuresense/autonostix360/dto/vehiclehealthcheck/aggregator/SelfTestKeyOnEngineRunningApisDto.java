package com.futuresense.autonostix360.dto.vehiclehealthcheck.aggregator;

import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoerDto;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoerPostTestResultsDto;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoerPreTestResultsDto;

import java.util.List;

/**
 * Dto class for aggregated api for self test key on engine running apis
 */
public class SelfTestKeyOnEngineRunningApisDto {
    private List<KoerDto> koer;

    private List<KoerPostTestResultsDto> koerPostTestResults;

    private List<KoerPreTestResultsDto> koerPreTestResults;


    public List<KoerDto> getKoer() {
        return koer;
    }

    public void setKoer(List<KoerDto> koer) {
        this.koer = koer;
    }

    public List<KoerPostTestResultsDto> getKoerPostTestResults() {
        return koerPostTestResults;
    }

    public void setKoerPostTestResults(List<KoerPostTestResultsDto> koerPostTestResults) {
        this.koerPostTestResults = koerPostTestResults;
    }

    public List<KoerPreTestResultsDto> getKoerPreTestResults() {
        return koerPreTestResults;
    }

    public void setKoerPreTestResults(List<KoerPreTestResultsDto> koerPreTestResults) {
        this.koerPreTestResults = koerPreTestResults;
    }
}
