package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TirePressureByLastMiles;
import com.futuresense.autonostix360.dto.usageprofile.TirePressureByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TirePressureByLastMilesMapper implements EntityMapper<TirePressureByLastMiles, TirePressureByLastMilesDto> {

    @Override
    public TirePressureByLastMiles buildEntity(TirePressureByLastMilesDto dto) {
        final TirePressureByLastMiles entity = new TirePressureByLastMiles();
        entity.setId(dto.getId());
        entity.setTirePressurePsi(dto.getTirePressurePsi());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TirePressureByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public TirePressureByLastMilesDto buildDto(TirePressureByLastMiles entity) {
        final TirePressureByLastMilesDto dto = new TirePressureByLastMilesDto();
        dto.setId(entity.getId());
        dto.setTirePressurePsi(entity.getTirePressurePsi());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TirePressureByLastMiles.class.getCanonicalName();
    }
}
