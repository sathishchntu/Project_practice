package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineCoolantTemperatureByLastMiles;
import com.futuresense.autonostix360.domain.usageprofile.TransmissionOilTemperatureByLastMiles;
import com.futuresense.autonostix360.dto.usageprofile.TransmissionOilTemperatureByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TransmissionOilTemperatureByLastMilesMapper implements EntityMapper<TransmissionOilTemperatureByLastMiles, TransmissionOilTemperatureByLastMilesDto> {
    @Override
    public TransmissionOilTemperatureByLastMiles buildEntity(TransmissionOilTemperatureByLastMilesDto dto) {
        final TransmissionOilTemperatureByLastMiles entity = new TransmissionOilTemperatureByLastMiles();
        entity.setId(dto.getId());
        entity.setTransmissionOilTemperatureFahrenheit(dto.getTransmissionOilTemperatureFahrenheit());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TransmissionOilTemperatureByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public TransmissionOilTemperatureByLastMilesDto buildDto(TransmissionOilTemperatureByLastMiles entity) {
        final TransmissionOilTemperatureByLastMilesDto dto = new TransmissionOilTemperatureByLastMilesDto();
        dto.setId(entity.getId());
        dto.setTransmissionOilTemperatureFahrenheit(entity.getTransmissionOilTemperatureFahrenheit());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineCoolantTemperatureByLastMiles.class.getCanonicalName();
    }
}
