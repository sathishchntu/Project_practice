package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfOverSpeedingEventsByMiles;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfOverSpeedingEventsByMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfOverSpeedingEventsByMilesMapper implements EntityMapper<NoOfOverSpeedingEventsByMiles, NoOfOverSpeedingEventsByMilesDto> {
    @Override
    public NoOfOverSpeedingEventsByMiles buildEntity(NoOfOverSpeedingEventsByMilesDto dto) {
        final NoOfOverSpeedingEventsByMiles entity = new NoOfOverSpeedingEventsByMiles();
        entity.setId(dto.getId());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setNoOfOverSpeeding(dto.getNoOfOverSpeeding());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return NoOfOverSpeedingEventsByMilesDto.class.getCanonicalName();
    }

    @Override
    public NoOfOverSpeedingEventsByMilesDto buildDto(NoOfOverSpeedingEventsByMiles entity) {
        final NoOfOverSpeedingEventsByMilesDto dto = new NoOfOverSpeedingEventsByMilesDto();
        dto.setId(entity.getId());
        dto.setMiles(entity.getMiles());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setNoOfOverSpeeding(entity.getNoOfOverSpeeding());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfOverSpeedingEventsByMiles.class.getCanonicalName();
    }
}
