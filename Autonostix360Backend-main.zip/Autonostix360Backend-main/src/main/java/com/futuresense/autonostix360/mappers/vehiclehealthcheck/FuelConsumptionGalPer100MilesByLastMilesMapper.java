package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.FuelConsumptionGalPer100MilesByLastMiles;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.FuelConsumptionGalPer100MilesByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class FuelConsumptionGalPer100MilesByLastMilesMapper implements EntityMapper<FuelConsumptionGalPer100MilesByLastMiles, FuelConsumptionGalPer100MilesByLastMilesDto> {

    @Override
    public FuelConsumptionGalPer100MilesByLastMiles buildEntity(FuelConsumptionGalPer100MilesByLastMilesDto dto) {
        final FuelConsumptionGalPer100MilesByLastMiles entity = new FuelConsumptionGalPer100MilesByLastMiles();
        entity.setId(dto.getId());
        entity.setGalPer100Miles(dto.getGalPer100Miles());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return FuelConsumptionGalPer100MilesByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public FuelConsumptionGalPer100MilesByLastMilesDto buildDto(FuelConsumptionGalPer100MilesByLastMiles entity) {
        final FuelConsumptionGalPer100MilesByLastMilesDto dto = new FuelConsumptionGalPer100MilesByLastMilesDto();
        dto.setId(entity.getId());
        dto.setGalPer100Miles(entity.getGalPer100Miles());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());

        return dto;
    }

    @Override
    public String entityClassName() {
        return FuelConsumptionGalPer100MilesByLastMiles.class.getCanonicalName();
    }
}
