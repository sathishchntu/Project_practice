package com.futuresense.autonostix360.mappers.maintenancelogs.score;

import com.futuresense.autonostix360.domain.maintenancelogs.score.UsageBasedMaintenance;
import com.futuresense.autonostix360.dto.maintenancelogs.score.UsageBasedMaintenanceDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

@Service
public class UsageBasedMaintenanceMapper implements EntityMapper<UsageBasedMaintenance, UsageBasedMaintenanceDto> {

    @Override
    public UsageBasedMaintenance buildEntity(UsageBasedMaintenanceDto dto) {
        UsageBasedMaintenance entity = new UsageBasedMaintenance();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setMaintenanceActivity(dto.getMaintenanceActivity());
        entity.setMetric(dto.getMetric());
        entity.setScheduled(dto.getScheduled());
        entity.setCompleted(dto.getCompleted());
        entity.setViolation(dto.getViolation());
        entity.setWeighnigFactor(dto.getWeighnigFactor());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return UsageBasedMaintenanceDto.class.getCanonicalName();
    }

    @Override
    public UsageBasedMaintenanceDto buildDto(UsageBasedMaintenance entity) {
        UsageBasedMaintenanceDto dto = new UsageBasedMaintenanceDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setMaintenanceActivity(entity.getMaintenanceActivity());
        dto.setMetric(entity.getMetric());
        dto.setScheduled(entity.getScheduled());
        dto.setCompleted(entity.getCompleted());
        dto.setViolation(entity.getViolation());
        dto.setWeighnigFactor(entity.getWeighnigFactor());

        return dto;
    }

    @Override
    public String entityClassName() {
        return UsageBasedMaintenance.class.getCanonicalName();
    }
}