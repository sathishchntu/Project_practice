package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.DrivingUnpavedRoadRouteAdherenceByTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * DrivingUnpavedRoadRouteAdherenceByTripRepository
 */
public interface DrivingUnpavedRoadRouteAdherenceByTripRepository extends CassandraRepository<DrivingUnpavedRoadRouteAdherenceByTrip, String> {

    @Query(value = "select max(trip) from driving_unpaved_road_route_adherence_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from driving_unpaved_road_route_adherence_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<DrivingUnpavedRoadRouteAdherenceByTrip> findDrivingUnpavedRoadRouteAdherenceByLastTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}