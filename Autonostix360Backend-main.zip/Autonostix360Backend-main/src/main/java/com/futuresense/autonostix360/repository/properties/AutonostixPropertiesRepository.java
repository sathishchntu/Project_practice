package com.futuresense.autonostix360.repository.properties;

import com.futuresense.autonostix360.domain.properties.AutonostixProperties;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * AutonostixPropertiesRepository
 */
public interface AutonostixPropertiesRepository extends CassandraRepository<AutonostixProperties, String> {

    @Query(value = "select * from autonostix_properties")
    List<AutonostixProperties> findAll();
}
