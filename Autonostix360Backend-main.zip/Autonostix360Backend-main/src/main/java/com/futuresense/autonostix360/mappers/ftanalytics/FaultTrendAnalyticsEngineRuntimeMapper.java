package com.futuresense.autonostix360.mappers.ftanalytics;

import com.futuresense.autonostix360.domain.ftanalytics.FaultTrendAnalyticsEngineRuntime;
import com.futuresense.autonostix360.dto.ftanalytics.FaultTrendAnalyticsEngineRuntimeDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class FaultTrendAnalyticsEngineRuntimeMapper implements EntityMapper<FaultTrendAnalyticsEngineRuntime, FaultTrendAnalyticsEngineRuntimeDto> {

    @Override
    public FaultTrendAnalyticsEngineRuntime buildEntity(FaultTrendAnalyticsEngineRuntimeDto dto) {
        final FaultTrendAnalyticsEngineRuntime entity = new FaultTrendAnalyticsEngineRuntime();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setName(dto.getName());
        entity.setDtcCode(dto.getDtcCode());
        entity.setDescription(dto.getDescription());
        entity.setSubSystem(dto.getSubSystem());
        entity.setRulEngineRunTime(dto.getRulEngineRunTime());
        entity.setModule(dto.getModule());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setOdometer(dto.getOdometer());
        entity.setRulMiles(dto.getRulMiles());
        entity.setRulHours(dto.getRulHours());
        entity.setRulKeyStarts(dto.getRulKeyStarts());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return FaultTrendAnalyticsEngineRuntimeDto.class.getCanonicalName();
    }

    @Override
    public FaultTrendAnalyticsEngineRuntimeDto buildDto(FaultTrendAnalyticsEngineRuntime entity) {
        final FaultTrendAnalyticsEngineRuntimeDto dto = new FaultTrendAnalyticsEngineRuntimeDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setName(entity.getName());
        dto.setDtcCode(entity.getDtcCode());
        dto.setDescription(entity.getDescription());
        dto.setSubSystem(entity.getSubSystem());
        dto.setRulEngineRunTime(entity.getRulEngineRunTime());
        dto.setModule(entity.getModule());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setOdometer(entity.getOdometer());
        dto.setRulMiles(entity.getRulMiles());
        dto.setRulHours(entity.getRulHours());
        dto.setRulKeyStarts(entity.getRulKeyStarts());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return FaultTrendAnalyticsEngineRuntime.class.getCanonicalName();
    }
}
