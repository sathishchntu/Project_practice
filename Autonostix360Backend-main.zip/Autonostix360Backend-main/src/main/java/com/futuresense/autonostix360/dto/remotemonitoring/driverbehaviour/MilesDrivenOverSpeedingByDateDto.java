package com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.MilesDrivenOverSpeedingByDate}.
 */
public class MilesDrivenOverSpeedingByDateDto implements Serializable {

    private UUID id;

    private Date statsDate;

    private Integer miles;

    private Double hours;

    private String threshold;

    private Integer engineRunTime;

    private Integer keyStarts;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Date getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(Date statsDate) {
        this.statsDate = statsDate;
    }

    public Integer getMiles() {
        return miles;
    }

    public void setMiles(Integer miles) {
        this.miles = miles;
    }

    public Double getHours() {
        return hours;
    }

    public void setHours(Double hours) {
        this.hours = hours;
    }

    public String getThreshold() {
        return threshold;
    }

    public void setThreshold(String threshold) {
        this.threshold = threshold;
    }

    public Integer getEngineRunTime() {
        return engineRunTime;
    }

    public void setEngineRunTime(Integer engineRunTime) {
        this.engineRunTime = engineRunTime;
    }

    public Integer getKeyStarts() {
        return keyStarts;
    }

    public void setKeyStarts(Integer keyStarts) {
        this.keyStarts = keyStarts;
    }
}
