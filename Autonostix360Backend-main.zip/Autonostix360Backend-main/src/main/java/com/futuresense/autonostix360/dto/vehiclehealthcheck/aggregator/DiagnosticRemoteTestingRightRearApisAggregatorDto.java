package com.futuresense.autonostix360.dto.vehiclehealthcheck.aggregator;

import com.futuresense.autonostix360.dto.vehiclehealthcheck.RightRearBreakPadWearDto;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.RightRearValveInLetDto;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.RightRearValveOutLetDto;

import java.io.Serializable;
import java.util.List;

/**
 * Dto class for aggregated api for right rear apis
 */
public class DiagnosticRemoteTestingRightRearApisAggregatorDto implements Serializable {

    private List<RightRearBreakPadWearDto> rightRearBreakPadWear;

    private List<RightRearValveInLetDto> rightRearValveInLet;

    private List<RightRearValveOutLetDto> rightRearValveOutLet;

    public List<RightRearBreakPadWearDto> getRightRearBreakPadWear() {
        return rightRearBreakPadWear;
    }

    public void setRightRearBreakPadWear(List<RightRearBreakPadWearDto> rightRearBreakPadWear) {
        this.rightRearBreakPadWear = rightRearBreakPadWear;
    }

    public List<RightRearValveInLetDto> getRightRearValveInLet() {
        return rightRearValveInLet;
    }

    public void setRightRearValveInLet(List<RightRearValveInLetDto> rightRearValveInLet) {
        this.rightRearValveInLet = rightRearValveInLet;
    }

    public List<RightRearValveOutLetDto> getRightRearValveOutLet() {
        return rightRearValveOutLet;
    }

    public void setRightRearValveOutLet(List<RightRearValveOutLetDto> rightRearValveOutLet) {
        this.rightRearValveOutLet = rightRearValveOutLet;
    }
}
