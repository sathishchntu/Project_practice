package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.TrafficSignalViolationByTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * TrafficSignalViolationByTripRepository
 */
public interface TrafficSignalViolationByTripRepository extends CassandraRepository<TrafficSignalViolationByTrip, String> {

    @Query(value = "select max(trip) from traffic_signal_violation_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from traffic_signal_violation_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<TrafficSignalViolationByTrip> findTrafficSignalViolationByLastTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}
