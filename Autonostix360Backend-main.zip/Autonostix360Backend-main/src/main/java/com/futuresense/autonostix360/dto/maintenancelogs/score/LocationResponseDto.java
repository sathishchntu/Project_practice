package com.futuresense.autonostix360.dto.maintenancelogs.score;

import org.springframework.data.domain.Page;

import java.io.Serializable;

/**
 * Custom response object for Location
 */
public class LocationResponseDto implements Serializable {

    private Page<LocationDto> paginatedResponse;

    private String messages;

    public Page<LocationDto> getPaginatedResponse() {
        return paginatedResponse;
    }

    public void setPaginatedResponse(Page<LocationDto> paginatedResponse) {
        this.paginatedResponse = paginatedResponse;
    }

    public String getMessages() {
        return messages;
    }

    public void setMessages(String messages) {
        this.messages = messages;
    }
}
