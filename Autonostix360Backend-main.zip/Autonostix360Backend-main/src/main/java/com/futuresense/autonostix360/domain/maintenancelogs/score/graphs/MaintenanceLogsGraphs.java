package com.futuresense.autonostix360.domain.maintenancelogs.score.graphs;

import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entity MaintenanceLogsGraphs represents table maintenance_logs_graphs
 */
@Table(value = "maintenance_logs_graphs")
public class MaintenanceLogsGraphs {

    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("stats_date")
    private String statsDate;

    @PartitionKey(4)
    @Column("graph_name")
    private String graphName;

    @Column("last_updated")
    private Timestamp lastUpdated;

    @Column("x_axis_name")
    private String xAxisName;

    @Column("y_axis_name")
    private String yAxisName;

    @Column("x_axis_data")
    private Double xAxisData;

    @Column("y_axis_data")
    private Double yAxisData;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getGraphName() {
        return graphName;
    }

    public void setGraphName(String graphName) {
        this.graphName = graphName;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getxAxisName() {
        return xAxisName;
    }

    public void setxAxisName(String xAxisName) {
        this.xAxisName = xAxisName;
    }

    public String getyAxisName() {
        return yAxisName;
    }

    public void setyAxisName(String yAxisName) {
        this.yAxisName = yAxisName;
    }

    public Double getxAxisData() {
        return xAxisData;
    }

    public void setxAxisData(Double xAxisData) {
        this.xAxisData = xAxisData;
    }

    public Double getyAxisData() {
        return yAxisData;
    }

    public void setyAxisData(Double yAxisData) {
        this.yAxisData = yAxisData;
    }
}