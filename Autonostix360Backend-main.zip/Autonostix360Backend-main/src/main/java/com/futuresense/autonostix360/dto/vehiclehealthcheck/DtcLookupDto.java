package com.futuresense.autonostix360.dto.vehiclehealthcheck;

import java.io.Serializable;

/**
 * This dto will be used for DTC Details cache lookup
 */
public class DtcLookupDto implements Serializable {

    private Integer identifier;

    private String dtcCode;

    private String description;

    public DtcLookupDto(String dtcCode, String description, Integer identifier) {
        this.dtcCode = dtcCode;
        this.description = description;
        this.identifier = identifier;
    }

    public Integer getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Integer identifier) {
        this.identifier = identifier;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
