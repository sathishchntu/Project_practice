package com.futuresense.autonostix360.mappers.coreinterfaces;

public interface IDtoToEntity<E, D> {
    E buildEntity(D dto);

    String dtoClassName();
}