package com.futuresense.autonostix360.repository.maintenancelogs;

import com.futuresense.autonostix360.domain.maintenancelogs.MaintenanceLogs;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;
import java.util.UUID;

/**
 * MaintenanceLogsRepository
 */
public interface MaintenanceLogsRepository extends CassandraRepository<MaintenanceLogs, UUID> {

    @Deprecated
    @Query(value = "select * from maintenance_logs " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId ")
    Slice<MaintenanceLogs> findByVinNumberAndOrganizationId(CassandraPageRequest first, String vinNumber, Integer organizationId);

    @Deprecated
    @Query(value = "select * from maintenance_logs " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId ")
    Slice<MaintenanceLogs> findByVinNumberAndOrganizationIdWithPageable(String vinNumber, Integer organizationId, Pageable pageable);

    @Deprecated
    @Query(value = "select count(*) from maintenance_logs " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId ")
    int findCountByVinNumberAndOrganizationId(String vinNumber, Integer organizationId, String partitionYear);

    List<MaintenanceLogs> findByVinNumberAndOrganizationId(String vinNumber, Integer organizationId);
}
