package com.futuresense.autonostix360.dto.ftanalytics.graphs;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * request dto for post request on fault trend analytics rul graphs
 */
public class FaultTrendAnalyticsRulGraphsRequestDto implements Serializable {

    @NotNull
    private String vinNumber;

    @NotNull
    private Integer organizationId;

    @NotNull
    private String statsDate;

    @NotNull
    private String dtcCode;

    @NotNull
    private String graphName;

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getGraphName() {
        return graphName;
    }

    public void setGraphName(String graphName) {
        this.graphName = graphName;
    }
}