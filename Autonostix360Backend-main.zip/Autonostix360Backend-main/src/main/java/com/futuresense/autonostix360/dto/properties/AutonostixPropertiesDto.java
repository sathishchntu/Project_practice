package com.futuresense.autonostix360.dto.properties;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Dto class for public class AutonostixProperties entity
 */
public class AutonostixPropertiesDto {

    private UUID id;

    private String vinNumber;

    private Integer organizationId;

    private String propertyForTable;

    private String propertyName;

    private String propertyValue;

    private Timestamp lastUpdated;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getPropertyForTable() {
        return propertyForTable;
    }

    public void setPropertyForTable(String propertyForTable) {
        this.propertyForTable = propertyForTable;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(String propertyValue) {
        this.propertyValue = propertyValue;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
