package com.futuresense.autonostix360.repository.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TirePressureByLastTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * TirePressureByLastTripRepository
 */
public interface TirePressureByLastTripRepository extends CassandraRepository<TirePressureByLastTrip, Long> {

    @Query(value = "select max(trip) from tire_pressure_by_last_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from tire_pressure_by_last_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<TirePressureByLastTrip> findTirePressureByLastTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}
