package com.futuresense.autonostix360.repository.search;

import com.futuresense.autonostix360.domain.search.MaintenanceLog;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import java.util.List;

/**
 * ElasticSearch repository for Maintenance Logs
 */
public interface MaintenanceLogRepository extends ElasticsearchRepository<MaintenanceLog, String> {

    List<MaintenanceLog> findAllByVinNumberAndOrganizationIdOrderByStatsDateDesc(String vinNumber, Integer organizationId);

    List<MaintenanceLog> findAllByVinNumberAndOrganizationIdOrderByStatsDateDesc(String vinNumber, Integer organizationId, Pageable pageable);

    List<MaintenanceLog> findAll();
}
