package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TransmissionGearByLastDate;
import com.futuresense.autonostix360.dto.usageprofile.TransmissionGearByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TransmissionGearByLastDateMapper implements EntityMapper<TransmissionGearByLastDate, TransmissionGearByLastDateDto> {

    @Override
    public TransmissionGearByLastDate buildEntity(TransmissionGearByLastDateDto dto) {
        final TransmissionGearByLastDate entity = new TransmissionGearByLastDate();
        entity.setId(dto.getId());
        entity.setTransmissionGear(dto.getTransmissionGear());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TransmissionGearByLastDateDto.class.getCanonicalName();
    }

    @Override
    public TransmissionGearByLastDateDto buildDto(TransmissionGearByLastDate entity) {
        final TransmissionGearByLastDateDto dto = new TransmissionGearByLastDateDto();
        dto.setId(entity.getId());
        dto.setTransmissionGear(entity.getTransmissionGear());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TransmissionGearByLastDate.class.getCanonicalName();
    }
}
