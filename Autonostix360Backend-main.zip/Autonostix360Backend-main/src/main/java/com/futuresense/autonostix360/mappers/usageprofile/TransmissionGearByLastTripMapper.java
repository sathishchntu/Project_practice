package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TransmissionGearByLastTrip;
import com.futuresense.autonostix360.dto.usageprofile.TransmissionGearByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TransmissionGearByLastTripMapper implements EntityMapper<TransmissionGearByLastTrip, TransmissionGearByLastTripDto> {
    @Override
    public TransmissionGearByLastTrip buildEntity(TransmissionGearByLastTripDto dto) {
        final TransmissionGearByLastTrip entity = new TransmissionGearByLastTrip();
        entity.setId(dto.getId());
        entity.setTransmissionGear(dto.getTransmissionGear());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TransmissionGearByLastTripDto.class.getCanonicalName();
    }

    @Override
    public TransmissionGearByLastTripDto buildDto(TransmissionGearByLastTrip entity) {
        final TransmissionGearByLastTripDto dto = new TransmissionGearByLastTripDto();
        dto.setId(entity.getId());
        dto.setTransmissionGear(entity.getTransmissionGear());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TransmissionGearByLastTrip.class.getCanonicalName();
    }
}
