package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfRapidAccelerationByTrip;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * NoOfRapidAccelerationByTripRepository
 */
public interface NoOfRapidAccelerationByTripRepository extends CassandraRepository<NoOfRapidAccelerationByTrip, Long> {

    @Query(value = "select max(trip) from no_of_rapid_acceleration_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    Integer findMaxTripNumber(String vinNumber, Integer organizationId);

    @Query(value = "select * from no_of_rapid_acceleration_by_trip " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and trip > :tripFrom and trip <= :tripTo")
    List<NoOfRapidAccelerationByTrip> findNoOfRapidAccelerationByTripByVinAndOrganizationIdAndTripRange(String vinNumber, Integer organizationId, int tripFrom, int tripTo);
}
