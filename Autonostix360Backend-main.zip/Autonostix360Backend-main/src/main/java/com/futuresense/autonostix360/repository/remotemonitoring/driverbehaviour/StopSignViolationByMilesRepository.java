package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.StopSignViolationByMiles;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * StopSignViolationByMilesRepository
 */
public interface StopSignViolationByMilesRepository extends CassandraRepository<StopSignViolationByMiles, String> {

    @Query("select * from stop_sign_violation_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    List<StopSignViolationByMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId);

    @Query("select max(odometer) from stop_sign_violation_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    Integer findMaxOdometerReadingByVinAndOrganizationId(String vinNumber, Integer organizationId);

    @Query("select * from stop_sign_violation_by_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and odometer >= :fromOdometerReading and odometer <= :maxOdometerReading")
    List<StopSignViolationByMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId, int fromOdometerReading, Integer maxOdometerReading);
}