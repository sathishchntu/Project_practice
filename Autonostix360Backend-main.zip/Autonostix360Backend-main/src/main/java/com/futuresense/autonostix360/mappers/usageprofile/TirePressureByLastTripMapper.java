package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TirePressureByLastTrip;
import com.futuresense.autonostix360.dto.usageprofile.TirePressureByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TirePressureByLastTripMapper implements EntityMapper<TirePressureByLastTrip, TirePressureByLastTripDto> {

    @Override
    public TirePressureByLastTrip buildEntity(TirePressureByLastTripDto dto) {
        final TirePressureByLastTrip entity = new TirePressureByLastTrip();
        entity.setId(dto.getId());
        entity.setTirePressurePsi(dto.getTirePressurePsi());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TirePressureByLastTripDto.class.getCanonicalName();
    }

    @Override
    public TirePressureByLastTripDto buildDto(TirePressureByLastTrip entity) {
        final TirePressureByLastTripDto dto = new TirePressureByLastTripDto();
        dto.setId(entity.getId());
        dto.setTirePressurePsi(entity.getTirePressurePsi());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TirePressureByLastTrip.class.getCanonicalName();
    }
}
