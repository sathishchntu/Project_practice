package com.futuresense.autonostix360.repository.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineCoolantTemperatureByLastDate;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.Date;
import java.util.List;

/**
 * EngineCoolantTemperatureByLastDateRepository
 */
public interface EngineCoolantTemperatureByLastDateRepository extends CassandraRepository<EngineCoolantTemperatureByLastDate, String> {

    @Query(value = "select * from engine_coolant_temperature_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date = :dateString")
    List<EngineCoolantTemperatureByLastDate> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, Date dateString);

    @Query(value = "select * from engine_coolant_temperature_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    List<EngineCoolantTemperatureByLastDate> findAllByVinNumberAndOrganizationId(String vinNumber, Integer organizationId);

    @Query(value = "select * from engine_coolant_temperature_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date >= :fromDate and stats_date <= :toDate")
    List<EngineCoolantTemperatureByLastDate> findByVinNumberAndOrganizationIdAndStatsDateRange(String vinNumber, Integer organizationId, Date fromDate, Date toDate);
}
