package com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfHarshCorneringByMiles}.
 */
public class NoOfHarshCorneringByMilesDto implements Serializable {

    private UUID id;

    private Integer miles;

    private Double hours;

    private Integer engineRunTime;

    private Integer keyStarts;

    private Integer noOfHarshCornering;

    private Date statsDate;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Integer getMiles() {
        return miles;
    }

    public void setMiles(Integer miles) {
        this.miles = miles;
    }

    public Double getHours() {
        return hours;
    }

    public void setHours(Double hours) {
        this.hours = hours;
    }

    public Integer getEngineRunTime() {
        return engineRunTime;
    }

    public void setEngineRunTime(Integer engineRunTime) {
        this.engineRunTime = engineRunTime;
    }

    public Integer getKeyStarts() {
        return keyStarts;
    }

    public void setKeyStarts(Integer keyStarts) {
        this.keyStarts = keyStarts;
    }

    public Integer getNoOfHarshCornering() {
        return noOfHarshCornering;
    }

    public void setNoOfHarshCornering(Integer noOfHarshCornering) {
        this.noOfHarshCornering = noOfHarshCornering;
    }

    public Date getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(Date statsDate) {
        this.statsDate = statsDate;
    }
}
