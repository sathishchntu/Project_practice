package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfHarshCorneringByTrip;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfHarshCorneringByTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfHarshCorneringByTripMapper implements EntityMapper<NoOfHarshCorneringByTrip, NoOfHarshCorneringByTripDto> {

    @Override
    public NoOfHarshCorneringByTrip buildEntity(NoOfHarshCorneringByTripDto dto) {
        final NoOfHarshCorneringByTrip entity = new NoOfHarshCorneringByTrip();
        entity.setId(dto.getId());
        entity.setTrip(dto.getTrip());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setNoOfHarshCornering(dto.getNoOfHarshCornering());
        entity.setStatsDate(dto.getStatsDate());
        return entity;

    }

    @Override
    public String dtoClassName() {
        return NoOfHarshCorneringByTripDto.class.getCanonicalName();
    }

    @Override
    public NoOfHarshCorneringByTripDto buildDto(NoOfHarshCorneringByTrip entity) {
        final NoOfHarshCorneringByTripDto dto = new NoOfHarshCorneringByTripDto();
        dto.setId(entity.getId());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setNoOfHarshCornering(entity.getNoOfHarshCornering());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfHarshCorneringByTrip.class.getCanonicalName();
    }
}

