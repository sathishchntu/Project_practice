package com.futuresense.autonostix360.mappers.search;

import com.futuresense.autonostix360.domain.search.MaintenanceLog;
import com.futuresense.autonostix360.dto.search.MaintenanceLogDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class MaintenanceLogMapper implements EntityMapper<MaintenanceLog, MaintenanceLogDto> {
    @Override
    public MaintenanceLog buildEntity(MaintenanceLogDto dto) {
        final MaintenanceLog entity = new MaintenanceLog();
        entity.setId(dto.getId());
        entity.setMaintenanceActivity(dto.getMaintenanceActivity());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setPartitionYear(String.valueOf(LocalDate.now().getYear()));
        entity.setDtcCode(StringUtils.isNotEmpty(dto.getDtcCode()) ? dto.getDtcCode() : "");
        entity.setSubSystem(StringUtils.isNotEmpty(dto.getSubSystem()) ? dto.getSubSystem() : "");
        entity.setDescription(StringUtils.isNotEmpty(dto.getDescription()) ? dto.getDescription() : "");
        entity.setOdometer(dto.getOdometer());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return MaintenanceLogDto.class.getCanonicalName();
    }

    @Override
    public MaintenanceLogDto buildDto(MaintenanceLog entity) {
        final MaintenanceLogDto dto = new MaintenanceLogDto();
        dto.setId(entity.getId());
        dto.setMaintenanceActivity(entity.getMaintenanceActivity());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setDtcCode(entity.getDtcCode());
        dto.setSubSystem(entity.getSubSystem());
        dto.setDescription(entity.getDescription());
        dto.setOdometer(entity.getOdometer());
        dto.setStatsDate(entity.getStatsDate());
        dto.setPartitionYear(entity.getPartitionYear());
        return dto;
    }

    @Override
    public String entityClassName() {
        return MaintenanceLog.class.getCanonicalName();
    }
}
