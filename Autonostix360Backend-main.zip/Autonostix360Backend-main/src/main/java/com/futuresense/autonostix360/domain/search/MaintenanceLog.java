package com.futuresense.autonostix360.domain.search;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import static com.futuresense.autonostix360.util.Indices.MAINTENANCE_LOGS_INDEX;

/**
 * Elasticsearch document representing MaintenanceLogs
 */
@Document(indexName = MAINTENANCE_LOGS_INDEX, createIndex = true)
public class MaintenanceLog {

    @Id
    private String id;

    private String maintenanceActivity;

    private String vinNumber;

    private Integer organizationId;

    private String partitionYear;

    private String dtcCode;

    private String subSystem;

    private String description;

    private Integer odometer;

    private String statsDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMaintenanceActivity() {
        return maintenanceActivity;
    }

    public void setMaintenanceActivity(String maintenanceActivity) {
        this.maintenanceActivity = maintenanceActivity;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getPartitionYear() {
        return partitionYear;
    }

    public void setPartitionYear(String partitionYear) {
        this.partitionYear = partitionYear;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getSubSystem() {
        return subSystem;
    }

    public void setSubSystem(String subSystem) {
        this.subSystem = subSystem;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    @Override
    public String toString() {
        return "MaintenanceLog{" +
                "id='" + id + '\'' +
                ", maintenanceActivity='" + maintenanceActivity + '\'' +
                ", vinNumber='" + vinNumber + '\'' +
                ", organizationId=" + organizationId +
                ", partitionYear='" + partitionYear + '\'' +
                ", dtcCode='" + dtcCode + '\'' +
                ", subSystem='" + subSystem + '\'' +
                ", description='" + description + '\'' +
                ", odometer=" + odometer +
                ", statsDate='" + statsDate + '\'' +
                '}';
    }
}
