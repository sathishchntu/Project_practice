package com.futuresense.autonostix360.mappers.ftanalytics;

import com.futuresense.autonostix360.domain.ftanalytics.FaultTrendAnalyticsEngineStarts;
import com.futuresense.autonostix360.dto.ftanalytics.FaultTrendAnalyticsEngineStartsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class FaultTrendAnalyticsEngineStartsMapper implements EntityMapper<FaultTrendAnalyticsEngineStarts, FaultTrendAnalyticsEngineStartsDto> {

    @Override
    public FaultTrendAnalyticsEngineStarts buildEntity(FaultTrendAnalyticsEngineStartsDto dto) {
        final FaultTrendAnalyticsEngineStarts entity = new FaultTrendAnalyticsEngineStarts();
        entity.setId(dto.getId());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setDescription(dto.getDescription());
        entity.setDtcCode(dto.getDtcCode());
        entity.setModule(dto.getModule());
        entity.setName(dto.getName());
        entity.setRulKeyStarts(dto.getRulKeyStarts());
        entity.setSubsystem(dto.getSubsystem());
        entity.setOdometer(dto.getOdometer());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setRulMiles(dto.getRulMiles());
        entity.setRulHours(dto.getRulHours());
        entity.setRulEngineRunTime(dto.getRulEngineRunTime());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return FaultTrendAnalyticsEngineStartsDto.class.getCanonicalName();
    }

    @Override
    public FaultTrendAnalyticsEngineStartsDto buildDto(FaultTrendAnalyticsEngineStarts entity) {
        final FaultTrendAnalyticsEngineStartsDto dto = new FaultTrendAnalyticsEngineStartsDto();
        dto.setId(entity.getId());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setDescription(entity.getDescription());
        dto.setDtcCode(entity.getDtcCode());
        dto.setModule(entity.getModule());
        dto.setName(entity.getName());
        dto.setRulKeyStarts(entity.getRulKeyStarts());
        dto.setSubsystem(entity.getSubsystem());
        dto.setOdometer(entity.getOdometer());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setRulMiles(entity.getRulMiles());
        dto.setRulHours(entity.getRulHours());
        dto.setRulEngineRunTime(entity.getRulEngineRunTime());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return FaultTrendAnalyticsEngineStarts.class.getCanonicalName();
    }
}
