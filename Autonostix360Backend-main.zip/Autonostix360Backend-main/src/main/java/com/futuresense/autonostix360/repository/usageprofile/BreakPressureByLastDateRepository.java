package com.futuresense.autonostix360.repository.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.BreakPressureByLastDate;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.Date;
import java.util.List;

/**
 * BreakPressureByLastDateRepository
 */
public interface BreakPressureByLastDateRepository extends CassandraRepository<BreakPressureByLastDate, String> {

    @Query(value = "select * from break_pressure_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date = :dateString")
    List<BreakPressureByLastDate> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, Date dateString);

    @Query(value = "select * from break_pressure_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId")
    List<BreakPressureByLastDate> findAllByVinNumberAndOrganizationId(String vinNumber, Integer organizationId);

    @Query(value = "select * from break_pressure_by_last_date " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "stats_date >= :fromDate and stats_date <= :toDate")
    List<BreakPressureByLastDate> findByVinNumberAndOrganizationIdAndStatsDateRange(String vinNumber, Integer organizationId, Date fromDate, Date toDate);
}
