package com.futuresense.autonostix360.repository.ftanalytics;

import com.futuresense.autonostix360.domain.ftanalytics.FaultTrendAnalyticsEngineRuntime;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.UUID;

/**
 * FaultTrendAnalyticsEngineRuntimeRepository
 */

public interface FaultTrendAnalyticsEngineRuntimeRepository extends CassandraRepository<FaultTrendAnalyticsEngineRuntime, UUID> {

    @Query(value = "select * from fault_trend_analytics_engine_runtime " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_engine_runtime_hours >= :fromRulEngineRuntimeHours and rul_engine_runtime_hours <= :toRulEngineRuntimeHours")
    Slice<FaultTrendAnalyticsEngineRuntime> findByVinNumberAndOrganizationIdAndEngineRuntimeHoursRange(String vinNumber, Integer organizationId, Integer fromRulEngineRuntimeHours, Integer toRulEngineRuntimeHours, Pageable pageable);

    @Query(value = "select count(*) from fault_trend_analytics_engine_runtime " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_engine_runtime_hours >= :fromRulEngineRuntimeHours and rul_engine_runtime_hours <= :toRulEngineRuntimeHours"
    )
    int pageCount(String vinNumber, Integer organizationId, Integer fromRulEngineRuntimeHours, Integer toRulEngineRuntimeHours);

    @Query(value = "select * from fault_trend_analytics_engine_runtime " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_engine_runtime_hours >= :fromRulEngineRuntimeHours and rul_engine_runtime_hours <= :toRulEngineRuntimeHours")
    Slice<FaultTrendAnalyticsEngineRuntime> findAllByVinNumberAndOrganizationIdAndEngineRuntimeHoursRange(CassandraPageRequest pageRequest, String vinNumber, Integer organizationId, Integer fromRulEngineRuntimeHours, Integer toRulEngineRuntimeHours);
}
