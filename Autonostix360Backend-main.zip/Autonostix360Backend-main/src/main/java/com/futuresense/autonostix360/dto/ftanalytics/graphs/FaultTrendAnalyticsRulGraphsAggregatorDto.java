package com.futuresense.autonostix360.dto.ftanalytics.graphs;

import java.io.Serializable;
import java.util.List;

/**
 * Dto class for aggregated api for fault trend analytics rul graph apis
 */
public class FaultTrendAnalyticsRulGraphsAggregatorDto implements Serializable {

    private List<FaultTrendAnalyticRulGraphsDto> faultTrendAnalyticsRulGraphs;

    private FaultTrendAnalyticsRulGraphsThresholdsDto faultTrendAnalyticsRulGraphsThresholds;

    public List<FaultTrendAnalyticRulGraphsDto> getFaultTrendAnalyticsRulGraphs() {
        return faultTrendAnalyticsRulGraphs;
    }

    public void setFaultTrendAnalyticsRulGraphs(List<FaultTrendAnalyticRulGraphsDto> faultTrendAnalyticsRulGraphs) {
        this.faultTrendAnalyticsRulGraphs = faultTrendAnalyticsRulGraphs;
    }

    public FaultTrendAnalyticsRulGraphsThresholdsDto getFaultTrendAnalyticsRulGraphsThresholds() {
        return faultTrendAnalyticsRulGraphsThresholds;
    }

    public void setFaultTrendAnalyticsRulGraphsThresholds(FaultTrendAnalyticsRulGraphsThresholdsDto faultTrendAnalyticsRulGraphsThresholds) {
        this.faultTrendAnalyticsRulGraphsThresholds = faultTrendAnalyticsRulGraphsThresholds;
    }
}
