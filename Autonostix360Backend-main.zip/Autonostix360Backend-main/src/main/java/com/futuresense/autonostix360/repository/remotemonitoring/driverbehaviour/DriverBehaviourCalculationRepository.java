package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.DriverBehaviourCalculation;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

/**
 * Repository for DriverBehaviourCalculation
 */
public interface DriverBehaviourCalculationRepository extends CassandraRepository<DriverBehaviourCalculation, String> {

    List<DriverBehaviourCalculation> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, String statsDate1);
}
