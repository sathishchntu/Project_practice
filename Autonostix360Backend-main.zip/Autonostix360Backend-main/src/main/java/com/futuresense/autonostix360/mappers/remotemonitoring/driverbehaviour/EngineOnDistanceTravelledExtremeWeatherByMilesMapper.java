package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.EngineOnDistanceTravelledExtremeWeatherByMiles;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.EngineOnDistanceTravelledExtremeWeatherByMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineOnDistanceTravelledExtremeWeatherByMilesMapper implements EntityMapper<EngineOnDistanceTravelledExtremeWeatherByMiles, EngineOnDistanceTravelledExtremeWeatherByMilesDto> {

    @Override
    public EngineOnDistanceTravelledExtremeWeatherByMiles buildEntity(EngineOnDistanceTravelledExtremeWeatherByMilesDto dto) {
        final EngineOnDistanceTravelledExtremeWeatherByMiles entity = new EngineOnDistanceTravelledExtremeWeatherByMiles();
        entity.setId(dto.getId());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineOnDistanceTravelledExtremeWeatherByMilesDto.class.getCanonicalName();
    }

    @Override
    public EngineOnDistanceTravelledExtremeWeatherByMilesDto buildDto(EngineOnDistanceTravelledExtremeWeatherByMiles entity) {
        final EngineOnDistanceTravelledExtremeWeatherByMilesDto dto = new EngineOnDistanceTravelledExtremeWeatherByMilesDto();
        dto.setId(entity.getId());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineOnDistanceTravelledExtremeWeatherByMiles.class.getCanonicalName();
    }
}