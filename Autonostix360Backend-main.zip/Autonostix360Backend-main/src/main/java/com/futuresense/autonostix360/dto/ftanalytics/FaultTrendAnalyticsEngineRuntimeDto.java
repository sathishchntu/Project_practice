package com.futuresense.autonostix360.dto.ftanalytics;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.ftanalytics.FaultTrendAnalyticsEngineRuntime}.
 */
public class FaultTrendAnalyticsEngineRuntimeDto implements Serializable {

    private UUID id;

    private String vinNumber;

    private Integer organizationId;

    private String name;

    private String dtcCode;

    private String description;

    private String subSystem;

    private Integer rulEngineRunTime;

    private String module;

    private Timestamp lastUpdated;

    private Integer odometer;

    private Double rulMiles;

    private Double rulHours;

    private Integer rulKeyStarts;

    private String statsDate;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSubSystem() {
        return subSystem;
    }

    public void setSubSystem(String subSystem) {
        this.subSystem = subSystem;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public Integer getRulEngineRunTime() {
        return rulEngineRunTime;
    }

    public void setRulEngineRunTime(Integer rulEngineRunTime) {
        this.rulEngineRunTime = rulEngineRunTime;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Double getRulMiles() {
        return rulMiles;
    }

    public void setRulMiles(Double rulMiles) {
        this.rulMiles = rulMiles;
    }

    public Double getRulHours() {
        return rulHours;
    }

    public void setRulHours(Double rulHours) {
        this.rulHours = rulHours;
    }

    public Integer getRulKeyStarts() {
        return rulKeyStarts;
    }

    public void setRulKeyStarts(Integer rulKeyStarts) {
        this.rulKeyStarts = rulKeyStarts;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }
}
