package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfOverSpeedingEventsByTrip;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfOverSpeedingEventsByTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfOverSpeedingEventsByTripMapper implements EntityMapper<NoOfOverSpeedingEventsByTrip, NoOfOverSpeedingEventsByTripDto> {

    @Override
    public NoOfOverSpeedingEventsByTrip buildEntity(NoOfOverSpeedingEventsByTripDto dto) {
        final NoOfOverSpeedingEventsByTrip entity = new NoOfOverSpeedingEventsByTrip();
        entity.setId(dto.getId());
        entity.setTrip(dto.getTrip());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setNoOfOverSpeeding(dto.getNoOfOverSpeeding());
        entity.setStatsDate(dto.getStatsDate());
        return entity;

    }

    @Override
    public String dtoClassName() {
        return NoOfOverSpeedingEventsByTripDto.class.getCanonicalName();
    }

    @Override
    public NoOfOverSpeedingEventsByTripDto buildDto(NoOfOverSpeedingEventsByTrip entity) {
        final NoOfOverSpeedingEventsByTripDto dto = new NoOfOverSpeedingEventsByTripDto();
        dto.setId(entity.getId());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setNoOfOverSpeeding(entity.getNoOfOverSpeeding());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfOverSpeedingEventsByTrip.class.getCanonicalName();
    }
}

