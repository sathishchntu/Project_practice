package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineOilTemperatureByLastTrip;
import com.futuresense.autonostix360.dto.usageprofile.EngineOilTemperatureByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineOilTemperatureByLastTripMapper implements EntityMapper<EngineOilTemperatureByLastTrip, EngineOilTemperatureByLastTripDto> {
    @Override
    public EngineOilTemperatureByLastTrip buildEntity(EngineOilTemperatureByLastTripDto dto) {
        final EngineOilTemperatureByLastTrip entity = new EngineOilTemperatureByLastTrip();
        entity.setId(dto.getId());
        entity.setOilTemperatureFahrenheit(dto.getOilTemperatureFahrenheit());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineOilTemperatureByLastTripDto.class.getCanonicalName();
    }

    @Override
    public EngineOilTemperatureByLastTripDto buildDto(EngineOilTemperatureByLastTrip entity) {
        final EngineOilTemperatureByLastTripDto dto = new EngineOilTemperatureByLastTripDto();
        dto.setId(entity.getId());
        dto.setOilTemperatureFahrenheit(entity.getOilTemperatureFahrenheit());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineOilTemperatureByLastTrip.class.getCanonicalName();
    }
}
