package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.NoOfRapidAccelerationByDate;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.NoOfRapidAccelerationByDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class NoOfRapidAccelerationByDateMapper implements EntityMapper<NoOfRapidAccelerationByDate, NoOfRapidAccelerationByDateDto> {

    @Override
    public NoOfRapidAccelerationByDate buildEntity(NoOfRapidAccelerationByDateDto dto) {
        final NoOfRapidAccelerationByDate entity = new NoOfRapidAccelerationByDate();
        entity.setId(dto.getId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setNoOfRapidAcceleration(dto.getNoOfRapidAcceleration());
        entity.setHours(dto.getHours());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return NoOfRapidAccelerationByDateDto.class.getCanonicalName();
    }

    @Override
    public NoOfRapidAccelerationByDateDto buildDto(NoOfRapidAccelerationByDate entity) {
        final NoOfRapidAccelerationByDateDto dto = new NoOfRapidAccelerationByDateDto();
        dto.setId(entity.getId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setNoOfRapidAcceleration(entity.getNoOfRapidAcceleration());
        dto.setHours(entity.getHours());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return NoOfRapidAccelerationByDate.class.getCanonicalName();
    }
}