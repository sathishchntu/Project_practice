package com.futuresense.autonostix360.dto.vehiclehealthcheck.aggregator;

import com.futuresense.autonostix360.dto.vehiclehealthcheck.*;

import java.io.Serializable;
import java.util.List;

public class DigitalTwinMilesApisAggregatorDto implements Serializable {

    private List<BatteryEnergyConsumptionAtKeyOffByLastMilesDto> batteryEnergyConsumptionAtKeyOffByLastMiles;

    private List<BatteryEnergyConsumptionByLastMilesDto> batteryEnergyConsumptionByLastMiles;

    private List<EngineFuelConsumptionByLastMilesDto> engineFuelConsumptionByLastMiles;

    private List<FuelConsumptionGalPer100MilesByLastMilesDto> fuelConsumptionGalPer100MilesByLastMiles;

    private List<RemainingOilLifeByLastMilesDto> remainingOilLifeByLastMiles;

    private List<TimeBetweenParticularFilterRegenByLastMilesDto> timeBetweenParticularFilterRegenByLastMiles;

    private List<TimeToStartEngineByLastMilesDto> timeToStartEngineByLastMiles;

    private List<UreaDieselConsumptionByLastMilesDto> ureaDieselConsumptionByLastMiles;

    public List<BatteryEnergyConsumptionAtKeyOffByLastMilesDto> getBatteryEnergyConsumptionAtKeyOffByLastMiles() {
        return batteryEnergyConsumptionAtKeyOffByLastMiles;
    }

    public void setBatteryEnergyConsumptionAtKeyOffByLastMiles(List<BatteryEnergyConsumptionAtKeyOffByLastMilesDto> batteryEnergyConsumptionAtKeyOffByLastMiles) {
        this.batteryEnergyConsumptionAtKeyOffByLastMiles = batteryEnergyConsumptionAtKeyOffByLastMiles;
    }

    public List<BatteryEnergyConsumptionByLastMilesDto> getBatteryEnergyConsumptionByLastMiles() {
        return batteryEnergyConsumptionByLastMiles;
    }

    public void setBatteryEnergyConsumptionByLastMiles(List<BatteryEnergyConsumptionByLastMilesDto> batteryEnergyConsumptionByLastMiles) {
        this.batteryEnergyConsumptionByLastMiles = batteryEnergyConsumptionByLastMiles;
    }

    public List<EngineFuelConsumptionByLastMilesDto> getEngineFuelConsumptionByLastMiles() {
        return engineFuelConsumptionByLastMiles;
    }

    public void setEngineFuelConsumptionByLastMiles(List<EngineFuelConsumptionByLastMilesDto> engineFuelConsumptionByLastMiles) {
        this.engineFuelConsumptionByLastMiles = engineFuelConsumptionByLastMiles;
    }

    public List<FuelConsumptionGalPer100MilesByLastMilesDto> getFuelConsumptionGalPer100MilesByLastMiles() {
        return fuelConsumptionGalPer100MilesByLastMiles;
    }

    public void setFuelConsumptionGalPer100MilesByLastMiles(List<FuelConsumptionGalPer100MilesByLastMilesDto> fuelConsumptionGalPer100MilesByLastMiles) {
        this.fuelConsumptionGalPer100MilesByLastMiles = fuelConsumptionGalPer100MilesByLastMiles;
    }

    public List<RemainingOilLifeByLastMilesDto> getRemainingOilLifeByLastMiles() {
        return remainingOilLifeByLastMiles;
    }

    public void setRemainingOilLifeByLastMiles(List<RemainingOilLifeByLastMilesDto> remainingOilLifeByLastMiles) {
        this.remainingOilLifeByLastMiles = remainingOilLifeByLastMiles;
    }

    public List<TimeBetweenParticularFilterRegenByLastMilesDto> getTimeBetweenParticularFilterRegenByLastMiles() {
        return timeBetweenParticularFilterRegenByLastMiles;
    }

    public void setTimeBetweenParticularFilterRegenByLastMiles(List<TimeBetweenParticularFilterRegenByLastMilesDto> timeBetweenParticularFilterRegenByLastMiles) {
        this.timeBetweenParticularFilterRegenByLastMiles = timeBetweenParticularFilterRegenByLastMiles;
    }

    public List<TimeToStartEngineByLastMilesDto> getTimeToStartEngineByLastMiles() {
        return timeToStartEngineByLastMiles;
    }

    public void setTimeToStartEngineByLastMiles(List<TimeToStartEngineByLastMilesDto> timeToStartEngineByLastMiles) {
        this.timeToStartEngineByLastMiles = timeToStartEngineByLastMiles;
    }

    public List<UreaDieselConsumptionByLastMilesDto> getUreaDieselConsumptionByLastMiles() {
        return ureaDieselConsumptionByLastMiles;
    }

    public void setUreaDieselConsumptionByLastMiles(List<UreaDieselConsumptionByLastMilesDto> ureaDieselConsumptionByLastMiles) {
        this.ureaDieselConsumptionByLastMiles = ureaDieselConsumptionByLastMiles;
    }
}
