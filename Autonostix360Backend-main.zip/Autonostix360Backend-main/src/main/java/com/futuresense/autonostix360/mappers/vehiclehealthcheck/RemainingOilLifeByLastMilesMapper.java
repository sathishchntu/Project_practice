package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.RemainingOilLifeByLastMiles;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.RemainingOilLifeByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class RemainingOilLifeByLastMilesMapper implements EntityMapper<RemainingOilLifeByLastMiles, RemainingOilLifeByLastMilesDto> {

    @Override
    public RemainingOilLifeByLastMiles buildEntity(RemainingOilLifeByLastMilesDto dto) {
        final RemainingOilLifeByLastMiles entity = new RemainingOilLifeByLastMiles();
        entity.setId(dto.getId());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setMilesSinceLastOilChange(dto.getMilesSinceLastOilChange());
        entity.setInitial(dto.getInitial());
        entity.setFourtyKMiles(dto.getFourtyKMiles());
        entity.setEightyKMiles(dto.getEightyKMiles());
        entity.setOneTwentyKMiles(dto.getOneTwentyKMiles());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return RemainingOilLifeByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public RemainingOilLifeByLastMilesDto buildDto(RemainingOilLifeByLastMiles entity) {
        final RemainingOilLifeByLastMilesDto dto = new RemainingOilLifeByLastMilesDto();
        dto.setId(entity.getId());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setMilesSinceLastOilChange(entity.getMilesSinceLastOilChange());
        dto.setInitial(entity.getInitial());
        dto.setFourtyKMiles(entity.getFourtyKMiles());
        dto.setEightyKMiles(entity.getEightyKMiles());
        dto.setOneTwentyKMiles(entity.getOneTwentyKMiles());
        return dto;
    }

    @Override
    public String entityClassName() {
        return RemainingOilLifeByLastMiles.class.getCanonicalName();
    }
}
