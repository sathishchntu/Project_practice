package com.futuresense.autonostix360.dto.vehiclehealthcheck.aggregator;

import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoeoDto;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoeoPostTestResultsDto;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoeoPreTestResultsDto;

import java.io.Serializable;
import java.util.List;

/**
 * Dto class for aggregated api for Digital Twin KOEO apis
 */
public class SelfTestKOEOApisAggregatorDto implements Serializable {

    private List<KoeoDto> koeos;

    private List<KoeoPostTestResultsDto> koeoPostTestResults;

    private List<KoeoPreTestResultsDto> koeoPreTestResults;

    public List<KoeoDto> getKoeos() {
        return koeos;
    }

    public void setKoeos(List<KoeoDto> koeos) {
        this.koeos = koeos;
    }

    public List<KoeoPostTestResultsDto> getKoeoPostTestResults() {
        return koeoPostTestResults;
    }

    public void setKoeoPostTestResults(List<KoeoPostTestResultsDto> koeoPostTestResults) {
        this.koeoPostTestResults = koeoPostTestResults;
    }

    public List<KoeoPreTestResultsDto> getKoeoPreTestResults() {
        return koeoPreTestResults;
    }

    public void setKoeoPreTestResults(List<KoeoPreTestResultsDto> koeoPreTestResults) {
        this.koeoPreTestResults = koeoPreTestResults;
    }
}
