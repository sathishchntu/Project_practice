package com.futuresense.autonostix360.dto.vehiclehealthcheck;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Dto class represents response entity for  {@link com.futuresense.autonostix360.domain.vehiclehealthcheck.DTCAllModules}.
 */
public class DTCAllModulesDto {

    private UUID id;

    private String vinNumber;

    private Integer organizationId;

    private String statsDate;

    private Integer odometer;

    private String dtcCode;

    private String description;

    private String dtcStatus;

    private String category;

    private Timestamp lastUpdated;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDtcStatus() {
        return dtcStatus;
    }

    public void setDtcStatus(String dtcStatus) {
        this.dtcStatus = dtcStatus;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
