package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TransmissionGearByLastMiles;
import com.futuresense.autonostix360.dto.usageprofile.TransmissionGearByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TransmissionGearByLastMilesMapper implements EntityMapper<TransmissionGearByLastMiles, TransmissionGearByLastMilesDto> {
    @Override
    public TransmissionGearByLastMiles buildEntity(TransmissionGearByLastMilesDto dto) {
        final TransmissionGearByLastMiles entity = new TransmissionGearByLastMiles();
        entity.setId(dto.getId());
        entity.setTransmissionGear(dto.getTransmissionGear());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TransmissionGearByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public TransmissionGearByLastMilesDto buildDto(TransmissionGearByLastMiles entity) {
        final TransmissionGearByLastMilesDto dto = new TransmissionGearByLastMilesDto();
        dto.setId(entity.getId());
        dto.setTransmissionGear(entity.getTransmissionGear());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TransmissionGearByLastMiles.class.getCanonicalName();
    }
}
