package com.futuresense.autonostix360.repository.ftanalytics;

import com.futuresense.autonostix360.domain.ftanalytics.FaultTrendAnalyticsMiles;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

/**
 * FaultTrendAnalyticsMilesRepository
 */
public interface FaultTrendAnalyticsMilesRepository extends CassandraRepository<FaultTrendAnalyticsMiles, String> {

    @Query(value = "select * from fault_trend_analytics_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_miles >= :fromRulMiles and rul_miles <= :toRulMiles")
    Slice<FaultTrendAnalyticsMiles> findByVinNumberAndOrganizationIdAndRulMilesRange(String vinNumber, Integer organizationId, Double fromRulMiles, Double toRulMiles, Pageable pageable);

    @Query(value = "select count(*) from fault_trend_analytics_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_miles >= :fromRulMiles and rul_miles <= :toRulMiles")
    int pageCount(String vinNumber, Integer organizationId, Double fromRulMiles, Double toRulMiles);


    @Query(value = "select * from fault_trend_analytics_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId and " +
            "rul_miles >= :fromRulMiles and rul_miles <= :toRulMiles")
    Slice<FaultTrendAnalyticsMiles> findAllByVinNumberAndOrganizationIdAndRulMilesRange(CassandraPageRequest pageRequest, String vinNumber, Integer organizationId, Double fromRulMiles, Double toRulMiles);
}