package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineCoolantTemperatureByLastTrip;
import com.futuresense.autonostix360.dto.usageprofile.EngineCoolantTemperatureByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineCoolantTemperatureByLastTripMapper implements EntityMapper<EngineCoolantTemperatureByLastTrip, EngineCoolantTemperatureByLastTripDto> {
    @Override
    public EngineCoolantTemperatureByLastTrip buildEntity(EngineCoolantTemperatureByLastTripDto dto) {
        final EngineCoolantTemperatureByLastTrip entity = new EngineCoolantTemperatureByLastTrip();
        entity.setId(dto.getId());
        entity.setTemperatureInFahrenheit(dto.getTemperatureInFahrenheit());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineCoolantTemperatureByLastTripDto.class.getCanonicalName();
    }

    @Override
    public EngineCoolantTemperatureByLastTripDto buildDto(EngineCoolantTemperatureByLastTrip entity) {
        final EngineCoolantTemperatureByLastTripDto dto = new EngineCoolantTemperatureByLastTripDto();
        dto.setId(entity.getId());
        dto.setTemperatureInFahrenheit(entity.getTemperatureInFahrenheit());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineCoolantTemperatureByLastTrip.class.getCanonicalName();
    }
}
