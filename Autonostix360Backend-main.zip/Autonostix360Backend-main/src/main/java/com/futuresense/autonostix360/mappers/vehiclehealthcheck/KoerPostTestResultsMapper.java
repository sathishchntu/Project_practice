package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.KoerPostTestResults;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.KoerPostTestResultsDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class that converts dto to entity and vice versa
 */
@Service
public class KoerPostTestResultsMapper implements EntityMapper<KoerPostTestResults, KoerPostTestResultsDto> {
    @Override
    public KoerPostTestResults buildEntity(KoerPostTestResultsDto dto) {
        final KoerPostTestResults entity = new KoerPostTestResults();
        entity.setId(dto.getId());
        entity.setDtcCode(dto.getDtcCode());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return KoerPostTestResultsDto.class.getCanonicalName();
    }

    @Override
    public KoerPostTestResultsDto buildDto(KoerPostTestResults entity) {
        final KoerPostTestResultsDto dto = new KoerPostTestResultsDto();
        dto.setId(entity.getId());
        dto.setDtcCode(entity.getDtcCode());
        dto.setStatsDate(entity.getStatsDate());
        return dto;
    }

    @Override
    public String entityClassName() {
        return KoerPostTestResults.class.getCanonicalName();
    }
}
