package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.BreakPressureByLastTrip;
import com.futuresense.autonostix360.dto.usageprofile.BreakPressureByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class BreakPressureByLastTripMapper implements EntityMapper<BreakPressureByLastTrip, BreakPressureByLastTripDto> {
    @Override
    public BreakPressureByLastTrip buildEntity(BreakPressureByLastTripDto dto) {
        final BreakPressureByLastTrip entity = new BreakPressureByLastTrip();
        entity.setId(dto.getId());
        entity.setBreakPressurePsi(dto.getBreakPressurePsi());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return BreakPressureByLastTripDto.class.getCanonicalName();
    }

    @Override
    public BreakPressureByLastTripDto buildDto(BreakPressureByLastTrip entity) {
        final BreakPressureByLastTripDto dto = new BreakPressureByLastTripDto();
        dto.setId(entity.getId());
        dto.setBreakPressurePsi(entity.getBreakPressurePsi());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return BreakPressureByLastTrip.class.getCanonicalName();
    }
}
