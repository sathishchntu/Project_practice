package com.futuresense.autonostix360.domain.vehiclehealthcheck;

import com.datastax.oss.driver.api.mapper.annotations.ClusteringColumn;
import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entity RightRearValveOutLet represents table right_rear_valve_outlet
 */
@Table(value = "right_rear_valve_outlet")
public class RightRearValveOutLet {

    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("stats_date")
    private String statsDate;

    @ClusteringColumn
    @Column("odometer")
    private Integer odometer;

    @Column("last_updated")
    private Timestamp lastUpdated;

    @Column("module")
    private String module;

    @Column("time")
    private Double time;

    @Column("valve_actuation_duty_cycle_pwm")
    private Integer valveActuationDutyCyclePWM;

    @Column("break_fluid_pressure_20k")
    private Double breakFluidPressure20k;

    @Column("break_fluid_pressure_50k")
    private Double breakFluidPressure50k;

    @Column("break_fluid_pressure_100k")
    private Double breakFluidPressure100k;

    @Column("break_fluid_pressure_120k")
    private Double breakFluidPressure120k;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public Double getTime() {
        return time;
    }

    public void setTime(Double time) {
        this.time = time;
    }

    public Integer getValveActuationDutyCyclePWM() {
        return valveActuationDutyCyclePWM;
    }

    public void setValveActuationDutyCyclePWM(Integer valveActuationDutyCyclePWM) {
        this.valveActuationDutyCyclePWM = valveActuationDutyCyclePWM;
    }

    public Double getBreakFluidPressure20k() {
        return breakFluidPressure20k;
    }

    public void setBreakFluidPressure20k(Double breakFluidPressure20k) {
        this.breakFluidPressure20k = breakFluidPressure20k;
    }

    public Double getBreakFluidPressure50k() {
        return breakFluidPressure50k;
    }

    public void setBreakFluidPressure50k(Double breakFluidPressure50k) {
        this.breakFluidPressure50k = breakFluidPressure50k;
    }

    public Double getBreakFluidPressure100k() {
        return breakFluidPressure100k;
    }

    public void setBreakFluidPressure100k(Double breakFluidPressure100k) {
        this.breakFluidPressure100k = breakFluidPressure100k;
    }

    public Double getBreakFluidPressure120k() {
        return breakFluidPressure120k;
    }

    public void setBreakFluidPressure120k(Double breakFluidPressure120k) {
        this.breakFluidPressure120k = breakFluidPressure120k;
    }
}