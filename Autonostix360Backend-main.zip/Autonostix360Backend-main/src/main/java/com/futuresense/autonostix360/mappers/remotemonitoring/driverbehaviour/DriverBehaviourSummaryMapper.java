package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.DriverBehaviourSummary;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.DriverBehaviourSummaryDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Entity <-> Dto mapping
 */
@Service
public class DriverBehaviourSummaryMapper implements EntityMapper<DriverBehaviourSummary, DriverBehaviourSummaryDto> {
    @Override
    public DriverBehaviourSummary buildEntity(DriverBehaviourSummaryDto dto) {

        final DriverBehaviourSummary entity = new DriverBehaviourSummary();

        entity.setAvgDistancePerDayMiles(dto.getAvgDistancePerDayMiles());
        entity.setAvgEngineRuntimeIdleHours(dto.getAvgEngineRuntimeIdleHours());
        entity.setNoOfOverSpeedingEvent(dto.getNoOfOverSpeedingEvent());
        entity.setNoOfHarshCorneringEvents(dto.getNoOfHarshCorneringEvents());
        entity.setNoOfHarshBreakingEvents(dto.getNoOfHarshBreakingEvents());
        entity.setNoOfRapidAccelerationPerMile(dto.getNoOfRapidAccelerationPerMile());
        entity.setMileDrivenInRedZoneOfLaneTracking(dto.getMileDrivenInRedZoneOfLaneTracking());
        entity.setMileDrivenInGreenZoneOfLaneTracking(dto.getMileDrivenInGreenZoneOfLaneTracking());
        entity.setMileDrivenInYellowZoneOfLaneTracking(dto.getMileDrivenInYellowZoneOfLaneTracking());
        entity.setTendencyAvoidingHarshWeatherDriving(dto.getTendencyAvoidingHarshWeatherDriving());
        entity.setPercentageOfUnpavedDriving(dto.getPercentageOfUnpavedDriving());
        entity.setCriticalTrafficSignalViolationLimit(dto.getCriticalTrafficSignalViolationLimit());
        entity.setCriticalStopSignalViolationLimit(dto.getCriticalStopSignalViolationLimit());
        entity.setOverallScorePercentage(dto.getOverallScorePercentage());

        return entity;
    }

    @Override
    public String dtoClassName() {
        return DriverBehaviourSummaryDto.class.getCanonicalName();
    }

    @Override
    public DriverBehaviourSummaryDto buildDto(DriverBehaviourSummary entity) {

        final DriverBehaviourSummaryDto dto = new DriverBehaviourSummaryDto();

        dto.setAvgDistancePerDayMiles(entity.getAvgDistancePerDayMiles());
        dto.setAvgEngineRuntimeIdleHours(entity.getAvgEngineRuntimeIdleHours());
        dto.setNoOfOverSpeedingEvent(entity.getNoOfOverSpeedingEvent());
        dto.setNoOfHarshCorneringEvents(entity.getNoOfHarshCorneringEvents());
        dto.setNoOfHarshBreakingEvents(entity.getNoOfHarshBreakingEvents());
        dto.setNoOfRapidAccelerationPerMile(entity.getNoOfRapidAccelerationPerMile());
        dto.setMileDrivenInRedZoneOfLaneTracking(entity.getMileDrivenInRedZoneOfLaneTracking());
        dto.setMileDrivenInGreenZoneOfLaneTracking(entity.getMileDrivenInGreenZoneOfLaneTracking());
        dto.setMileDrivenInYellowZoneOfLaneTracking(entity.getMileDrivenInYellowZoneOfLaneTracking());
        dto.setTendencyAvoidingHarshWeatherDriving(entity.getTendencyAvoidingHarshWeatherDriving());
        dto.setPercentageOfUnpavedDriving(entity.getPercentageOfUnpavedDriving());
        dto.setCriticalTrafficSignalViolationLimit(entity.getCriticalTrafficSignalViolationLimit());
        dto.setCriticalStopSignalViolationLimit(entity.getCriticalStopSignalViolationLimit());
        dto.setOverallScorePercentage(entity.getOverallScorePercentage());

        return dto;
    }

    @Override
    public String entityClassName() {
        return DriverBehaviourSummary.class.getCanonicalName();
    }
}
