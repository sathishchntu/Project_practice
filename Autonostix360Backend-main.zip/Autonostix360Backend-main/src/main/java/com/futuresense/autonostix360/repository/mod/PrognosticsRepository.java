package com.futuresense.autonostix360.repository.mod;

import com.futuresense.autonostix360.domain.mod.Prognostics;
import org.springframework.data.cassandra.core.query.CassandraPageRequest;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.UUID;

/**
 * PrognosticsRepository
 */

public interface PrognosticsRepository extends CassandraRepository<Prognostics, UUID> {

    @Query(value = "select * from prognostics where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    Slice<Prognostics> findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, String statsDate, Pageable pageable);

    @Query(value = "select count(*) from prognostics where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    int pageCount(String vinNumber, Integer organizationId, String statsDate);

    @Query(value = "select * from prognostics where " +
            "vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and stats_date = :statsDate")
    Slice<Prognostics> findByVinNumberAndOrganizationIdAndStatsDate(CassandraPageRequest pageRequest, String vinNumber, Integer organizationId, String statsDate);
}