package com.futuresense.autonostix360.dto.maintenancelogs;

import java.io.Serializable;
import java.util.Set;

/**
 * Dto class to create custom filter
 */
public class FilterDto implements Serializable {

    Set<String> subSystems;

    Set<String> dtcCodes;

    public Set<String> getSubSystems() {
        return subSystems;
    }

    public void setSubSystems(Set<String> subSystems) {
        this.subSystems = subSystems;
    }

    public Set<String> getDtcCodes() {
        return dtcCodes;
    }

    public void setDtcCodes(Set<String> dtcCodes) {
        this.dtcCodes = dtcCodes;
    }
}
