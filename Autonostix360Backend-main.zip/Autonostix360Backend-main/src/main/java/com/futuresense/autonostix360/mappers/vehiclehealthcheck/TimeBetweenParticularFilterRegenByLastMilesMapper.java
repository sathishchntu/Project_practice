package com.futuresense.autonostix360.mappers.vehiclehealthcheck;


import com.futuresense.autonostix360.domain.vehiclehealthcheck.TimeBetweenParticularFilterRegenByLastMiles;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.TimeBetweenParticularFilterRegenByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TimeBetweenParticularFilterRegenByLastMilesMapper implements EntityMapper<TimeBetweenParticularFilterRegenByLastMiles, TimeBetweenParticularFilterRegenByLastMilesDto> {
    @Override
    public TimeBetweenParticularFilterRegenByLastMiles buildEntity(TimeBetweenParticularFilterRegenByLastMilesDto dto) {
        final TimeBetweenParticularFilterRegenByLastMiles entity = new TimeBetweenParticularFilterRegenByLastMiles();
        entity.setId(dto.getId());
        entity.setTimeBetweenParticularFilterRegenMin(dto.getTimeBetweenParticularFilterRegenMin());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TimeBetweenParticularFilterRegenByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public TimeBetweenParticularFilterRegenByLastMilesDto buildDto(TimeBetweenParticularFilterRegenByLastMiles entity) {
        final TimeBetweenParticularFilterRegenByLastMilesDto dto = new TimeBetweenParticularFilterRegenByLastMilesDto();
        dto.setId(entity.getId());
        dto.setTimeBetweenParticularFilterRegenMin(entity.getTimeBetweenParticularFilterRegenMin());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TimeBetweenParticularFilterRegenByLastMiles.class.getCanonicalName();
    }
}
