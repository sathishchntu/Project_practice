package com.futuresense.autonostix360.domain.vehiclehealthcheck;

import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entity DTCDetails represents dtc_details
 */
@Table(value = "dtc_details")
public class DTCDetails {

    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("stats_date")
    private String statsDate;

    @Column("dtc_code")
    private String dtcCode;

    @Column("casual_probability")
    private String causalProbability;

    @Column("associated_dtcs")
    private String associatedDtcs;

    @Column("description")
    private String description;

    @Column("historical_root_cause")
    private String historicalRootCause;

    @Column("potential_solution")
    private String potentialSolution;

    @Column("odometer")
    private Integer odometer;

    @Column("last_updated")
    private Timestamp lastUpdated;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getDtcCode() {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode) {
        this.dtcCode = dtcCode;
    }

    public String getCausalProbability() {
        return causalProbability;
    }

    public void setCausalProbability(String causalProbability) {
        this.causalProbability = causalProbability;
    }

    public String getAssociatedDtcs() {
        return associatedDtcs;
    }

    public void setAssociatedDtcs(String associatedDtcs) {
        this.associatedDtcs = associatedDtcs;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getHistoricalRootCause() {
        return historicalRootCause;
    }

    public void setHistoricalRootCause(String historicalRootCause) {
        this.historicalRootCause = historicalRootCause;
    }

    public String getPotentialSolution() {
        return potentialSolution;
    }

    public void setPotentialSolution(String potentialSolution) {
        this.potentialSolution = potentialSolution;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
