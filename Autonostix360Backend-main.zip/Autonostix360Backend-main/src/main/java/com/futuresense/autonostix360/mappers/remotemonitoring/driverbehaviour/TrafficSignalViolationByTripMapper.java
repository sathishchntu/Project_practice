package com.futuresense.autonostix360.mappers.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.TrafficSignalViolationByTrip;
import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.TrafficSignalViolationByTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TrafficSignalViolationByTripMapper implements EntityMapper<TrafficSignalViolationByTrip, TrafficSignalViolationByTripDto> {

    @Override
    public TrafficSignalViolationByTrip buildEntity(TrafficSignalViolationByTripDto dto) {
        TrafficSignalViolationByTrip entity = new TrafficSignalViolationByTrip();
        entity.setId(dto.getId());
        entity.setStatsDate(dto.getStatsDate());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setNoOfSignalViolation(dto.getNoOfSignalViolation());
        entity.setHours(dto.getHours());
        entity.setEngineRunTime(dto.getEngineRunTime());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TrafficSignalViolationByTripDto.class.getCanonicalName();
    }

    @Override
    public TrafficSignalViolationByTripDto buildDto(TrafficSignalViolationByTrip entity) {
        TrafficSignalViolationByTripDto dto = new TrafficSignalViolationByTripDto();
        dto.setId(entity.getId());
        dto.setStatsDate(entity.getStatsDate());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setNoOfSignalViolation(entity.getNoOfSignalViolation());
        dto.setHours(entity.getHours());
        dto.setEngineRunTime(entity.getEngineRunTime());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TrafficSignalViolationByTrip.class.getCanonicalName();
    }
}
