package com.futuresense.autonostix360.dto.usageprofile.aggregator;

import com.futuresense.autonostix360.dto.usageprofile.*;

import java.io.Serializable;
import java.util.List;

public class UsageProfileTripApisAggregatorDto implements Serializable {

    private List<BreakPressureByLastTripDto> breakPressureByLastTripDto;

    private List<EngineCoolantTemperatureByLastTripDto> engineCoolantTemperatureByLastTripDto;

    private List<EngineOilLevelByLastTripDto> engineOilLevelByLastTripDto;

    private List<EngineOilTemperatureByLastTripDto> engineOilTemperatureByLastTripDto;

    private List<EngineSpeedByLastTripDto> engineSpeedByLastTripDto;

    private List<EngineTorqueByLastTripDto> engineTorqueByLastTripDto;

    private List<RemainingEngineLifeByLastTripDto> remainingEngineLifeByLastTripDto;

    private List<TirePressureByLastTripDto> tirePressureByLastTripDto;

    private List<TransmissionGearByLastTripDto> transmissionGearByLastTripDto;

    private List<TransmissionOilTemperatureByLastTripDto> transmissionOilTemperatureByLastTripDto;

    public List<BreakPressureByLastTripDto> getBreakPressureByLastTripDto() {
        return breakPressureByLastTripDto;
    }

    public void setBreakPressureByLastTripDto(List<BreakPressureByLastTripDto> breakPressureByLastTripDto) {
        this.breakPressureByLastTripDto = breakPressureByLastTripDto;
    }

    public List<EngineCoolantTemperatureByLastTripDto> getEngineCoolantTemperatureByLastTripDto() {
        return engineCoolantTemperatureByLastTripDto;
    }

    public void setEngineCoolantTemperatureByLastTripDto(List<EngineCoolantTemperatureByLastTripDto> engineCoolantTemperatureByLastTripDto) {
        this.engineCoolantTemperatureByLastTripDto = engineCoolantTemperatureByLastTripDto;
    }

    public List<EngineOilLevelByLastTripDto> getEngineOilLevelByLastTripDto() {
        return engineOilLevelByLastTripDto;
    }

    public void setEngineOilLevelByLastTripDto(List<EngineOilLevelByLastTripDto> engineOilLevelByLastTripDto) {
        this.engineOilLevelByLastTripDto = engineOilLevelByLastTripDto;
    }

    public List<EngineOilTemperatureByLastTripDto> getEngineOilTemperatureByLastTripDto() {
        return engineOilTemperatureByLastTripDto;
    }

    public void setEngineOilTemperatureByLastTripDto(List<EngineOilTemperatureByLastTripDto> engineOilTemperatureByLastTripDto) {
        this.engineOilTemperatureByLastTripDto = engineOilTemperatureByLastTripDto;
    }

    public List<EngineSpeedByLastTripDto> getEngineSpeedByLastTripDto() {
        return engineSpeedByLastTripDto;
    }

    public void setEngineSpeedByLastTripDto(List<EngineSpeedByLastTripDto> engineSpeedByLastTripDto) {
        this.engineSpeedByLastTripDto = engineSpeedByLastTripDto;
    }

    public List<EngineTorqueByLastTripDto> getEngineTorqueByLastTripDto() {
        return engineTorqueByLastTripDto;
    }

    public void setEngineTorqueByLastTripDto(List<EngineTorqueByLastTripDto> engineTorqueByLastTripDto) {
        this.engineTorqueByLastTripDto = engineTorqueByLastTripDto;
    }

    public List<RemainingEngineLifeByLastTripDto> getRemainingEngineLifeByLastTripDto() {
        return remainingEngineLifeByLastTripDto;
    }

    public void setRemainingEngineLifeByLastTripDto(List<RemainingEngineLifeByLastTripDto> remainingEngineLifeByLastTripDto) {
        this.remainingEngineLifeByLastTripDto = remainingEngineLifeByLastTripDto;
    }

    public List<TirePressureByLastTripDto> getTirePressureByLastTripDto() {
        return tirePressureByLastTripDto;
    }

    public void setTirePressureByLastTripDto(List<TirePressureByLastTripDto> tirePressureByLastTripDto) {
        this.tirePressureByLastTripDto = tirePressureByLastTripDto;
    }

    public List<TransmissionGearByLastTripDto> getTransmissionGearByLastTripDto() {
        return transmissionGearByLastTripDto;
    }

    public void setTransmissionGearByLastTripDto(List<TransmissionGearByLastTripDto> transmissionGearByLastTripDto) {
        this.transmissionGearByLastTripDto = transmissionGearByLastTripDto;
    }

    public List<TransmissionOilTemperatureByLastTripDto> getTransmissionOilTemperatureByLastTripDto() {
        return transmissionOilTemperatureByLastTripDto;
    }

    public void setTransmissionOilTemperatureByLastTripDto(List<TransmissionOilTemperatureByLastTripDto> transmissionOilTemperatureByLastTripDto) {
        this.transmissionOilTemperatureByLastTripDto = transmissionOilTemperatureByLastTripDto;
    }
}
