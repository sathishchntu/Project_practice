package com.futuresense.autonostix360.domain.maintenancelogs.score;

import com.datastax.oss.driver.api.mapper.annotations.ClusteringColumn;
import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entity QualityDto represents table location
 */
@Table(value = "quality")
public class Quality {

    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("stats_date")
    private String statsDate;

    @Column("component_replaced")
    private String componentReplaced;

    @Column("vehicle_compatible_components")
    private String vehicleCompatibleComponents;

    @Column("actual_replaced_components")
    private String actualReplacedComponents;

    @Column("weighing_factor")
    private Double weighingFactor;

    @Column("violation")
    private String violation;

    @ClusteringColumn
    @Column("last_updated")
    private Timestamp lastUpdated;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public String getComponentReplaced() {
        return componentReplaced;
    }

    public void setComponentReplaced(String componentReplaced) {
        this.componentReplaced = componentReplaced;
    }

    public Double getWeighingFactor() {
        return weighingFactor;
    }

    public void setWeighingFactor(Double weighingFactor) {
        this.weighingFactor = weighingFactor;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getVehicleCompatibleComponents() {
        return vehicleCompatibleComponents;
    }

    public void setVehicleCompatibleComponents(String vehicleCompatibleComponents) {
        this.vehicleCompatibleComponents = vehicleCompatibleComponents;
    }

    public String getActualReplacedComponents() {
        return actualReplacedComponents;
    }

    public void setActualReplacedComponents(String actualReplacedComponents) {
        this.actualReplacedComponents = actualReplacedComponents;
    }

    public String getViolation() {
        return violation;
    }

    public void setViolation(String violation) {
        this.violation = violation;
    }
}
