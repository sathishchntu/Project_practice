package com.futuresense.autonostix360.dto.vehiclehealthcheck.aggregator;

import com.futuresense.autonostix360.dto.vehiclehealthcheck.*;

import java.io.Serializable;
import java.util.List;

/**
 * Dto class for aggregated api for Digital Twin Trip apis
 */
public class DigitalTwinTripApisAggregatorDto implements Serializable {

    private List<UreaDieselConsumptionByLastTripDto> ureaDieselConsumptionByLastTrips;

    private List<TimeBetweenParticularFilterRegenByLastTripDto> timeBetweenParticularFilterRegenByLastTrips;

    private List<BatteryEnergyConsumptionAtKeyOffByLastTripDto> batteryEnergyConsumptionAtKeyOffByLastTrips;

    private List<BatteryEnergyConsumptionByLastTripDto> batteryEnergyConsumptionByLastTrips;

    private List<EngineFuelConsumptionByLastTripDto> engineFuelConsumptionByLastTrips;

    private List<FuelConsumptionGalPer100MilesByLastTripDto> fuelConsumptionGalPer100MilesByLastTrips;

    private List<RemainingOilLifeByLastTripDto> remainingOilLifeByLastTrips;

    private List<TimeToStartEngineByLastTripDto> timeToStartEngineByLastTrips;

    public List<UreaDieselConsumptionByLastTripDto> getUreaDieselConsumptionByLastTrips() {
        return ureaDieselConsumptionByLastTrips;
    }

    public void setUreaDieselConsumptionByLastTrips(List<UreaDieselConsumptionByLastTripDto> ureaDieselConsumptionByLastTrips) {
        this.ureaDieselConsumptionByLastTrips = ureaDieselConsumptionByLastTrips;
    }

    public List<TimeBetweenParticularFilterRegenByLastTripDto> getTimeBetweenParticularFilterRegenByLastTrips() {
        return timeBetweenParticularFilterRegenByLastTrips;
    }

    public void setTimeBetweenParticularFilterRegenByLastTrips(List<TimeBetweenParticularFilterRegenByLastTripDto> timeBetweenParticularFilterRegenByLastTrips) {
        this.timeBetweenParticularFilterRegenByLastTrips = timeBetweenParticularFilterRegenByLastTrips;
    }

    public List<BatteryEnergyConsumptionAtKeyOffByLastTripDto> getBatteryEnergyConsumptionAtKeyOffByLastTrips() {
        return batteryEnergyConsumptionAtKeyOffByLastTrips;
    }

    public void setBatteryEnergyConsumptionAtKeyOffByLastTrips(List<BatteryEnergyConsumptionAtKeyOffByLastTripDto> batteryEnergyConsumptionAtKeyOffByLastTrips) {
        this.batteryEnergyConsumptionAtKeyOffByLastTrips = batteryEnergyConsumptionAtKeyOffByLastTrips;
    }

    public List<BatteryEnergyConsumptionByLastTripDto> getBatteryEnergyConsumptionByLastTrips() {
        return batteryEnergyConsumptionByLastTrips;
    }

    public void setBatteryEnergyConsumptionByLastTrips(List<BatteryEnergyConsumptionByLastTripDto> batteryEnergyConsumptionByLastTrips) {
        this.batteryEnergyConsumptionByLastTrips = batteryEnergyConsumptionByLastTrips;
    }

    public List<EngineFuelConsumptionByLastTripDto> getEngineFuelConsumptionByLastTrips() {
        return engineFuelConsumptionByLastTrips;
    }

    public void setEngineFuelConsumptionByLastTrips(List<EngineFuelConsumptionByLastTripDto> engineFuelConsumptionByLastTrips) {
        this.engineFuelConsumptionByLastTrips = engineFuelConsumptionByLastTrips;
    }

    public List<FuelConsumptionGalPer100MilesByLastTripDto> getFuelConsumptionGalPer100MilesByLastTrips() {
        return fuelConsumptionGalPer100MilesByLastTrips;
    }

    public void setFuelConsumptionGalPer100MilesByLastTrips(List<FuelConsumptionGalPer100MilesByLastTripDto> fuelConsumptionGalPer100MilesByLastTrips) {
        this.fuelConsumptionGalPer100MilesByLastTrips = fuelConsumptionGalPer100MilesByLastTrips;
    }

    public List<RemainingOilLifeByLastTripDto> getRemainingOilLifeByLastTrips() {
        return remainingOilLifeByLastTrips;
    }

    public void setRemainingOilLifeByLastTrips(List<RemainingOilLifeByLastTripDto> remainingOilLifeByLastTrips) {
        this.remainingOilLifeByLastTrips = remainingOilLifeByLastTrips;
    }

    public List<TimeToStartEngineByLastTripDto> getTimeToStartEngineByLastTrips() {
        return timeToStartEngineByLastTrips;
    }

    public void setTimeToStartEngineByLastTrips(List<TimeToStartEngineByLastTripDto> timeToStartEngineByLastTrips) {
        this.timeToStartEngineByLastTrips = timeToStartEngineByLastTrips;
    }
}
