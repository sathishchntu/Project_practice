package com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour;

import java.io.Serializable;

/**
 * Custom response object to have complete values
 * eg:
 * Average distance Travel per day - 80 Miles
 * Average time Engine was Running while idle - 1.4 Hours
 */
public class DriverBehaviourSummaryResponseDto implements Serializable {

    private String avgDistancePerDayMiles;

    private String avgEngineRuntimeIdleHours;

    private String noOfOverSpeedingEvent;

    private String milesDrivenOverSpeeding;

    private String noOfHarshBreakingEvents;

    private String noOfHarshCorneringEvents;

    private String noOfRapidAccelerationPerMile;

    private String mileDrivenInGreenZoneOfLaneTracking;

    private String mileDrivenInYellowZoneOfLaneTracking;

    private String mileDrivenInRedZoneOfLaneTracking;

    private String tendencyAvoidingHarshWeatherDriving;

    private String percentageOfUnpavedDriving;

    private String criticalTrafficSignalViolationLimit;

    private String criticalStopSignalViolationLimit;

    private String overallScorePercentage;

    public String getAvgDistancePerDayMiles() {
        return avgDistancePerDayMiles;
    }

    public void setAvgDistancePerDayMiles(String avgDistancePerDayMiles) {
        this.avgDistancePerDayMiles = avgDistancePerDayMiles;
    }

    public String getAvgEngineRuntimeIdleHours() {
        return avgEngineRuntimeIdleHours;
    }

    public void setAvgEngineRuntimeIdleHours(String avgEngineRuntimeIdleHours) {
        this.avgEngineRuntimeIdleHours = avgEngineRuntimeIdleHours;
    }

    public String getNoOfOverSpeedingEvent() {
        return noOfOverSpeedingEvent;
    }

    public void setNoOfOverSpeedingEvent(String noOfOverSpeedingEvent) {
        this.noOfOverSpeedingEvent = noOfOverSpeedingEvent;
    }

    public String getMilesDrivenOverSpeeding() {
        return milesDrivenOverSpeeding;
    }

    public void setMilesDrivenOverSpeeding(String milesDrivenOverSpeeding) {
        this.milesDrivenOverSpeeding = milesDrivenOverSpeeding;
    }

    public String getNoOfHarshBreakingEvents() {
        return noOfHarshBreakingEvents;
    }

    public void setNoOfHarshBreakingEvents(String noOfHarshBreakingEvents) {
        this.noOfHarshBreakingEvents = noOfHarshBreakingEvents;
    }

    public String getNoOfHarshCorneringEvents() {
        return noOfHarshCorneringEvents;
    }

    public void setNoOfHarshCorneringEvents(String noOfHarshCorneringEvents) {
        this.noOfHarshCorneringEvents = noOfHarshCorneringEvents;
    }

    public String getNoOfRapidAccelerationPerMile() {
        return noOfRapidAccelerationPerMile;
    }

    public void setNoOfRapidAccelerationPerMile(String noOfRapidAccelerationPerMile) {
        this.noOfRapidAccelerationPerMile = noOfRapidAccelerationPerMile;
    }

    public String getMileDrivenInGreenZoneOfLaneTracking() {
        return mileDrivenInGreenZoneOfLaneTracking;
    }

    public void setMileDrivenInGreenZoneOfLaneTracking(String mileDrivenInGreenZoneOfLaneTracking) {
        this.mileDrivenInGreenZoneOfLaneTracking = mileDrivenInGreenZoneOfLaneTracking;
    }

    public String getMileDrivenInYellowZoneOfLaneTracking() {
        return mileDrivenInYellowZoneOfLaneTracking;
    }

    public void setMileDrivenInYellowZoneOfLaneTracking(String mileDrivenInYellowZoneOfLaneTracking) {
        this.mileDrivenInYellowZoneOfLaneTracking = mileDrivenInYellowZoneOfLaneTracking;
    }

    public String getMileDrivenInRedZoneOfLaneTracking() {
        return mileDrivenInRedZoneOfLaneTracking;
    }

    public void setMileDrivenInRedZoneOfLaneTracking(String mileDrivenInRedZoneOfLaneTracking) {
        this.mileDrivenInRedZoneOfLaneTracking = mileDrivenInRedZoneOfLaneTracking;
    }

    public String getTendencyAvoidingHarshWeatherDriving() {
        return tendencyAvoidingHarshWeatherDriving;
    }

    public void setTendencyAvoidingHarshWeatherDriving(String tendencyAvoidingHarshWeatherDriving) {
        this.tendencyAvoidingHarshWeatherDriving = tendencyAvoidingHarshWeatherDriving;
    }

    public String getPercentageOfUnpavedDriving() {
        return percentageOfUnpavedDriving;
    }

    public void setPercentageOfUnpavedDriving(String percentageOfUnpavedDriving) {
        this.percentageOfUnpavedDriving = percentageOfUnpavedDriving;
    }

    public String getCriticalTrafficSignalViolationLimit() {
        return criticalTrafficSignalViolationLimit;
    }

    public void setCriticalTrafficSignalViolationLimit(String criticalTrafficSignalViolationLimit) {
        this.criticalTrafficSignalViolationLimit = criticalTrafficSignalViolationLimit;
    }

    public String getCriticalStopSignalViolationLimit() {
        return criticalStopSignalViolationLimit;
    }

    public void setCriticalStopSignalViolationLimit(String criticalStopSignalViolationLimit) {
        this.criticalStopSignalViolationLimit = criticalStopSignalViolationLimit;
    }

    public String getOverallScorePercentage() {
        return overallScorePercentage;
    }

    public void setOverallScorePercentage(String overallScorePercentage) {
        this.overallScorePercentage = overallScorePercentage;
    }
}
