package com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.aggregator;

import com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour.*;

import java.io.Serializable;
import java.util.List;

/**
 * Dto class for aggregated api for Driver Behaviour Date apis
 */
public class DriverBehaviorDateApisAggregatorDto implements Serializable {

    private List<DrivingUnpavedRoadRouteAdherenceByDateDto> drivingUnpavedRoadRouteAdherenceByDates;

    private List<TrafficSignalViolationByDateDto> trafficSignalViolationByDates;

    private List<StopSignViolationByDateDto> stopSignViolationByDates;

    private List<EngineRunTimeDistanceTravelledByDateDto> engineRunTimeDistanceTravelledByDates;

    private List<NoOfHarshBreakingByDateDto> noOfHarshBreakingByDates;

    private List<NoOfHarshCorneringByDateDto> noOfHarshCorneringByDates;

    private List<NoOfOverSpeedingEventsByDateDto> noOfOverSpeedingEventsByDates;

    private List<MilesDrivenOverSpeedingByDateDto> milesDrivenOverSpeedingByDates;

    private List<MilesDrivenInLaneTrackingZoneByDateDto> milesDrivenInLaneTrackingZoneByDates;

    private List<NoOfRapidAccelerationByDateDto> noOfRapidAccelerationByDates;

    private List<NoOfRapidDecelerationByDateDto> noOfRapidDecelerationByDates;

    private List<EngineOnDistanceTravelledExtremeWeatherByDateDto> engineOnDistanceTravelledExtremeWeatherByDates;

    public List<DrivingUnpavedRoadRouteAdherenceByDateDto> getDrivingUnpavedRoadRouteAdherenceByDates() {
        return drivingUnpavedRoadRouteAdherenceByDates;
    }

    public void setDrivingUnpavedRoadRouteAdherenceByDates(List<DrivingUnpavedRoadRouteAdherenceByDateDto> drivingUnpavedRoadRouteAdherenceByDates) {
        this.drivingUnpavedRoadRouteAdherenceByDates = drivingUnpavedRoadRouteAdherenceByDates;
    }

    public List<TrafficSignalViolationByDateDto> getTrafficSignalViolationByDates() {
        return trafficSignalViolationByDates;
    }

    public void setTrafficSignalViolationByDates(List<TrafficSignalViolationByDateDto> trafficSignalViolationByDates) {
        this.trafficSignalViolationByDates = trafficSignalViolationByDates;
    }

    public List<StopSignViolationByDateDto> getStopSignViolationByDates() {
        return stopSignViolationByDates;
    }

    public void setStopSignViolationByDates(List<StopSignViolationByDateDto> stopSignViolationByDates) {
        this.stopSignViolationByDates = stopSignViolationByDates;
    }

    public List<EngineRunTimeDistanceTravelledByDateDto> getEngineRunTimeDistanceTravelledByDates() {
        return engineRunTimeDistanceTravelledByDates;
    }

    public void setEngineRunTimeDistanceTravelledByDates(List<EngineRunTimeDistanceTravelledByDateDto> engineRunTimeDistanceTravelledByDates) {
        this.engineRunTimeDistanceTravelledByDates = engineRunTimeDistanceTravelledByDates;
    }

    public List<NoOfHarshBreakingByDateDto> getNoOfHarshBreakingByDates() {
        return noOfHarshBreakingByDates;
    }

    public void setNoOfHarshBreakingByDates(List<NoOfHarshBreakingByDateDto> noOfHarshBreakingByDates) {
        this.noOfHarshBreakingByDates = noOfHarshBreakingByDates;
    }

    public List<NoOfHarshCorneringByDateDto> getNoOfHarshCorneringByDates() {
        return noOfHarshCorneringByDates;
    }

    public void setNoOfHarshCorneringByDates(List<NoOfHarshCorneringByDateDto> noOfHarshCorneringByDates) {
        this.noOfHarshCorneringByDates = noOfHarshCorneringByDates;
    }

    public List<NoOfOverSpeedingEventsByDateDto> getNoOfOverSpeedingEventsByDates() {
        return noOfOverSpeedingEventsByDates;
    }

    public void setNoOfOverSpeedingEventsByDates(List<NoOfOverSpeedingEventsByDateDto> noOfOverSpeedingEventsByDates) {
        this.noOfOverSpeedingEventsByDates = noOfOverSpeedingEventsByDates;
    }

    public List<MilesDrivenOverSpeedingByDateDto> getMilesDrivenOverSpeedingByDates() {
        return milesDrivenOverSpeedingByDates;
    }

    public void setMilesDrivenOverSpeedingByDates(List<MilesDrivenOverSpeedingByDateDto> milesDrivenOverSpeedingByDates) {
        this.milesDrivenOverSpeedingByDates = milesDrivenOverSpeedingByDates;
    }

    public List<MilesDrivenInLaneTrackingZoneByDateDto> getMilesDrivenInLaneTrackingZoneByDates() {
        return milesDrivenInLaneTrackingZoneByDates;
    }

    public void setMilesDrivenInLaneTrackingZoneByDates(List<MilesDrivenInLaneTrackingZoneByDateDto> milesDrivenInLaneTrackingZoneByDates) {
        this.milesDrivenInLaneTrackingZoneByDates = milesDrivenInLaneTrackingZoneByDates;
    }

    public List<NoOfRapidAccelerationByDateDto> getNoOfRapidAccelerationByDates() {
        return noOfRapidAccelerationByDates;
    }

    public void setNoOfRapidAccelerationByDates(List<NoOfRapidAccelerationByDateDto> noOfRapidAccelerationByDates) {
        this.noOfRapidAccelerationByDates = noOfRapidAccelerationByDates;
    }

    public List<NoOfRapidDecelerationByDateDto> getNoOfRapidDecelerationByDates() {
        return noOfRapidDecelerationByDates;
    }

    public void setNoOfRapidDecelerationByDates(List<NoOfRapidDecelerationByDateDto> noOfRapidDecelerationByDates) {
        this.noOfRapidDecelerationByDates = noOfRapidDecelerationByDates;
    }

    public List<EngineOnDistanceTravelledExtremeWeatherByDateDto> getEngineOnDistanceTravelledExtremeWeatherByDates() {
        return engineOnDistanceTravelledExtremeWeatherByDates;
    }

    public void setEngineOnDistanceTravelledExtremeWeatherByDates(List<EngineOnDistanceTravelledExtremeWeatherByDateDto> engineOnDistanceTravelledExtremeWeatherByDates) {
        this.engineOnDistanceTravelledExtremeWeatherByDates = engineOnDistanceTravelledExtremeWeatherByDates;
    }
}
