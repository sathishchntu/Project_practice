package com.futuresense.autonostix360.domain.properties;

import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entity AutonostixProperties that hold prperty values for different tables
 */
@Table(value = "autonostix_properties")
public class AutonostixProperties {

    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("property_for_table")
    private String propertyForTable;

    @PartitionKey(4)
    @Column("property_name")
    private String propertyName;

    @PartitionKey(5)
    @Column("property_value")
    private String propertyValue;

    @Column("last_updated")
    private Timestamp lastUpdated;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getPropertyForTable() {
        return propertyForTable;
    }

    public void setPropertyForTable(String propertyForTable) {
        this.propertyForTable = propertyForTable;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(String propertyValue) {
        this.propertyValue = propertyValue;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
