package com.futuresense.autonostix360.mappers.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.EngineSpeedByLastMiles;
import com.futuresense.autonostix360.dto.usageprofile.EngineSpeedByLastMilesDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineSpeedByLastMilesMapper implements EntityMapper<EngineSpeedByLastMiles, EngineSpeedByLastMilesDto> {
    @Override
    public EngineSpeedByLastMiles buildEntity(EngineSpeedByLastMilesDto dto) {
        final EngineSpeedByLastMiles entity = new EngineSpeedByLastMiles();
        entity.setId(dto.getId());
        entity.setEngineSpeed(dto.getEngineSpeed());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setThreshold(dto.getThreshold());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineSpeedByLastMilesDto.class.getCanonicalName();
    }

    @Override
    public EngineSpeedByLastMilesDto buildDto(EngineSpeedByLastMiles entity) {
        final EngineSpeedByLastMilesDto dto = new EngineSpeedByLastMilesDto();
        dto.setId(entity.getId());
        dto.setEngineSpeed(entity.getEngineSpeed());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setThreshold(entity.getThreshold());
        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineSpeedByLastMiles.class.getCanonicalName();
    }
}
