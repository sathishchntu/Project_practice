package com.futuresense.autonostix360.dto.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.DriverBehaviourSummary;

import java.io.Serializable;

/**
 * Dto class represents response for entity  {@link DriverBehaviourSummary}.
 */
public class DriverBehaviourSummaryDto implements Serializable {

    private Double avgDistancePerDayMiles;

    private Double avgEngineRuntimeIdleHours;

    private Integer noOfOverSpeedingEvent;

    private Double milesDrivenOverSpeeding;

    private Double noOfHarshBreakingEvents;

    private Double noOfHarshCorneringEvents;

    private Double noOfRapidAccelerationPerMile;

    private Double mileDrivenInGreenZoneOfLaneTracking;

    private Double mileDrivenInYellowZoneOfLaneTracking;

    private Double mileDrivenInRedZoneOfLaneTracking;

    private String tendencyAvoidingHarshWeatherDriving;

    private Double percentageOfUnpavedDriving;

    private String criticalTrafficSignalViolationLimit;

    private String criticalStopSignalViolationLimit;

    private Double overallScorePercentage;

    public Double getAvgDistancePerDayMiles() {
        return avgDistancePerDayMiles;
    }

    public void setAvgDistancePerDayMiles(Double avgDistancePerDayMiles) {
        this.avgDistancePerDayMiles = avgDistancePerDayMiles;
    }

    public Double getAvgEngineRuntimeIdleHours() {
        return avgEngineRuntimeIdleHours;
    }

    public void setAvgEngineRuntimeIdleHours(Double avgEngineRuntimeIdleHours) {
        this.avgEngineRuntimeIdleHours = avgEngineRuntimeIdleHours;
    }

    public Integer getNoOfOverSpeedingEvent() {
        return noOfOverSpeedingEvent;
    }

    public void setNoOfOverSpeedingEvent(Integer noOfOverSpeedingEvent) {
        this.noOfOverSpeedingEvent = noOfOverSpeedingEvent;
    }

    public Double getMilesDrivenOverSpeeding() {
        return milesDrivenOverSpeeding;
    }

    public void setMilesDrivenOverSpeeding(Double milesDrivenOverSpeeding) {
        this.milesDrivenOverSpeeding = milesDrivenOverSpeeding;
    }

    public Double getNoOfHarshBreakingEvents() {
        return noOfHarshBreakingEvents;
    }

    public void setNoOfHarshBreakingEvents(Double noOfHarshBreakingEvents) {
        this.noOfHarshBreakingEvents = noOfHarshBreakingEvents;
    }

    public Double getNoOfHarshCorneringEvents() {
        return noOfHarshCorneringEvents;
    }

    public void setNoOfHarshCorneringEvents(Double noOfHarshCorneringEvents) {
        this.noOfHarshCorneringEvents = noOfHarshCorneringEvents;
    }

    public Double getNoOfRapidAccelerationPerMile() {
        return noOfRapidAccelerationPerMile;
    }

    public void setNoOfRapidAccelerationPerMile(Double noOfRapidAccelerationPerMile) {
        this.noOfRapidAccelerationPerMile = noOfRapidAccelerationPerMile;
    }

    public Double getMileDrivenInGreenZoneOfLaneTracking() {
        return mileDrivenInGreenZoneOfLaneTracking;
    }

    public void setMileDrivenInGreenZoneOfLaneTracking(Double mileDrivenInGreenZoneOfLaneTracking) {
        this.mileDrivenInGreenZoneOfLaneTracking = mileDrivenInGreenZoneOfLaneTracking;
    }

    public Double getMileDrivenInYellowZoneOfLaneTracking() {
        return mileDrivenInYellowZoneOfLaneTracking;
    }

    public void setMileDrivenInYellowZoneOfLaneTracking(Double mileDrivenInYellowZoneOfLaneTracking) {
        this.mileDrivenInYellowZoneOfLaneTracking = mileDrivenInYellowZoneOfLaneTracking;
    }

    public Double getMileDrivenInRedZoneOfLaneTracking() {
        return mileDrivenInRedZoneOfLaneTracking;
    }

    public void setMileDrivenInRedZoneOfLaneTracking(Double mileDrivenInRedZoneOfLaneTracking) {
        this.mileDrivenInRedZoneOfLaneTracking = mileDrivenInRedZoneOfLaneTracking;
    }

    public String getTendencyAvoidingHarshWeatherDriving() {
        return tendencyAvoidingHarshWeatherDriving;
    }

    public void setTendencyAvoidingHarshWeatherDriving(String tendencyAvoidingHarshWeatherDriving) {
        this.tendencyAvoidingHarshWeatherDriving = tendencyAvoidingHarshWeatherDriving;
    }

    public Double getPercentageOfUnpavedDriving() {
        return percentageOfUnpavedDriving;
    }

    public void setPercentageOfUnpavedDriving(Double percentageOfUnpavedDriving) {
        this.percentageOfUnpavedDriving = percentageOfUnpavedDriving;
    }

    public String getCriticalTrafficSignalViolationLimit() {
        return criticalTrafficSignalViolationLimit;
    }

    public void setCriticalTrafficSignalViolationLimit(String criticalTrafficSignalViolationLimit) {
        this.criticalTrafficSignalViolationLimit = criticalTrafficSignalViolationLimit;
    }

    public String getCriticalStopSignalViolationLimit() {
        return criticalStopSignalViolationLimit;
    }

    public void setCriticalStopSignalViolationLimit(String criticalStopSignalViolationLimit) {
        this.criticalStopSignalViolationLimit = criticalStopSignalViolationLimit;
    }

    public Double getOverallScorePercentage() {
        return overallScorePercentage;
    }

    public void setOverallScorePercentage(Double overallScorePercentage) {
        this.overallScorePercentage = overallScorePercentage;
    }
}
