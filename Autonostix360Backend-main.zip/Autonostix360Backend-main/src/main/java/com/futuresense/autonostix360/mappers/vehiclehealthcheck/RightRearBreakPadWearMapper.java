package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.RightRearBreakPadWear;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.RightRearBreakPadWearDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class RightRearBreakPadWearMapper implements EntityMapper<RightRearBreakPadWear, RightRearBreakPadWearDto> {

    @Override
    public RightRearBreakPadWear buildEntity(RightRearBreakPadWearDto dto) {
        final RightRearBreakPadWear entity = new RightRearBreakPadWear();
        entity.setId(dto.getId());
        entity.setModule(dto.getModule());
        entity.setTime(dto.getTime());
        entity.setValveActuationDutyCyclePWM(dto.getValveActuationDutyCyclePWM());
        entity.setBreakFluidPressure20k(dto.getBreakFluidPressure20k());
        entity.setBreakFluidPressure50k(dto.getBreakFluidPressure50k());
        entity.setBreakFluidPressure100k(dto.getBreakFluidPressure100k());
        entity.setBreakFluidPressure120k(dto.getBreakFluidPressure120k());
        entity.setLastUpdated(dto.getLastUpdated());
        entity.setOdometer(dto.getOdometer());
        entity.setVinNumber(dto.getVinNumber());
        entity.setOrganizationId(dto.getOrganizationId());
        entity.setStatsDate(dto.getStatsDate());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return RightRearBreakPadWearDto.class.getCanonicalName();
    }

    @Override
    public RightRearBreakPadWearDto buildDto(RightRearBreakPadWear entity) {
        final RightRearBreakPadWearDto dto = new RightRearBreakPadWearDto();
        dto.setId(entity.getId());
        dto.setModule(entity.getModule());
        dto.setTime(entity.getTime());
        dto.setBreakFluidPressure20k(entity.getBreakFluidPressure20k());
        dto.setBreakFluidPressure50k(entity.getBreakFluidPressure50k());
        dto.setValveActuationDutyCyclePWM(entity.getValveActuationDutyCyclePWM());
        dto.setBreakFluidPressure100k(entity.getBreakFluidPressure100k());
        dto.setBreakFluidPressure120k(entity.getBreakFluidPressure120k());
        dto.setOrganizationId(entity.getOrganizationId());
        dto.setLastUpdated(entity.getLastUpdated());
        dto.setStatsDate(entity.getStatsDate());
        dto.setVinNumber(entity.getVinNumber());
        dto.setOdometer(entity.getOdometer());
        return dto;
    }

    @Override
    public String entityClassName() {
        return RightRearBreakPadWear.class.getCanonicalName();
    }
}
