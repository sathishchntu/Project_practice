package com.futuresense.autonostix360.mappers.vehiclehealthcheck;


import com.futuresense.autonostix360.domain.vehiclehealthcheck.TimeBetweenParticularFilterRegenByLastDate;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.TimeBetweenParticularFilterRegenByLastDateDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class TimeBetweenParticularFilterRegenByLastDateMapper implements EntityMapper<TimeBetweenParticularFilterRegenByLastDate, TimeBetweenParticularFilterRegenByLastDateDto> {

    @Override
    public TimeBetweenParticularFilterRegenByLastDate buildEntity(TimeBetweenParticularFilterRegenByLastDateDto dto) {
        final TimeBetweenParticularFilterRegenByLastDate entity = new TimeBetweenParticularFilterRegenByLastDate();
        entity.setId(dto.getId());
        entity.setTimeBetweenParticularFilterRegenMin(dto.getTimeBetweenParticularFilterRegenMin());
        entity.setStatsDate(dto.getStatsDate());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return TimeBetweenParticularFilterRegenByLastDateDto.class.getCanonicalName();
    }

    @Override
    public TimeBetweenParticularFilterRegenByLastDateDto buildDto(TimeBetweenParticularFilterRegenByLastDate entity) {
        final TimeBetweenParticularFilterRegenByLastDateDto dto = new TimeBetweenParticularFilterRegenByLastDateDto();
        dto.setId(entity.getId());
        dto.setTimeBetweenParticularFilterRegenMin(entity.getTimeBetweenParticularFilterRegenMin());
        dto.setStatsDate(entity.getStatsDate());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        return dto;
    }

    @Override
    public String entityClassName() {
        return TimeBetweenParticularFilterRegenByLastDate.class.getCanonicalName();
    }
}
