package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.UreaDieselConsumptionByLastTrip;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.UreaDieselConsumptionByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class UreaDieselConsumptionByLastTripMapper implements EntityMapper<UreaDieselConsumptionByLastTrip, UreaDieselConsumptionByLastTripDto> {

    @Override
    public UreaDieselConsumptionByLastTrip buildEntity(UreaDieselConsumptionByLastTripDto dto) {
        final UreaDieselConsumptionByLastTrip entity = new UreaDieselConsumptionByLastTrip();
        entity.setId(dto.getId());
        entity.setTimeToStartTheEngineSeconds(dto.getTimeToStartTheEngineSeconds());
        entity.setTrip(dto.getTrip());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());

        return entity;
    }

    @Override
    public String dtoClassName() {
        return UreaDieselConsumptionByLastTripDto.class.getCanonicalName();
    }

    @Override
    public UreaDieselConsumptionByLastTripDto buildDto(UreaDieselConsumptionByLastTrip entity) {
        final UreaDieselConsumptionByLastTripDto dto = new UreaDieselConsumptionByLastTripDto();
        dto.setId(entity.getId());
        dto.setTimeToStartTheEngineSeconds(entity.getTimeToStartTheEngineSeconds());
        dto.setTrip(entity.getTrip());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());

        return dto;
    }

    @Override
    public String entityClassName() {
        return UreaDieselConsumptionByLastTrip.class.getCanonicalName();
    }
}
