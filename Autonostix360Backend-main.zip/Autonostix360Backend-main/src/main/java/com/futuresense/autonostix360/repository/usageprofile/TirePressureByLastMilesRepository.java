package com.futuresense.autonostix360.repository.usageprofile;

import com.futuresense.autonostix360.domain.usageprofile.TirePressureByLastMiles;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;

/**
 * TirePressureByLastMilesRepository
 */
public interface TirePressureByLastMilesRepository extends CassandraRepository<TirePressureByLastMiles, Long> {
    @Query("select * from tire_pressure_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    List<TirePressureByLastMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId);

    @Query("select max(odometer) from tire_pressure_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id=:organizationId")
    Integer findMaxOdometerReadingByVinAndOrganizationId(String vinNumber, Integer organizationId);

    @Query("select * from tire_pressure_by_last_miles " +
            "where vin_number = :vinNumber " +
            "and organization_id = :organizationId " +
            "and odometer >= :fromOdometerReading and odometer <= :maxOdometerReading")
    List<TirePressureByLastMiles> findAllByVinNumberAndOrganizationIdAndOdometerRange(String vinNumber, Integer organizationId, int fromOdometerReading, Integer maxOdometerReading);


}
