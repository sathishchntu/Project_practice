package com.futuresense.autonostix360.repository.remotemonitoring.driverbehaviour;

import com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour.DriverBehaviourSummary;
import org.springframework.data.cassandra.repository.CassandraRepository;

/**
 * Repository for DriverBehaviourSummary
 */
public interface DriverBehaviourSummaryRepository extends CassandraRepository<DriverBehaviourSummary, String> {

    DriverBehaviourSummary findByVinNumberAndOrganizationIdAndStatsDate(String vinNumber, Integer organizationId, String statsDate);
}
