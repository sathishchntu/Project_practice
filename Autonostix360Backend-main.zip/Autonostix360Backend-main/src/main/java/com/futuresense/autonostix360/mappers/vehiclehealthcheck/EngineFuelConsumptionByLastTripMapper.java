package com.futuresense.autonostix360.mappers.vehiclehealthcheck;

import com.futuresense.autonostix360.domain.vehiclehealthcheck.EngineFuelConsumptionByLastTrip;
import com.futuresense.autonostix360.dto.vehiclehealthcheck.EngineFuelConsumptionByLastTripDto;
import com.futuresense.autonostix360.mappers.coreinterfaces.EntityMapper;
import org.springframework.stereotype.Service;

/**
 * Mapper class provides conversion from Dto to Entity and vice versa
 */
@Service
public class EngineFuelConsumptionByLastTripMapper implements EntityMapper<EngineFuelConsumptionByLastTrip, EngineFuelConsumptionByLastTripDto> {

    @Override
    public EngineFuelConsumptionByLastTrip buildEntity(EngineFuelConsumptionByLastTripDto dto) {
        final EngineFuelConsumptionByLastTrip entity = new EngineFuelConsumptionByLastTrip();
        entity.setId(dto.getId());
        entity.setAverageFuelConsumption(dto.getAverageFuelConsumption());
        entity.setMiles(dto.getMiles());
        entity.setHours(dto.getHours());
        entity.setKeyStarts(dto.getKeyStarts());
        entity.setTrip(dto.getTrip());
        return entity;
    }

    @Override
    public String dtoClassName() {
        return EngineFuelConsumptionByLastTripDto.class.getCanonicalName();
    }

    @Override
    public EngineFuelConsumptionByLastTripDto buildDto(EngineFuelConsumptionByLastTrip entity) {
        final EngineFuelConsumptionByLastTripDto dto = new EngineFuelConsumptionByLastTripDto();
        dto.setId(entity.getId());
        dto.setAverageFuelConsumption(entity.getAverageFuelConsumption());
        dto.setMiles(entity.getMiles());
        dto.setHours(entity.getHours());
        dto.setKeyStarts(entity.getKeyStarts());
        dto.setTrip(entity.getTrip());

        return dto;
    }

    @Override
    public String entityClassName() {
        return EngineFuelConsumptionByLastTrip.class.getCanonicalName();
    }
}
