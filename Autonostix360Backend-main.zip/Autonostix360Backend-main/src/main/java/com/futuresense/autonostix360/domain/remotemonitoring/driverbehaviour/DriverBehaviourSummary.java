package com.futuresense.autonostix360.domain.remotemonitoring.driverbehaviour;

import com.datastax.oss.driver.api.mapper.annotations.PartitionKey;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Table;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Entity DriverBehaviourSummary represents table driver_behaviour_summary
 */
@Table(value = "driver_behaviour_summary")
public class DriverBehaviourSummary {

    @Id
    @Column("id")
    private UUID id;

    @PartitionKey(1)
    @Column("vin_number")
    private String vinNumber;

    @PartitionKey(2)
    @Column("organization_id")
    private Integer organizationId;

    @PartitionKey(3)
    @Column("stats_date")
    private String statsDate;

    @Column("avg_distance_per_day_miles")
    private Double avgDistancePerDayMiles;

    @Column("avg_engine_runtime_idle_hours")
    private Double avgEngineRuntimeIdleHours;

    @Column("no_of_over_speeding_event")
    private Integer noOfOverSpeedingEvent;

    @Column("miles_driven_over_speeding")
    private Double milesDrivenOverSpeeding;

    @Column("no_of_harsh_breaking_events")
    private Double noOfHarshBreakingEvents;

    @Column("no_of_harsh_cornering_events")
    private Double noOfHarshCorneringEvents;

    @Column("no_of_rapid_acceleration_per_mile")
    private Double noOfRapidAccelerationPerMile;

    @Column("mile_driven_in_green_zone_of_lane_tracking")
    private Double mileDrivenInGreenZoneOfLaneTracking;

    @Column("mile_driven_in_yellow_zone_of_lane_tracking")
    private Double mileDrivenInYellowZoneOfLaneTracking;

    @Column("mile_driven_in_red_zone_of_lane_tracking")
    private Double mileDrivenInRedZoneOfLaneTracking;

    @Column("tendency_avoiding_harsh_weather_driving")
    private String tendencyAvoidingHarshWeatherDriving;

    @Column("percentage_of_unpaved_driving")
    private Double percentageOfUnpavedDriving;

    @Column("critical_traffic_signal_violation_limit")
    private String criticalTrafficSignalViolationLimit;

    @Column("critical_stop_signal_violation_limit")
    private String criticalStopSignalViolationLimit;

    @Column("overall_score_percentage")
    private Double overallScorePercentage;

    @Column("last_updated")
    private Timestamp lastUpdated;

    @Column("odometer")
    private Integer odometer;


    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public String getStatsDate() {
        return statsDate;
    }

    public void setStatsDate(String statsDate) {
        this.statsDate = statsDate;
    }

    public Double getAvgDistancePerDayMiles() {
        return avgDistancePerDayMiles;
    }

    public void setAvgDistancePerDayMiles(Double avgDistancePerDayMiles) {
        this.avgDistancePerDayMiles = avgDistancePerDayMiles;
    }

    public Double getAvgEngineRuntimeIdleHours() {
        return avgEngineRuntimeIdleHours;
    }

    public void setAvgEngineRuntimeIdleHours(Double avgEngineRuntimeIdleHours) {
        this.avgEngineRuntimeIdleHours = avgEngineRuntimeIdleHours;
    }

    public Integer getNoOfOverSpeedingEvent() {
        return noOfOverSpeedingEvent;
    }

    public void setNoOfOverSpeedingEvent(Integer noOfOverSpeedingEvent) {
        this.noOfOverSpeedingEvent = noOfOverSpeedingEvent;
    }

    public Double getMilesDrivenOverSpeeding() {
        return milesDrivenOverSpeeding;
    }

    public void setMilesDrivenOverSpeeding(Double milesDrivenOverSpeeding) {
        this.milesDrivenOverSpeeding = milesDrivenOverSpeeding;
    }

    public Double getNoOfHarshBreakingEvents() {
        return noOfHarshBreakingEvents;
    }

    public void setNoOfHarshBreakingEvents(Double noOfHarshBreakingEvents) {
        this.noOfHarshBreakingEvents = noOfHarshBreakingEvents;
    }

    public Double getNoOfHarshCorneringEvents() {
        return noOfHarshCorneringEvents;
    }

    public void setNoOfHarshCorneringEvents(Double noOfHarshCorneringEvents) {
        this.noOfHarshCorneringEvents = noOfHarshCorneringEvents;
    }

    public Double getNoOfRapidAccelerationPerMile() {
        return noOfRapidAccelerationPerMile;
    }

    public void setNoOfRapidAccelerationPerMile(Double noOfRapidAccelerationPerMile) {
        this.noOfRapidAccelerationPerMile = noOfRapidAccelerationPerMile;
    }

    public Double getMileDrivenInGreenZoneOfLaneTracking() {
        return mileDrivenInGreenZoneOfLaneTracking;
    }

    public void setMileDrivenInGreenZoneOfLaneTracking(Double mileDrivenInGreenZoneOfLaneTracking) {
        this.mileDrivenInGreenZoneOfLaneTracking = mileDrivenInGreenZoneOfLaneTracking;
    }

    public Double getMileDrivenInYellowZoneOfLaneTracking() {
        return mileDrivenInYellowZoneOfLaneTracking;
    }

    public void setMileDrivenInYellowZoneOfLaneTracking(Double mileDrivenInYellowZoneOfLaneTracking) {
        this.mileDrivenInYellowZoneOfLaneTracking = mileDrivenInYellowZoneOfLaneTracking;
    }

    public Double getMileDrivenInRedZoneOfLaneTracking() {
        return mileDrivenInRedZoneOfLaneTracking;
    }

    public void setMileDrivenInRedZoneOfLaneTracking(Double mileDrivenInRedZoneOfLaneTracking) {
        this.mileDrivenInRedZoneOfLaneTracking = mileDrivenInRedZoneOfLaneTracking;
    }

    public String getTendencyAvoidingHarshWeatherDriving() {
        return tendencyAvoidingHarshWeatherDriving;
    }

    public void setTendencyAvoidingHarshWeatherDriving(String tendencyAvoidingHarshWeatherDriving) {
        this.tendencyAvoidingHarshWeatherDriving = tendencyAvoidingHarshWeatherDriving;
    }

    public Double getPercentageOfUnpavedDriving() {
        return percentageOfUnpavedDriving;
    }

    public void setPercentageOfUnpavedDriving(Double percentageOfUnpavedDriving) {
        this.percentageOfUnpavedDriving = percentageOfUnpavedDriving;
    }

    public String getCriticalTrafficSignalViolationLimit() {
        return criticalTrafficSignalViolationLimit;
    }

    public void setCriticalTrafficSignalViolationLimit(String criticalTrafficSignalViolationLimit) {
        this.criticalTrafficSignalViolationLimit = criticalTrafficSignalViolationLimit;
    }

    public String getCriticalStopSignalViolationLimit() {
        return criticalStopSignalViolationLimit;
    }

    public void setCriticalStopSignalViolationLimit(String criticalStopSignalViolationLimit) {
        this.criticalStopSignalViolationLimit = criticalStopSignalViolationLimit;
    }

    public Double getOverallScorePercentage() {
        return overallScorePercentage;
    }

    public void setOverallScorePercentage(Double overallScorePercentage) {
        this.overallScorePercentage = overallScorePercentage;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }
}
