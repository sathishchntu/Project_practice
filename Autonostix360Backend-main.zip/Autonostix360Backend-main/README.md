#Autonostix360 microservice
This application was generated using https://start.spring.io/

## Development

To start your application in the dev profile, run:

```
-Dspring.profiles.active=dev [VM option]
```

## Build

```
build war: 
./gradlew clean build -x test
```

```
build jar: 
./gradlew -Pversion=1.0.0 build clean build -x test bootJar
```

## Run as jar file:

```
prodMode:
SET ASTRA_API_TOKEN=
SET ASTRA_API_DATABASE_ID=
SET ASTRA_API_DATABASE_REGION=
SET ASTRA_CQL_DOWNLOAD_PATH=
SET ASTRA_DRIVER_CONFIG_BASIC_KEYSPACE=
java -jar -Xmx1024m -Dspring.profiles.active=dev build/libs/autonostix360servicev1.jar
```

```
devMode:
java -jar -Dspring.profiles.active=dev build/libs/autonostix360servicev1.jar
```

## API documentation:

```
http://localhost:8096/api-docs
```

```
The OpenAPI definitions are in JSON format by default. For yaml format, we can obtain the definitions at:
```

```
http://localhost:8096/api-docs.yaml
```

### Swagger

```
http://localhost:8096/swagger-ui.html
```

## actuator health

```
http://localhost:8096/actuator/health
```

## Dockerization

```
To build and push to docker hub

./gradlew clean dockerPush --exclude-task test -PimageRegistry='youngsoftinida/autonostix' -PrunEnv=dev -PimageVersion='v1.0.5'



docker run -d -it -p 8096:8096 --env-file='/home/experimets/work/dev.env' youngsoftinida/autonostix:backend-v1.0.5

```

## ELASTICSEARCH (Using docker-compose to setup elastic search & kibana 7.8.1)

```
docker-compose -f docker-componse.yml up -d
```