#!/bin/sh

echo "Running with: Java Options: ${JAVA_OPTS}, Jar and Args: ${@}, Default Spring Profile: ${SPRING_PROFILES_ACTIVE}"
exec java ${JAVA_OPTS} -jar ${@}
